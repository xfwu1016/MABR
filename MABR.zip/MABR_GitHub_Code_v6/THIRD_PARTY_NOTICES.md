# Data and algorithm attribution

UCI Mammographic Mass: Elter, M. (2007), DOI https://doi.org/10.24432/C53K6Z, CC BY 4.0. UCI Hepatitis: (1983, repository citation year), DOI https://doi.org/10.24432/C5Q59J, CC BY 4.0. License link: https://creativecommons.org/licenses/by/4.0/ . Original data files are retained. Their use in encoding, grouping, splitting and simulated federation is documented in the corresponding protocol; those transformations do not imply endorsement by the original creators.

WDBC: Wolberg et al. (1993), https://doi.org/10.24432/C5DW2B . Optical Recognition of Handwritten Digits: Alpaydin and Kaynak (1998), https://doi.org/10.24432/C50P49 . The code uses the copies distributed with scikit-learn and retains its dataset description links.

FLTrust: Cao, Fang, Liu and Gong (NDSS 2021), https://doi.org/10.14722/ndss.2021.24434 . Numerical rules were checked against the authors' public source https://people.duke.edu/~zg70/code/fltrust.zip . Project `author_methods.py` files provide this study's NumPy adaptation. The external MXNet source archive itself is not redistributed in this code package.

Other dependencies are installed separately under their respective licenses. This notice does not relicense any dataset or third-party implementation.
