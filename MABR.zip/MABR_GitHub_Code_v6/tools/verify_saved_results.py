from pathlib import Path
import csv,itertools,json,math
ROOT=Path(__file__).resolve().parents[1]/'reproduction'
def check(path,fields,axes):
    with (ROOT/path).open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
    keys=[tuple(r[k] for k in fields) for r in rows]
    expected=set(itertools.product(*axes))
    assert len(keys)==len(set(keys))==len(expected),path
    assert set(keys)==expected,path
    assert all(math.isfinite(float(r[k])) for r in rows for k in ['test_accuracy','test_balanced_accuracy','test_ce']),path
    return len(rows)
d=['breast_cancer','digits'];s=list(map(str,range(5)))
controlled=check('fltrust/comparison_runs.csv',['dataset','seed','attack','method'],[d,s,['none','signflip','alie','transport_aware','root_aligned'],['Median','FLTrust','FLTrust-CM','MGT-Med','TransportFLTrust','ReferenceOnly']])
natural=check('natural/natural_runs.csv',['dataset','partition','seed','attack','method'],[['mammographic_mass','hepatitis'],['random','burden'],s,['none','signflip','root_aligned'],['Mean','Median','FLTrust','MGT-Med','TransportFLTrust','ReferenceOnly']])
joint=check('natural/extension/joint_runs.csv',['dataset','partition','seed','attack','method'],[['mammographic_mass','hepatitis'],['random','burden'],s,['none','signflip','root_aligned'],['Joint-FLTrust','Joint-MGT-Med','Joint-TransportFLTrust','Joint-ReferenceOnly']])
sensitivity=check('fltrust/sensitivity/sensitivity_runs.csv',['seed','attack','method','learning_rate','hidden','rounds'],[list(map(str,range(3))),['signflip','root_aligned'],['Median','FLTrust','FLTrust-CM','MGT-Med','TransportFLTrust'],['0.05','0.15','0.3'],['12','48'],['160','320']])
print(json.dumps({'controlled_rows':controlled,'native_product_rows':natural,'native_joint_rows':joint,'sensitivity_checkpoint_rows':sensitivity,'primary_named_fits':controlled+natural+joint+sensitivity//2,'complete_factorial_grids':True,'finite_predictive_metrics':True},indent=2))
