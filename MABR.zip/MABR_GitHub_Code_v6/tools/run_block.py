from pathlib import Path
import argparse,shutil,subprocess,sys
repo=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('block',choices=['controlled','sensitivity','natural','joint']);p.add_argument('--fresh',action='store_true',required=True);p.add_argument('--output',type=Path);a=p.parse_args()
dest=(a.output or repo/'runs'/a.block).resolve()
if dest.exists():raise SystemExit('Output already exists; choose a new --output directory.')
drop={'controlled':{'comparison_runs.csv','comparison_curves.csv'},'sensitivity':{'sensitivity_runs.csv','sensitivity_curves.csv'},'natural':{'natural_runs.csv','natural_curves.csv'},'joint':{'joint_runs.csv','joint_curves.csv'}}[a.block]
shutil.copytree(repo/'reproduction',dest/'reproduction',ignore=lambda folder,names:[n for n in names if n in drop or n=='__pycache__'])
r=dest/'reproduction'
cmd={'controlled':[r/'fltrust/run_comparison.py','--workers','2'],'sensitivity':[r/'fltrust/run_sensitivity.py'],'natural':[r/'natural/run_natural.py'],'joint':[r/'natural/extension/run_joint.py']}[a.block]
subprocess.run([sys.executable,*map(str,cmd)],cwd=dest,check=True)
