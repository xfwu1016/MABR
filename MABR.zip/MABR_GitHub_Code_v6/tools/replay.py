from pathlib import Path
import sys,csv,json,hashlib
project=Path(__file__).resolve().parents[1];block=sys.argv[1]
if block not in {'controlled','natural','joint'}:raise SystemExit('Choose controlled, natural, or joint.')
if block=='controlled':
    folder=project/'reproduction'/'fltrust';sys.path.insert(0,str(folder))
    import run_comparison as module
    dataset='digits';seed=0;attack='root_aligned';method='FLTrust-CM'
    row=module.run_one((dataset,seed,attack,method))[0]
    rows=list(csv.DictReader((folder/'comparison_runs.csv').open()))
elif block=='natural':
    folder=project/'reproduction'/'natural';sys.path.insert(0,str(folder))
    import run_natural as module
    dataset='mammographic_mass';seed=0;attack='none';method='FLTrust'
    row=module.run(dataset,seed,'random',attack,method)[0]
    rows=[r for r in csv.DictReader((folder/'natural_runs.csv').open()) if r['partition']=='random']
else:
    folder=project/'reproduction'/'natural'/'extension';sys.path.insert(0,str(folder))
    import run_joint as module
    dataset='hepatitis';seed=0;attack='root_aligned';method='Joint-MGT-Med'
    row=module.run(dataset,'burden',seed,attack,method)[0]
    rows=[r for r in csv.DictReader((folder/'joint_runs.csv').open()) if r['partition']=='burden']
expected=next(r for r in rows if (r['dataset'],int(r['seed']),r['attack'],r['method'])==(dataset,seed,attack,method))
assert row['parameter_sha256']==expected['parameter_sha256']
for field in ['test_accuracy','test_ce','test_balanced_accuracy']:
    assert abs(row[field]-float(expected[field]))<1e-14
print(json.dumps({'block':block,'dataset':dataset,'seed':seed,'attack':attack,'method':method,'exact_parameter_hash_match':True,'metrics_match':True}))
