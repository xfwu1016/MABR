# 使用说明

作者：Xiaofei Wu、Wanling Xie、Rongmei Liang（通讯）。基金：国家自然科学基金12401345。

推荐Python 3.12。先安装requirements.txt，再运行`python tools/verify_saved_results.py`检查保存结果。`tools/replay.py`可选择controlled、natural或joint，实际重算一条完整训练轨迹并对比保存的参数哈希和指标。

完整重新训练请用`python tools/run_block.py controlled --fresh`，其他可选项为sensitivity、natural、joint。程序会新建runs子目录，不覆盖分发的保存结果。直接运行reproduction内的原实验入口会恢复已保存的记录，通常不会重新执行全部训练。

GitHub代码包包含实验程序、公有原始数据、配置、结果CSV和图表程序；不包含论文PDF、作者审批清单、虚拟环境、缓存、模型权重及36.7MB诊断向量文件。大诊断文件可由README中的命令重新生成。1080次主要训练执行不等于1080个独立统计样本。

原软件尚未指定统一开源许可证；未擅自添加MIT/Apache授权。数据源许可和算法来源见THIRD_PARTY_NOTICES.md。压缩包解压后上传内部文件和目录即可，不需将ZIP本身作为仓库源码提交。
