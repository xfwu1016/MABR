# Release scope

The paper metadata correspond to v6 (three authors; NSFC 12401345). Numerical evidence is preserved from the v3 reproducibility release, with the same saved outcomes. The v4 citation audit and v5 language edits did not change training results.

Only executable path resolution and auxiliary figure output-directory creation were adjusted for a standalone repository; `packaging_changes.json` records these edits. Original execution-time source hashes remain historical provenance and are not relabeled as hashes of the packaging edits. `SHA256SUMS.json` records the files in this distribution.

Obsolete workspace archiving helpers, workspace citation-processing scripts, caches, model checkpoints and the large conditional-gradient NPZ are omitted. Saved result CSVs, data archives, split/configuration records, native masks and diagnostic replicate CSVs are retained. Computational checks do not independently certify every theorem or validate the statistical assumptions on natural data.
