"""Summaries and figures generated exclusively from saved experiment rows."""
import os
for name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):
    os.environ[name]='1'
import csv,json,hashlib
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
METHODS=['Mean','Median','TrimmedMean','FLTrust','ReferenceOnly','TransportMean','MGT-Med']
ATTACKS=['none','signflip','alie','transport_aware']
DATASETS=['breast_cancer','digits','synthetic']
COLORS=['#777777','#0072B2','#56B4E9','#009E73','#CC79A7','#E69F00','#D55E00']
LABELS=dict(none='No attack',signflip='Sign flip',alie='ALIE-style',transport_aware='Transport-aware')

def load(name):
    p=ROOT/name
    if not p.exists():return []
    with p.open(encoding='utf-8') as f:
        return list(csv.DictReader(f))

def stats(rows,col):
    a=np.array([float(r[col]) for r in rows]);return a.mean(),a.std(ddof=1) if len(a)>1 else 0.

def subset(rows,**kw):return [r for r in rows if all(str(r[k])==str(v) for k,v in kw.items())]

def exact_counterexample():
    pa=np.array([.95,.2]);pb=np.array([.2,.95]);ps=np.array([.65,.65])
    pp=[pa]*6+[pb]*5
    def H(p):return np.array([[p[0],p.prod()],[p.prod(),p[1]]])
    def grad(w,p):return H(p)@w-p
    def loss(w,p):return .5*(w@H(p)@w-2*p@w+1)
    true=np.linalg.solve(H(ps),ps);wa=np.zeros(2);wc=np.zeros(2);hist=[]
    for t in range(401):
        hist.append(dict(round=t,raw_w1=wa[0],raw_w2=wa[1],transport_w1=wc[0],transport_w2=wc[1],
                         raw_target_loss=loss(wa,ps),transport_target_loss=loss(wc,ps)))
        ga=np.stack([grad(wa,p) for p in pp]);gc=np.stack([grad(wc,p)-grad(wc,p)+grad(wc,ps) for p in pp])
        wa-=.5*np.median(ga,axis=0);wc-=.5*np.median(gc,axis=0)
    with (ROOT/'counterexample.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(hist[0]));w.writeheader();w.writerows(hist)
    report=dict(setting='X1=X2=Y in {-1,1}, squared loss, exact population gradients, no Byzantine clients',
                profiles_a=pa.tolist(),profiles_b=pb.tolist(),counts=[6,5],target=ps.tolist(),
                target_optimum=true.tolist(),majority_profile_optimum=np.linalg.solve(H(pa),pa).tolist(),
                median_final=wa.tolist(),transport_final=wc.tolist(),
                median_target_loss=loss(wa,ps),transport_target_loss=loss(wc,ps),
                transport_max_optimality_error=float(np.abs(wc-true).max()))
    (ROOT/'counterexample.json').write_text(json.dumps(report,indent=2))
    fig,ax=plt.subplots(1,2,figsize=(7.1,2.6),layout='constrained')
    ax[0].plot([r['raw_w1'] for r in hist],[r['raw_w2'] for r in hist],color=COLORS[1],label='Raw median')
    ax[0].plot([r['transport_w1'] for r in hist],[r['transport_w2'] for r in hist],color=COLORS[-1],ls='--',label='Exact transport + median')
    ax[0].scatter(*true,color='black',marker='*',s=85,label='Target optimum',zorder=5)
    ax[0].set(xlabel=r'$w_1$',ylabel=r'$w_2$',title='(a) Optimization paths',xlim=(-.02,1.04),ylim=(-.02,.7));ax[0].legend(fontsize=7)
    ax[1].plot([r['round'] for r in hist],[r['raw_target_loss'] for r in hist],color=COLORS[1],label='Raw median')
    ax[1].plot([r['round'] for r in hist],[r['transport_target_loss'] for r in hist],color=COLORS[-1],ls='--',label='Exact transport + median')
    ax[1].set(xlabel='Round',ylabel='Target squared loss',title='(b) Target loss',ylim=(0,.52))
    save(fig,'counterexample')
    return report

def save(fig,name):
    out=ROOT/'figures';out.mkdir(exist_ok=True)
    fig.savefig(out/(name+'.pdf'),metadata={'Creator':'NumPy/Matplotlib experiment script'})
    fig.savefig(out/(name+'.png'),dpi=220)
    plt.close(fig)

def summarize():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':9,
                         'axes.labelsize':8,'legend.fontsize':7,'pdf.fonttype':42,
                         'axes.spines.top':False,'axes.spines.right':False})
    rows=load('main_runs.csv');curves=load('main_curves.csv');stress=load('stress_runs.csv')
    budgets=load('budget_runs.csv');diagnostic=load('fixed_theta_diagnostic.csv');static=load('static_runs.csv')
    if not rows:raise RuntimeError('No experiment rows')
    expected=3*3*4*7
    keys={(r['dataset'],r['seed'],r['attack'],r['method']) for r in rows}
    summaries=[]
    for d in DATASETS:
        for a in ATTACKS:
            for m in METHODS:
                rr=subset(rows,dataset=d,attack=a,method=m)
                if not rr:continue
                acc,sd=stats(rr,'test_accuracy');ce,csd=stats(rr,'test_ce')
                summaries.append(dict(dataset=d,attack=a,method=m,n=len(rr),accuracy_mean=acc,
                                      accuracy_sd=sd,ce_mean=ce,ce_sd=csd))
    with (ROOT/'summary.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(summaries[0]));w.writeheader();w.writerows(summaries)
    # Machine-generated tables retain every comparator and attack.
    lines=[r'\begin{table*}[t]',r'\centering',
           r'\caption{Final target-mask test accuracy (\%, mean $\pm$ sample SD over three paired seeds). All methods use the same mask-aware MLP. The reference core is available to FLTrust, ReferenceOnly, TransportMean and MGT-Med.}',
           r'\label{tab:main}',r'\small',r'\setlength{\tabcolsep}{4pt}',
           r'\begin{tabular}{llrrrrrrr}',r'\toprule',
           'Dataset & Attack & '+ ' & '.join(METHODS)+r' \\',r'\midrule']
    for d in DATASETS:
        for a in ATTACKS:
            vals=[]
            ss=subset(summaries,dataset=d,attack=a);best=max(s['accuracy_mean'] for s in ss)
            for m in METHODS:
                s=next(s for s in ss if s['method']==m)
                v=f"{100*s['accuracy_mean']:.1f} $\\pm$ {100*s['accuracy_sd']:.1f}"
                if s['accuracy_mean']==best:v=r'\textbf{'+v+'}'
                vals.append(v)
            lines.append(d.replace('_',' ')+' & '+LABELS[a]+' & '+' & '.join(vals)+r' \\')
        lines.append(r'\midrule' if d!=DATASETS[-1] else r'\bottomrule')
    lines +=[r'\end{tabular}',r'\end{table*}']
    (ROOT/'generated_tables.tex').write_text('\n'.join(lines),encoding='utf-8')
    fig,axes=plt.subplots(1,3,figsize=(7.1,3.0),layout='constrained',sharey=True)
    for ax,d in zip(axes,DATASETS):
        for j,m in enumerate(METHODS):
            ss=[next(s for s in summaries if s['dataset']==d and s['attack']==a and s['method']==m) for a in ATTACKS]
            ax.errorbar(np.arange(4)+(j-3)*.035,[s['accuracy_mean']*100 for s in ss],
                        yerr=[s['accuracy_sd']*100 for s in ss],color=COLORS[j],marker=['o','s','^','D','v','x','*'][j],
                        ms=3,ls='none',lw=1,label=m,capsize=1)
        ax.set_title(d.replace('_',' ').title());ax.set_xticks(range(4),['None','Sign flip','ALIE','Adaptive'],rotation=25)
        ax.set_xlabel('Attack');ax.set_ylim(0,102);ax.grid(axis='y',alpha=.2)
    axes[0].set_ylabel('Target-mask test accuracy (%)')
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='outside lower center',ncol=4,frameon=False)
    save(fig,'main_accuracy')
    fig,axes=plt.subplots(1,2,figsize=(7.1,2.9),layout='constrained',sharey=True)
    for ax,a in zip(axes,['signflip','transport_aware']):
        for j,m in enumerate(METHODS):
            rr=subset(curves,dataset='digits',attack=a,method=m)
            ts=sorted({int(r['round']) for r in rr}); means=[];sds=[]
            for t in ts:
                mu,sd=stats(subset(rr,round=t),'test_accuracy');means.append(100*mu);sds.append(100*sd)
            means=np.array(means);sds=np.array(sds)
            ax.plot(ts,means,color=COLORS[j],ls='--' if j in (4,5) else '-',lw=1.1,label=m)
            ax.fill_between(ts,means-sds,means+sds,color=COLORS[j],alpha=.09)
        ax.set(xlabel='Communication round',title=LABELS[a],ylim=(0,100));ax.grid(alpha=.2)
    axes[0].set_ylabel('Digits target-mask accuracy (%)')
    fig.legend(*axes[0].get_legend_handles_labels(),loc='outside lower center',ncol=4,frameon=False)
    save(fig,'digits_curves')
    fig,axes=plt.subplots(1,2,figsize=(7.1,2.6),layout='constrained')
    for j,(raw,corrected,label) in enumerate([
        ('raw_dispersion','corrected_dispersion','Honest gradient dispersion'),
        ('raw_median_anchor_error','corrected_median_anchor_error','Median-to-anchor distance')]):
        ax=axes[j]
        for k,d in enumerate(DATASETS):
            rr=subset(rows,dataset=d,attack='none',method='MGT-Med')
            aa=np.array([float(r[raw]) for r in rr]);bb=np.array([float(r[corrected]) for r in rr])
            for s in range(len(aa)):ax.plot([k-.13,k+.13],[aa[s],bb[s]],color='#999999',alpha=.6,lw=.7)
            ax.scatter(np.full(len(aa),k-.13),aa,color=COLORS[1],marker='o',s=20,label='Raw' if k==0 else None)
            ax.scatter(np.full(len(bb),k+.13),bb,color=COLORS[-1],marker='s',s=20,label='Transported' if k==0 else None)
        ax.set_xticks(range(3),['Breast cancer','Digits','Synthetic'],rotation=10)
        ax.set_title(label);ax.set_ylabel('Squared norm' if j==0 else 'Euclidean norm');ax.set_ylim(bottom=0);ax.legend()
    save(fig,'mechanism')
    fig,axes=plt.subplots(1,2,figsize=(7.1,2.8),layout='constrained')
    for j,m in enumerate(['ReferenceOnly','FLTrust','MGT-Med']):
        xx=[16,64,128];yy=[];sd=[]
        for b in xx:
            mu,ss=stats(subset(budgets,reference_size=b,method=m),'test_accuracy');yy.append(mu*100);sd.append(ss*100)
        axes[0].errorbar(xx,yy,yerr=sd,color=COLORS[[4,3,6][j]],marker=['v','D','s'][j],capsize=2,label=m)
    axes[0].set(xlabel='Trusted core size',ylabel='Digits accuracy (%)',title='(a) Reference-budget sensitivity',ylim=(30,100))
    axes[0].legend();axes[0].grid(alpha=.2)
    for j,k in enumerate(['raw_median_error','corrected_median_error','oracle_corrected_median_error']):
        xx=[16,64,128,512,2048,8192];yy=[];sd=[]
        for b in xx:
            mu,ss=stats(subset(diagnostic,reference_size=b),k);yy.append(mu);sd.append(ss)
        axes[1].errorbar(xx,yy,yerr=sd,color=[COLORS[1],COLORS[-1],COLORS[3]][j],marker=['o','s','^'][j],
                         ls='--' if j==2 else '-',capsize=2,label=['Raw median','Estimated transport','MC population correction'][j])
    axes[1].set_xscale('log',base=2);axes[1].set(xlabel='Independent calibration size',ylabel='Gradient error norm',
        title='(b) Fixed-parameter diagnostic',ylim=(0,None));axes[1].legend();axes[1].grid(alpha=.2)
    axes[1].set_xticks([16,64,128,512,2048,8192],['16','64','128','512','2048','8192'],rotation=20)
    save(fig,'reference_tradeoff')
    counter=exact_counterexample()
    pairs=[]
    for d in DATASETS:
        for a in ATTACKS:
            base=subset(rows,dataset=d,attack=a,method='Median'); prop=subset(rows,dataset=d,attack=a,method='MGT-Med')
            dif=[float(next(p for p in prop if p['seed']==b['seed'])['test_accuracy'])-float(b['test_accuracy']) for b in base]
            pairs.append(dict(dataset=d,attack=a,mean_accuracy_difference_pp=100*np.mean(dif),
                              sd_difference_pp=100*np.std(dif,ddof=1),per_seed_difference_pp=(100*np.array(dif)).tolist()))
    wins=int(sum(p['mean_accuracy_difference_pp']>0 for p in pairs))
    report=dict(n_rows=len(rows),expected_rows=expected,unique_keys=len(keys),complete=len(rows)==expected==len(keys),
                seeds=[0,1,2],same_seed_pairs=True,median_comparisons=pairs,
                positive_mean_cells_vs_median=wins,total_cells=len(pairs),counterexample=counter,
                stress_rows=len(stress),static_rows=len(static),budget_rows=len(budgets),fixed_theta_rows=len(diagnostic),
                all_main_metrics_finite=all(np.isfinite(float(r['test_ce'])) and np.isfinite(float(r['test_accuracy'])) for r in rows),
                raw_runs_sha256=hashlib.sha256((ROOT/'main_runs.csv').read_bytes()).hexdigest())
    (ROOT/'validation.json').write_text(json.dumps(report,indent=2))
    txt=['# Experiment evidence report','',f'Completed {len(rows)}/{expected} main neural fits; {len(stress)} domain-shift stress fits.',
         'All accuracy and loss summaries are computed from final-round evaluations, never selected by test performance.',
         'Uncertainty is the sample standard deviation across three independent data-split/training seeds; three mask evaluations within a seed are averaged, not treated as independent replicates.',
         '',f'MGT-Med exceeds raw Median in {wins}/12 dataset-attack cells by mean accuracy. Negative cells are retained.',
         '', '## Main accuracy and CE']
    for d in DATASETS:
        txt +=['',f'### {d}','Method | Attack | Accuracy (%) | CE','--- | --- | --- | ---']
        for a in ATTACKS:
            for m in METHODS:
                s=next(s for s in summaries if s['dataset']==d and s['attack']==a and s['method']==m)
                txt.append(f'{m} | {a} | {100*s["accuracy_mean"]:.3f} ± {100*s["accuracy_sd"]:.3f} | {s["ce_mean"]:.4f} ± {s["ce_sd"]:.4f}')
    txt +=['','## Method and scope notes',
        '- A client profile is fixed MCAR per coordinate and known to the server. Attacker profiles are fixed, but gradient messages are arbitrary.',
        '- The primary252fits redraw private masks at each minibatch access: a streaming/repeated-acquisition simulation. They do not model a permanently incomplete database. The separate48-fit static stress holds observed masks fixed.',
        '- None: all eleven clients are honest; the other three attacks corrupt clients 9 and 10 (zero-based).',
        '- Sign flip: each malicious raw gradient is -5 times the mean current honest raw gradient.',
        '- ALIE-style: each malicious raw gradient is mean(honest raw) + 1.5 * coordinate population-SD(honest raw). This is a specified experimental variant, not a claim of exact reproduction of an original attack implementation.',
        '- Transport-aware: each malicious raw message is its server correction d_i minus 5 times the current honest corrected-gradient mean. This attacker is granted the realized reference corrections as a deliberately stronger stress test.',
        '- FLTrust follows nonnegative cosine trust scores and server-gradient norm normalization; if their sum is zero it falls back to the reference gradient. Required per-round server reference-gradient counts are one for FLTrust/ReferenceOnly, four for transport methods, zero for raw baselines.',
        '- The StandardScaler is fit only on the complete trusted reference core and its fixed scaling statistics are shared by all methods. No complete private observation or test observation fits preprocessing. Masking is then applied to private examples.',
        '- The complete reference core has 64 labeled samples and is reused adaptively. Population fresh-core concentration statements are not claimed as guarantees for these reused-core fits.',
        '- Diagnostic reference gradients are computed even for raw baselines so paired diagnostics are available. Wall-clock values therefore include diagnostic overhead and must not be interpreted as fair algorithmic timing comparisons.',
        '- The honest dispersion is mean squared distance to the honest-gradient mean; anchor distance is Euclidean distance from the honest coordinate median to the current minibatch target-reference gradient. Both are averaged over all 160 rounds.',
        '- Baseline and proposed networks are the same tanh MLP; no pretrained representation, external images, GPU, or private benchmark data are used.',
        '- Three seeds and two small real datasets plus a synthetic benchmark are initial evidence, not a full Neural Networks acceptance-level validation.',
        '', '## Exact population counterexample',json.dumps(counter,indent=2),
        '', '## Paired accuracy changes against raw Median',json.dumps(pairs,indent=2)]
    if stress:
        txt +=['','## Domain-shift stress (20% random sample ordering, remaining samples sorted by class)',
               'Dataset | Attack | Method | Accuracy (%) | CE','--- | --- | --- | --- | ---']
        for d in ['digits','breast_cancer']:
            for a in ['none','transport_aware']:
                for m in METHODS:
                    rr=subset(stress,dataset=d,attack=a,method=m)
                    if not rr:continue
                    mu,sd=stats(rr,'test_accuracy');ce,_=stats(rr,'test_ce')
                    txt.append(f'{d} | {a} | {m} | {100*mu:.2f} ± {100*sd:.2f} | {ce:.4f}')
    txt +=['','## Fixed observed-mask stress',
           'Every private example is assigned a single independent mask at setup and that mask is reused at each access. Reference masks remain fresh; server knows the underlying generating profiles as an experimental oracle. Three paired seeds. Same64-sample reference-only standardization as the main experiment.',
           'Dataset | Attack | Method | Accuracy (%) | CE','--- | --- | --- | --- | ---']
    static_summary=[]
    for d in ['digits','breast_cancer']:
        for a in ['none','transport_aware']:
            for m in ['Median','FLTrust','ReferenceOnly','MGT-Med']:
                rr=subset(static,dataset=d,attack=a,method=m)
                if not rr:continue
                mu,sd=stats(rr,'test_accuracy');ce,_=stats(rr,'test_ce')
                txt.append(f'{d} | {a} | {m} | {100*mu:.3f} ± {100*sd:.3f} | {ce:.4f}')
                static_summary.append(dict(dataset=d,attack=a,method=m,accuracy_mean=mu,accuracy_sd=sd,ce_mean=ce))
    txt +=['','## Nested reference-budget sensitivity',
           'Digits under sign flip. A fixed128-sample reference reserve is removed from private training; reference sizes16/64/128 are nested. Every budget shares a scaler fitted to the first16 reference observations, preventing changing transformed private data. Three paired seeds. This sensitivity differs from the main reference64 scaler.',
           'Reference size | Method | Accuracy (%) | CE','--- | --- | --- | ---']
    budget_summary=[]
    for b in [16,64,128]:
        for m in ['ReferenceOnly','FLTrust','MGT-Med']:
            rr=subset(budgets,reference_size=b,method=m);mu,sd=stats(rr,'test_accuracy');ce,_=stats(rr,'test_ce')
            txt.append(f'{b} | {m} | {100*mu:.3f} ± {100*sd:.3f} | {ce:.4f}')
            budget_summary.append(dict(reference_size=b,method=m,accuracy_mean=mu,accuracy_sd=sd,ce_mean=ce))
    txt +=['','## Independent fixed-parameter diagnostic',
           'A separate8-dimensional synthetic population, three classes, hidden12,60,000 Monte Carlo target examples and12 independent replications. No diagnostic example was used for training/tuning. Same initialized parameter for all profiles;512 fresh examples per client. Population transport is an oracle comparison, not a feasible method.',
           'Reference size | Raw median error | Estimated transport error | MC population correction error | Raw dispersion | Corrected dispersion',
           '--- | --- | --- | --- | --- | ---']
    diagnostic_summary=[]
    for b in [16,64,128,512,2048,8192]:
        rr=subset(diagnostic,reference_size=b);ss={k:stats(rr,k) for k in ['raw_median_error','corrected_median_error','oracle_corrected_median_error','raw_dispersion','corrected_dispersion']}
        txt.append(str(b)+' | '+' | '.join(f'{mu:.5f} ± {sd:.5f}' for mu,sd in ss.values()))
        diagnostic_summary.append(dict(reference_size=b,**{k+'_mean':v[0] for k,v in ss.items()},**{k+'_sd':v[1] for k,v in ss.items()}))
    (ROOT/'additional_summary.json').write_text(json.dumps(dict(budget=budget_summary,diagnostic=diagnostic_summary,static=static_summary),indent=2))
    def tabfile(name,caption,label,headers,body,align):
        z=[r'\begin{table*}[t]',r'\centering',r'\small',r'\caption{'+caption+'}',r'\label{'+label+'}',
           r'\begin{tabular}{'+align+'}',r'\toprule',' & '.join(headers)+r' \\',r'\midrule']
        z+=[' & '.join(row)+r' \\' for row in body]
        z +=[r'\bottomrule',r'\end{tabular}',r'\end{table*}']
        (ROOT/name).write_text('\n'.join(z),encoding='utf-8')
    body=[]
    for d in ['digits','breast_cancer']:
        for a in ['none','transport_aware']:
            vals=[]
            for m in ['Median','FLTrust','ReferenceOnly','MGT-Med']:
                s=next(s for s in static_summary if s['dataset']==d and s['attack']==a and s['method']==m)
                vals.append(f'{100*s["accuracy_mean"]:.1f} $\\pm$ {100*s["accuracy_sd"]:.1f}')
            body.append([d.replace('_',' '),LABELS[a]]+vals)
    tabfile('generated_static_table.tex','Fixed observed-mask stress: target-mask test accuracy (\\%, mean $\\pm$ sample SD over three seeds). Private masks are held fixed for all rounds; profile probabilities are known.','tab:static',
            ['Dataset','Attack','Median','FLTrust','ReferenceOnly','MGT-Med'],body,'llrrrr')
    body=[]
    for b in [16,64,128]:
        vals=[]
        for m in ['ReferenceOnly','FLTrust','MGT-Med']:
            s=next(s for s in budget_summary if s['reference_size']==b and s['method']==m)
            vals.append(f'{100*s["accuracy_mean"]:.1f} $\\pm$ {100*s["accuracy_sd"]:.1f}')
        body.append([str(b)]+vals)
    tabfile('generated_budget_table.tex','Digits under sign-flip attack with nested trusted cores: target-mask accuracy (\\%, mean $\\pm$ sample SD over three seeds). The private pool and16-sample reference-fitted scaler are fixed across budgets.','tab:budget',
            ['Core size','ReferenceOnly','FLTrust','MGT-Med'],body,'rrrr')
    body=[]
    for s in diagnostic_summary:
        body.append([str(s['reference_size'])]+[f'{s[k+"_mean"]:.4f} $\\pm$ {s[k+"_sd"]:.4f}' for k in ['raw_median_error','corrected_median_error','oracle_corrected_median_error']])
    tabfile('generated_diagnostic_table.tex','Independent fixed-parameter gradient diagnostic: Euclidean target-gradient error (mean $\\pm$ sample SD over12 independent replications). The population-transport column uses oracle Monte Carlo correction; it is a diagnostic comparator. Sizes2048 and8192 extend the original range to characterize calibration error.','tab:diagnostic',
            ['Calibration size','Raw median','Estimated transport','MC population correction'],body,'rrrr')
    (ROOT/'report.md').write_text('\n'.join(txt),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in ('median_comparisons','counterexample')},indent=2))

if __name__=='__main__':summarize()
