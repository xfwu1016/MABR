from pathlib import Path
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='1'
import csv,json,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize

ROOT=Path(__file__).resolve().parents[1]
DATA=Path(__file__).resolve().parent
PROJ=ROOT
FIG=PROJ/'figures';TAB=PROJ/'tables'
FIG.mkdir(exist_ok=True);TAB.mkdir(exist_ok=True)
with (DATA/'grid_summary.csv').open() as f:rows=list(csv.DictReader(f))
cores=[16,32,64,128];qs=[.1,.25,.4,.6]
def cell(n,q,m):return next(r for r in rows if int(r['reference_core_size'])==n and float(r['q_low'])==q and r['method']==m)
def matrix(m,k='accuracy_mean'):return np.array([[float(cell(n,q,m)[k])*100 for n in cores] for q in qs])
Z=matrix('MGT-Med');X,Y=np.meshgrid(np.log2(cores),qs)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'pdf.fonttype':42,'svg.fonttype':'none'})
fig=plt.figure(figsize=(3.6,2.85),facecolor='white')
ax=fig.add_subplot(111,projection='3d')
ax.plot_surface(X,Y,Z,cmap='Blues',norm=Normalize(70,90),rstride=1,cstride=1,linewidth=.35,edgecolor='#ffffff',antialiased=True,shade=False,alpha=.97)
ax.scatter(X.ravel(),Y.ravel(),Z.ravel(),color='#16354a',s=7,depthshade=False,zorder=5)
ax.set_xticks(np.log2(cores),[str(n) for n in cores]);ax.set_yticks(qs,['.10','.25','.40','.60'])
ax.set_zlim(70,90);ax.set_zticks([70,80,90])
ax.set_xlabel(r'Reference core $N_0$',labelpad=4)
ax.set_ylabel(r'Observation rate $q_{\rm low}$',labelpad=4)
ax.set_zlabel('')
fig.text(.045,.62,'Accuracy (%)',rotation=90,ha='center',va='center',fontsize=8)
ax.view_init(elev=25,azim=-128);ax.set_box_aspect((1.2,1,.72));ax.grid(False)
for axis in (ax.xaxis,ax.yaxis,ax.zaxis):
    axis.pane.fill=False;axis.pane.set_edgecolor('white');axis.line.set_color('#9ba5ae')
ax.tick_params(pad=0)
fig.subplots_adjust(left=.14,right=.99,bottom=.12,top=.98)
fig.savefig(FIG/'joint_sensitivity_3d.pdf')
fig.savefig(FIG/'joint_sensitivity_3d.png',dpi=300)
plt.close(fig)
# A flat counterpart permits unoccluded exact comparison; all methods retained.
fig,axes=plt.subplots(1,3,figsize=(7.1,2.2),layout='constrained',sharey=True)
norm=Normalize(60,90)
for ax,m in zip(axes,['Median','FLTrust','MGT-Med']):
    zz=matrix(m)
    im=ax.imshow(zz,origin='lower',aspect='auto',cmap='viridis',norm=norm,interpolation='nearest')
    ax.set_xticks(range(4),cores);ax.set_yticks(range(4),['.10','.25','.40','.60'])
    ax.set_xlabel(r'Reference core $N_0$');ax.set_title(m,fontsize=9)
    for i in range(4):
        for j in range(4):ax.text(j,i,f'{zz[i,j]:.1f}',ha='center',va='center',fontsize=7,color='white' if zz[i,j]<77 else '#17212a')
axes[0].set_ylabel(r'Low-group rate $q_{\rm low}$')
fig.colorbar(im,ax=axes,label='Target-mask accuracy (%)',fraction=.025,pad=.025)
fig.savefig(FIG/'joint_sensitivity_2d.pdf');fig.savefig(FIG/'joint_sensitivity_2d.png',dpi=220)
plt.close(fig)
lines=[r'\begin{table*}[t]',r'\centering',r'\small',r'\caption{Two-factor static-mask sensitivity on Digits under the transport-aware attack. Entries are final accuracy in percent (mean $\pm$ sample SD over three paired seeds). $N_0$ counts distinct core examples; every round uses $b_0=64$ reference draws with replacement. Complete protocol is given in Section~\ref{subsec:joint-sensitivity}.}',r'\label{tab:joint-grid}',r'\begin{tabular}{rrrrr}',r'\toprule',r'$N_0$ & $q_{\rm low}$ & Median & FLTrust & MGT--Med\\',r'\midrule']
for n in cores:
    for q in qs:
        cells=[]
        for m in ['Median','FLTrust','MGT-Med']:
            r=cell(n,q,m);cells.append(f"{100*float(r['accuracy_mean']):.2f} $\\pm$ {100*float(r['accuracy_sd']):.2f}")
        lines.append(f'{n} & {q:.2f} & '+' & '.join(cells)+r'\\')
    if n!=cores[-1]:lines.append(r'\addlinespace')
lines +=[r'\bottomrule',r'\end{tabular}',r'\end{table*}']
(TAB/'joint_grid.tex').write_text('\n'.join(lines),encoding='utf-8')
manifest=dict(source='grid_summary.csv',source_sha256=hashlib.sha256((DATA/'grid_summary.csv').read_bytes()).hexdigest(),
              x='distinct reference core size N0, log2 positions labelled as actual counts',y='generating observation probability of first four clients',
              z='MGT-Med final target-mask accuracy percent, arithmetic mean over three paired seeds',
              uncertainty='SD not drawn on 3D surface; complete SD in flat table and CSV',
              surface='16 measured grid points; planar visual faces between grid nodes; no smoothing, fitted response surface, extra synthetic observations, or unmeasured node values',
              common_3d_z_limits=[70,90],main_cmap='Blues',n_runs=144,n_seed=3)
(DATA/'figure_provenance.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print('Plotted measured 4x4 surface and flat comparator map.')
