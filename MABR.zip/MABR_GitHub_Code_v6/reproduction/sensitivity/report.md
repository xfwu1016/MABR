# Joint reference-core / observation-rate sensitivity

Completed 144 grid fits and six no-attack invariance-control fits.
The 4 by 4 grid is predefined, not selected from test results. All three methods and all seed-level records are retained.
Target: Digits, static private masks, transport-aware messages, 11 clients, 2 Byzantine clients, oracle profiles, 160 rounds, 24 hidden units, and SGD step size 0.15.
Reference core size N0 varies over 16, 32, 64, and 128; the per-round reference minibatch b0 remains 64 and is resampled with replacement.
Four low-observation clients use q_low = 0.10, 0.25, 0.40, or 0.60. Three other clients have rate 0.60 and four have rate 0.90; the target rate is 0.65.
A fixed 128-example reserve is excluded from the same private pool. Every budget shares scaling fitted to the first 16 reference examples.
Uncertainty is sample SD across 3 paired data-split/training seeds. Within-seed target-mask draws are averaged.

Proposed method mean accuracy range: [76.99588477366254, 83.33333333333334].
MGT-Med improves raw Median mean accuracy in 12/16 cells, and FLTrust in 5/16 cells.

## Full aggregate table
N0 | q_low | Method | Accuracy% mean±SD | CE mean±SD | Difference vs Median(pp) | Difference vs FLTrust(pp)
--- | --- | --- | --- | --- | --- | ---
16 | 0.10 | MGT-Med | 76.996 ± 1.168 | 0.7940 ± 0.0373 | 3.765 | -0.658
16 | 0.10 | Median | 73.230 ± 3.815 | 1.0018 ± 0.0939 | 0.000 | -4.424
16 | 0.10 | FLTrust | 77.654 ± 9.701 | 0.7302 ± 0.2435 | 4.424 | 0.000
16 | 0.25 | MGT-Med | 80.453 ± 0.899 | 0.7095 ± 0.0296 | 0.988 | 3.683
16 | 0.25 | Median | 79.465 ± 2.268 | 0.7767 ± 0.0603 | 0.000 | 2.695
16 | 0.25 | FLTrust | 76.770 ± 12.078 | 0.7393 ± 0.3148 | -2.695 | 0.000
16 | 0.40 | MGT-Med | 81.461 ± 0.731 | 0.6979 ± 0.0339 | 0.267 | 8.045
16 | 0.40 | Median | 81.193 ± 0.935 | 0.7157 ± 0.0500 | 0.000 | 7.778
16 | 0.40 | FLTrust | 73.416 ± 19.482 | 0.9031 ± 0.6252 | -7.778 | 0.000
16 | 0.60 | MGT-Med | 81.770 ± 1.695 | 0.6895 ± 0.0435 | -0.370 | 11.029
16 | 0.60 | Median | 82.140 ± 0.943 | 0.6772 ± 0.0357 | 0.000 | 11.399
16 | 0.60 | FLTrust | 70.741 ± 21.593 | 1.1175 ± 0.8747 | -11.399 | 0.000
32 | 0.10 | MGT-Med | 78.683 ± 0.840 | 0.7366 ± 0.0335 | 5.597 | -4.362
32 | 0.10 | Median | 73.086 ± 3.529 | 1.0014 ± 0.0931 | 0.000 | -9.959
32 | 0.10 | FLTrust | 83.045 ± 1.327 | 0.5924 ± 0.0249 | 9.959 | 0.000
32 | 0.25 | MGT-Med | 81.605 ± 0.913 | 0.6842 ± 0.0274 | 2.449 | -1.152
32 | 0.25 | Median | 79.156 ± 2.200 | 0.7783 ± 0.0624 | 0.000 | -3.601
32 | 0.25 | FLTrust | 82.757 ± 2.715 | 0.5812 ± 0.0440 | 3.601 | 0.000
32 | 0.40 | MGT-Med | 82.428 ± 0.874 | 0.6804 ± 0.0250 | 1.193 | 1.091
32 | 0.40 | Median | 81.235 ± 0.950 | 0.7166 ± 0.0478 | 0.000 | -0.103
32 | 0.40 | FLTrust | 81.337 ± 5.168 | 0.6089 ± 0.1213 | 0.103 | 0.000
32 | 0.60 | MGT-Med | 82.058 ± 1.155 | 0.6842 ± 0.0365 | -0.123 | 1.872
32 | 0.60 | Median | 82.181 ± 1.147 | 0.6784 ± 0.0332 | 0.000 | 1.996
32 | 0.60 | FLTrust | 80.185 ± 6.529 | 0.6667 ± 0.1820 | -1.996 | 0.000
64 | 0.10 | MGT-Med | 82.551 ± 0.411 | 0.6528 ± 0.0348 | 9.486 | -1.049
64 | 0.10 | Median | 73.066 ± 3.778 | 1.0173 ± 0.0956 | 0.000 | -10.535
64 | 0.10 | FLTrust | 83.601 ± 0.838 | 0.5888 ± 0.0241 | 10.535 | 0.000
64 | 0.25 | MGT-Med | 82.963 ± 0.482 | 0.6498 ± 0.0356 | 3.457 | -1.111
64 | 0.25 | Median | 79.506 ± 2.382 | 0.7810 ± 0.0643 | 0.000 | -4.568
64 | 0.25 | FLTrust | 84.074 ± 0.163 | 0.5688 ± 0.0273 | 4.568 | 0.000
64 | 0.40 | MGT-Med | 82.984 ± 0.143 | 0.6610 ± 0.0348 | 1.790 | -1.708
64 | 0.40 | Median | 81.193 ± 1.155 | 0.7130 ± 0.0493 | 0.000 | -3.498
64 | 0.40 | FLTrust | 84.691 ± 0.385 | 0.5555 ± 0.0225 | 3.498 | 0.000
64 | 0.60 | MGT-Med | 81.852 ± 1.133 | 0.6824 ± 0.0408 | -0.329 | -2.819
64 | 0.60 | Median | 82.181 ± 0.981 | 0.6768 ± 0.0382 | 0.000 | -2.490
64 | 0.60 | FLTrust | 84.671 ± 0.539 | 0.5403 ± 0.0194 | 2.490 | 0.000
128 | 0.10 | MGT-Med | 83.333 ± 1.173 | 0.6365 ± 0.0445 | 10.329 | -0.514
128 | 0.10 | Median | 73.004 ± 3.673 | 1.0176 ± 0.0944 | 0.000 | -10.844
128 | 0.10 | FLTrust | 83.848 ± 1.515 | 0.6034 ± 0.0370 | 10.844 | 0.000
128 | 0.25 | MGT-Med | 83.251 ± 0.899 | 0.6466 ± 0.0471 | 3.868 | -0.782
128 | 0.25 | Median | 79.383 ± 1.902 | 0.7842 ± 0.0617 | 0.000 | -4.650
128 | 0.25 | FLTrust | 84.033 ± 1.194 | 0.5873 ± 0.0411 | 4.650 | 0.000
128 | 0.40 | MGT-Med | 83.128 ± 0.702 | 0.6632 ± 0.0452 | 2.099 | -1.317
128 | 0.40 | Median | 81.029 ± 0.843 | 0.7169 ± 0.0497 | 0.000 | -3.416
128 | 0.40 | FLTrust | 84.444 ± 0.687 | 0.5701 ± 0.0396 | 3.416 | 0.000
128 | 0.60 | MGT-Med | 81.955 ± 1.125 | 0.6828 ± 0.0417 | -0.267 | -2.881
128 | 0.60 | Median | 82.222 ± 1.354 | 0.6771 ± 0.0400 | 0.000 | -2.613
128 | 0.60 | FLTrust | 84.835 ± 0.929 | 0.5550 ± 0.0386 | 2.613 | 0.000

## Interpretation limits
- The new sensitivity is a static-mask stress protocol. It differs from the original main streaming-mask study and the earlier sign-flip budget sensitivity.
- q_low is an enrolled observation probability for one client group, not a universal scalar measure of non-IID heterogeneity.
- N0 is not b0. Increasing a fixed core can improve reference representation without increasing the per-round reference batch.
- Raw Median can vary with N0 under the transport-aware attack, since the raw adversarial vectors themselves depend on the server correction.
- A no-attack control confirms exact Median parameter identity across N0 = 16 and 128 when the private pool and scaling are held fixed.
- This is one dataset and one strong message-level attack with 3 seeds; do not claim universal superiority or a significance result.
- The resulting grid supports a measured-node surface or 3D bars. Any interpolation between cells is only a visual guide, not measured data.