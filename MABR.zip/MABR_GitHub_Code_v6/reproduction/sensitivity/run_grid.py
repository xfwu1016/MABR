"""Predefined missingness x trusted-core sensitivity, reusing unchanged MLP code.

This script writes only beside itself. It neither edits the base experiment
implementation nor tunes parameters from test measurements.
"""
import os
for name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[name]='1'
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import csv,json,hashlib,platform

ROOT=Path(__file__).resolve().parent
# Support both the working layout and a sensitivity/ subfolder inside the
# delivered reproduction directory.
BASE=next(p for p in [ROOT.parent.parent/'experiments'/'run_experiments.py',
                     ROOT.parent/'run_experiments.py',
                     ROOT/'run_experiments_base.py'] if p.exists())
sys.path.insert(0,str(BASE.parent))
import numpy as np
import scipy, sklearn
from run_experiments import run,prepare,gradient_check,CONFIG

BUDGETS=[16,32,64,128]
LOW=[.10,.25,.40,.60]
METHODS=['MGT-Med','Median','FLTrust']
SEEDS=[0,1,2]

def write_rows(p,rows):
    if not rows:return
    with p.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def append_rows(p,rows):
    if not rows:return
    exists=p.exists()
    with p.open('a',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]))
        if not exists:w.writeheader()
        w.writerows(rows)

def load(p):
    if not p.exists():return []
    with p.open(encoding='utf-8') as f:return list(csv.DictReader(f))

def main():
    ROOT.mkdir(exist_ok=True,parents=True)
    initial_hash=hashlib.sha256(BASE.read_bytes()).hexdigest()
    config=dict(dataset='digits',reference_core_sizes=BUDGETS,
        low_group_observation_probabilities=LOW,methods=METHODS,seeds=SEEDS,
        profiles='[q_low]*4 + [0.60]*3 + [0.90]*4',target_observation_probability=.65,
        n_clients=11,n_byzantine=2,byzantine_ids_zero_based=[9,10],attack='transport_aware',
        static_private_masks=True,rounds=160,learning_rate=.15,hidden=24,
        client_batch=32,reference_minibatch_b0=64,sampling_reference='with replacement',
        fixed_reference_reserve=128,scaler_fit_on_first_reference_examples=16,
        fixed_private_pool_across_budgets=True,known_generating_mask_profiles=True,
        baseline_anchor_dependency='Transport-aware raw attack depends on the current reference correction for ALL methods, including raw Median.',
        evaluation='Final-round accuracy and CE averaged over3 paired target masks per seed; seed means and sample SD.',
        no_test_tuning=True,base_source=str(BASE),base_source_sha256=initial_hash,
        exact_naming='N0 is stored trusted-core size. b0=64 is per-round resampling batch size, distinct from N0.')
    (ROOT/'grid_config.json').write_text(json.dumps(config,indent=2),encoding='utf-8')
    check=gradient_check()
    rows=load(ROOT/'grid_runs.csv')
    done={(int(r['seed']),int(r['reference_core_size']),float(r['q_low']),r['method']) for r in rows}
    count=0;expected=len(BUDGETS)*len(LOW)*len(METHODS)*len(SEEDS)
    metadata={}
    # Reconstruct metadata even on a resumed run with no pending training jobs.
    for seed in SEEDS:
        for budget in BUDGETS:
            _,_,_,meta=prepare('digits',seed,reference_size=budget,core_pool=128,scaler_subset=16)
            for low in LOW:metadata[f'{seed}:{budget}:{low}']=meta
    for seed in SEEDS:
        for budget in BUDGETS:
            for low in LOW:
                profiles=[low]*4+[.6]*3+[.9]*4
                for method in METHODS:
                    key=(seed,budget,low,method)
                    if key in done:continue
                    row,curves,meta=run('digits',seed,'transport_aware',method,
                        reference_size=budget,core_pool=128,scaler_subset=16,
                        profiles_override=profiles,static_masks=True)
                    row.update(reference_core_size=budget,q_low=low,reference_minibatch_b0=64,scaler_reference_size=16)
                    for c in curves:c.update(reference_core_size=budget,q_low=low,reference_minibatch_b0=64)
                    append_rows(ROOT/'grid_runs.csv',[row]);append_rows(ROOT/'grid_curves.csv',curves)
                    count+=1
                    metadata[f'{seed}:{budget}:{low}']=meta
                    print(f'{count}/{expected-len(done)} seed={seed} N0={budget} qlow={low} {method}: accuracy={100*row["test_accuracy"]:.3f}% CE={row["test_ce"]:.4f}',flush=True)
    rows=load(ROOT/'grid_runs.csv')
    def select(**kw):return [r for r in rows if all(str(r[k])==str(v) for k,v in kw.items())]
    summaries=[]
    for budget in BUDGETS:
        for low in LOW:
            for method in METHODS:
                rr=select(reference_core_size=budget,q_low=low,method=method)
                assert sorted(int(r['seed']) for r in rr)==SEEDS
                acc=np.array([float(r['test_accuracy']) for r in rr]);ce=np.array([float(r['test_ce']) for r in rr])
                s=dict(reference_core_size=budget,q_low=low,method=method,n_seeds=len(rr),
                       accuracy_mean=acc.mean(),accuracy_sd=acc.std(ddof=1),
                       ce_mean=ce.mean(),ce_sd=ce.std(ddof=1))
                for other in ['Median','FLTrust']:
                    other_rows=select(reference_core_size=budget,q_low=low,method=other)
                    byseed={int(r['seed']):float(r['test_accuracy']) for r in other_rows}
                    dif=np.array([float(r['test_accuracy'])-byseed[int(r['seed'])] for r in rr])
                    s[f'difference_vs_{other}_pp_mean']=100*dif.mean()
                    s[f'difference_vs_{other}_pp_sd']=100*dif.std(ddof=1)
                summaries.append(s)
    write_rows(ROOT/'grid_summary.csv',summaries)
    # These additional controls isolate core invariance from the attack's
    # deliberate dependence on reference corrections.
    controls=[]
    for seed in SEEDS:
        a,_,_=run('digits',seed,'none','Median',reference_size=16,core_pool=128,
                  scaler_subset=16,profiles_override=CONFIG['profiles'],static_masks=True)
        b,_,_=run('digits',seed,'none','Median',reference_size=128,core_pool=128,
                  scaler_subset=16,profiles_override=CONFIG['profiles'],static_masks=True)
        controls.append(dict(seed=seed,attack='none',method='Median',budgets=[16,128],
            exact_parameter_hash_identity=a['parameter_sha256']==b['parameter_sha256'],
            accuracy_identity=a['test_accuracy']==b['test_accuracy'],
            hash16=a['parameter_sha256'],hash128=b['parameter_sha256']))
    assert all(x['exact_parameter_hash_identity'] for x in controls)
    # Reconstruct actual source indices for each seed to validate split semantics.
    from sklearn.datasets import load_digits
    from sklearn.model_selection import train_test_split
    ds=load_digits();split_checks=[]
    for seed in SEEDS:
        ii=np.arange(len(ds.target))
        pool,test=train_test_split(ii,test_size=.3,stratify=ds.target,random_state=100+seed)
        private,core=train_test_split(pool,test_size=128,stratify=ds.target[pool],random_state=200+seed)
        assert len(set(private)&set(core))==len(set(private)&set(test))==len(set(core)&set(test))==0
        split_checks.append(dict(seed=seed,private=len(private),reference_reserve=len(core),test=len(test),disjoint=True))
    keys={(int(r['seed']),int(r['reference_core_size']),float(r['q_low']),r['method']) for r in rows}
    finite=all(np.isfinite(float(r['test_accuracy'])) and np.isfinite(float(r['test_ce'])) for r in rows)
    assert len(rows)==len(keys)==expected and finite
    final_hash=hashlib.sha256(BASE.read_bytes()).hexdigest()
    assert final_hash==initial_hash
    proposed=[s for s in summaries if s['method']=='MGT-Med']
    report=dict(main_grid_training_fits=len(rows),expected_grid_fits=expected,
        additional_no_attack_control_fits=6,complete_unique_keys=len(keys)==expected,
        all_metrics_finite=finite,base_source_unchanged=final_hash==initial_hash,
        base_source_sha256=final_hash,gradient_check=check,split_checks=split_checks,
        no_attack_median_core_invariance=controls,
        main_attack_median_invariance_not_required='Raw transport-aware adversarial messages change when the reference correction changes. This is intended attack access, not a test failure.',
        proposed_mean_accuracy_range_percent=[float(100*min(s['accuracy_mean'] for s in proposed)),float(100*max(s['accuracy_mean'] for s in proposed))],
        positive_mean_cells_vs_median=int(sum(s['difference_vs_Median_pp_mean']>0 for s in proposed)),
        positive_mean_cells_vs_fltrust=int(sum(s['difference_vs_FLTrust_pp_mean']>0 for s in proposed)),
        n_grid_cells=len(proposed),
        raw_csv_sha256=hashlib.sha256((ROOT/'grid_runs.csv').read_bytes()).hexdigest(),
        environment=dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__,platform=platform.platform()))
    (ROOT/'integrity.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    (ROOT/'grid_data_allocation.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
    txt=['# Joint reference-core / observation-rate sensitivity','',
         f'Completed {len(rows)} grid fits and six no-attack invariance-control fits.',
         'The 4 by 4 grid is predefined, not selected from test results. All three methods and all seed-level records are retained.',
         'Target: Digits, static private masks, transport-aware messages, 11 clients, 2 Byzantine clients, oracle profiles, 160 rounds, 24 hidden units, and SGD step size 0.15.',
         'Reference core size N0 varies over 16, 32, 64, and 128; the per-round reference minibatch b0 remains 64 and is resampled with replacement.',
         'Four low-observation clients use q_low = 0.10, 0.25, 0.40, or 0.60. Three other clients have rate 0.60 and four have rate 0.90; the target rate is 0.65.',
         'A fixed 128-example reserve is excluded from the same private pool. Every budget shares scaling fitted to the first 16 reference examples.',
         'Uncertainty is sample SD across 3 paired data-split/training seeds. Within-seed target-mask draws are averaged.',
         '',f'Proposed method mean accuracy range: {report["proposed_mean_accuracy_range_percent"]}.',
         f'MGT-Med improves raw Median mean accuracy in {report["positive_mean_cells_vs_median"]}/16 cells, and FLTrust in {report["positive_mean_cells_vs_fltrust"]}/16 cells.',
         '', '## Full aggregate table',
         'N0 | q_low | Method | Accuracy% mean±SD | CE mean±SD | Difference vs Median(pp) | Difference vs FLTrust(pp)',
         '--- | --- | --- | --- | --- | --- | ---']
    for s in summaries:
        txt.append(f'{s["reference_core_size"]} | {s["q_low"]:.2f} | {s["method"]} | {100*s["accuracy_mean"]:.3f} ± {100*s["accuracy_sd"]:.3f} | {s["ce_mean"]:.4f} ± {s["ce_sd"]:.4f} | {s["difference_vs_Median_pp_mean"]:.3f} | {s["difference_vs_FLTrust_pp_mean"]:.3f}')
    txt +=['','## Interpretation limits',
            '- The new sensitivity is a static-mask stress protocol. It differs from the original main streaming-mask study and the earlier sign-flip budget sensitivity.',
            '- q_low is an enrolled observation probability for one client group, not a universal scalar measure of non-IID heterogeneity.',
            '- N0 is not b0. Increasing a fixed core can improve reference representation without increasing the per-round reference batch.',
            '- Raw Median can vary with N0 under the transport-aware attack, since the raw adversarial vectors themselves depend on the server correction.',
            '- A no-attack control confirms exact Median parameter identity across N0 = 16 and 128 when the private pool and scaling are held fixed.',
            '- This is one dataset and one strong message-level attack with 3 seeds; do not claim universal superiority or a significance result.',
            '- The resulting grid supports a measured-node surface or 3D bars. Any interpolation between cells is only a visual guide, not measured data.']
    (ROOT/'report.md').write_text('\n'.join(txt),encoding='utf-8')
    print(json.dumps({k:report[k] for k in ['main_grid_training_fits','all_metrics_finite','base_source_unchanged','proposed_mean_accuracy_range_percent','positive_mean_cells_vs_median','positive_mean_cells_vs_fltrust']},indent=2),flush=True)

if __name__=='__main__':main()
