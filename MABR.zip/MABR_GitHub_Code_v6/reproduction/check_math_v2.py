"""Independent deterministic sanity checks for the integrated v1 theory.

These checks do not replace the proofs or verify statistical assumptions in data.
"""
import json
from pathlib import Path
import numpy as np
import sys,itertools,importlib.util

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
rng=np.random.default_rng(20261029)

identity=0.
for k in range(1000):
    mu_i,mu_0i,mu_0star=rng.normal(size=(3,17))
    D=mu_0i-mu_0star;Delta=mu_i-mu_0i
    identity=max(identity,float(np.max(np.abs((mu_i-D)-(mu_0star+Delta)))))

median_violation=-float('inf');median_cases=0
for n in range(2,21):
    for f in range((n-1)//2+1):
        for k in range(20):
            center=rng.normal(size=17)
            honest=center+rng.uniform(-1,1,size=(n-f,17))*rng.uniform(.001,3,size=17)
            bad=rng.normal(scale=1000,size=(f,17))
            reports=np.vstack((honest,bad))
            radius=np.max(np.abs(honest-center),axis=0)
            err=np.abs(np.median(reports,axis=0)-center)
            median_violation=max(median_violation,float(np.max(err-radius)))
            median_cases+=1

descent_violation=-float('inf')
for k in range(2000):
    A=rng.normal(size=(7,7));H=A.T@A
    L=np.linalg.eigvalsh(H).max()
    theta=rng.normal(size=7);error=rng.normal(size=7)
    eta=rng.uniform(.001,1)/L
    g=H@theta;v=g+error;next_theta=theta-eta*v
    F=.5*theta@H@theta;Fn=.5*next_theta@H@next_theta
    bound=F-.5*eta*np.dot(g,g)+.5*eta*np.dot(error,error)
    descent_violation=max(descent_violation,float(Fn-bound))

q=np.array([.95,.2]);target=np.array([.65,.65])
H=lambda a:np.array([[a[0],a.prod()],[a.prod(),a[1]]])
w=np.linalg.solve(H(q),q);wt=np.linalg.solve(H(target),target)
closed=np.array([(1-q[1])/(1-q.prod()),(1-q[0])/(1-q.prod())])
excess=.5*(w-wt)@H(target)@(w-wt)
errtransport=0.
for theta in rng.normal(size=(1000,2)):
    raw=H(q)@theta-q
    difference=(H(q)-H(target))@theta-(q-target)
    errtransport=max(errtransport,float(np.max(np.abs(raw-difference-(H(target)@theta-target)))))

sys.dont_write_bytecode=True
module_path=Path(__file__).resolve().parent/'run_experiments.py'
spec=importlib.util.spec_from_file_location('checked_mgt_implementation',module_path)
impl=importlib.util.module_from_spec(spec);spec.loader.exec_module(impl)
net=impl.MLP(4,3,5)
x=rng.normal(size=(7,4));y=rng.integers(0,3,size=7)
theta=net.initialize(rng)+.2*x.mean()
W,b,V,a=net.unpack(theta)
R0=max(1.,float(np.abs(x).max()))
Gt=max(1.,R0*float(np.abs(V).sum(axis=1).max()))
actual=0.
for mask in itertools.product([0,1],repeat=4):
    for k in range(len(x)):
        grad=net.loss_grad(theta,x[k:k+1],y[k:k+1],np.array(mask)[None,:])[1]
        actual=max(actual,float(np.abs(grad).max()))

report={
    'population_identity_max_abs_residual':identity,
    'median_even_and_odd_cases':median_cases,
    'median_max_bound_violation':median_violation,
    'smooth_descent_cases':2000,
    'smooth_descent_max_bound_violation':descent_violation,
    'local_minimizer':w.tolist(),'target_minimizer':wt.tolist(),
    'closed_form_minimizer_abs_residual':float(np.max(np.abs(w-closed))),
    'exact_target_excess_risk':float(excess),
    'toy_transport_max_abs_residual':errtransport,
    'finite_core_predictable_gradient_bound':Gt,
    'largest_coordinate_gradient_all_16_masks_7_core_points':actual,
    'finite_core_gradient_envelope_valid':actual<=Gt+1e-12,
    'scope':'Deterministic numerical sanity checks; not proof or validation of fresh-sample/gradient-bound/Lipschitz assumptions.'}
assert identity<1e-12
assert median_violation<1e-12
assert descent_violation<1e-12
assert abs(excess-.055862119133724034)<1e-12
assert errtransport<1e-12
assert actual<=Gt+1e-12
(OUT/'math_checks_v2.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
