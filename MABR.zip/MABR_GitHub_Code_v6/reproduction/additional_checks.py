import os
for name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):
    os.environ[name]='1'
import json,csv,hashlib
from pathlib import Path
import numpy as np
from run_experiments import run,MLP,CONFIG,append_csv
ROOT=Path(__file__).resolve().parent

def checks():
    rows=[]
    # Identical profiles force every paired-mask transport difference to zero.
    a,_,_=run('digits',0,'signflip','Median',rounds=30,profiles_override=[.65]*11)
    b,_,_=run('digits',0,'signflip','MGT-Med',rounds=30,profiles_override=[.65]*11)
    identical=a['parameter_sha256']==b['parameter_sha256']
    report=dict(homogeneous_masks_exact_parameter_identity=identical,
                median_parameter_sha256=a['parameter_sha256'],mgt_parameter_sha256=b['parameter_sha256'],
                accuracy_equal=a['test_accuracy']==b['test_accuracy'],rounds=30,seed=0,attack='signflip')
    if not identical:raise AssertionError(report)
    (ROOT/'homogeneous_identity.json').write_text(json.dumps(report,indent=2))
    result=ROOT/'budget_runs.csv';curves=ROOT/'budget_curves.csv'
    existing=[]
    if result.exists():
        with result.open() as f:existing=list(csv.DictReader(f))
    done={(int(r['seed']),int(r['reference_size']),r['method']) for r in existing}
    for seed in [0,1,2]:
        for budget in [16,64,128]:
            for method in ['ReferenceOnly','MGT-Med','FLTrust']:
                if (seed,budget,method) in done:continue
                row,cs,meta=run('digits',seed,'signflip',method,reference_size=budget,core_pool=128,scaler_subset=16)
                row['reference_size']=budget;row['scaler_reference_size']=16
                for c in cs:c['reference_size']=budget
                append_csv(result,[row]);append_csv(curves,cs)
                print(f'budget seed{seed} nref{budget} {method}: {row["test_accuracy"]:.4f}',flush=True)
    # Fixed-parameter mechanistic diagnostic. Its independent synthetic population
    # never enters training, hyperparameter choice, or checkpoint selection.
    r=np.random.default_rng(1977);dim=8;c=3;net=MLP(dim,c,12)
    theta=net.initialize(np.random.default_rng(1919));qstar=.65
    coeff=np.random.default_rng(1821).normal(size=(dim,c))
    def sample(n,rng):
        x=rng.normal(size=(n,dim));x[:,1]=.7*x[:,0]+np.sqrt(.51)*x[:,1]
        logits=x@coeff+.4*np.stack((x[:,0]*x[:,2],-x[:,0]*x[:,2],x[:,3]**2-1),axis=1)
        logits+=rng.normal(scale=.8,size=(n,c))
        return x,np.argmax(logits,axis=1)
    xpop,ypop=sample(60000,r)
    # Independent Monte Carlo population gradients under each profile, with
    # common data/masks to reduce the diagnostic's comparison variance.
    U=r.random(xpop.shape)
    population={q:net.loss_grad(theta,xpop,ypop,U<q)[1] for q in [.25,.6,.65,.9]}
    target=population[qstar]
    for seed in range(12):
        rr=np.random.default_rng(7120+seed)
        # Independent client observations approximate current private gradients.
        raw=[]
        for q in CONFIG['profiles']:
            xx,yy=sample(512,rr);mm=rr.random(xx.shape)<q
            raw.append(net.loss_grad(theta,xx,yy,mm)[1])
        raw=np.stack(raw)
        core_x,core_y=sample(8192,rr);core_u=rr.random(core_x.shape)
        for budget in [16,64,128,512,2048,8192]:
            anchors={q:net.loss_grad(theta,core_x[:budget],core_y[:budget],core_u[:budget]<q)[1] for q in [.25,.6,.65,.9]}
            D=np.stack([anchors[q]-anchors[qstar] for q in CONFIG['profiles']])
            corrected=raw-D
            exact=np.stack([population[q]-target for q in CONFIG['profiles']])
            rows.append(dict(seed=seed,reference_size=budget,
                raw_mean_error=float(np.linalg.norm(raw.mean(axis=0)-target)),
                corrected_mean_error=float(np.linalg.norm(corrected.mean(axis=0)-target)),
                raw_median_error=float(np.linalg.norm(np.median(raw,axis=0)-target)),
                corrected_median_error=float(np.linalg.norm(np.median(corrected,axis=0)-target)),
                oracle_corrected_median_error=float(np.linalg.norm(np.median(raw-exact,axis=0)-target)),
                raw_dispersion=float(np.mean(np.sum((raw-raw.mean(axis=0))**2,axis=1))),
                corrected_dispersion=float(np.mean(np.sum((corrected-corrected.mean(axis=0))**2,axis=1)))))
    with (ROOT/'fixed_theta_diagnostic.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (ROOT/'additional_protocol.json').write_text(json.dumps(dict(
        fixed_theta=dict(seed_parameter=1919,teacher_seed=1821,population_seed=1977,
                         population_size=60000,features=8,classes=3,hidden=12,
                         private_gradient_samples_per_client=512,replicates=12,
                         reference_sizes=[16,64,128,512,2048,8192],reference_and_clients_independent=True,
                         role='posthoc mechanistic diagnostic; not training or tuning'),
        budget=dict(dataset='digits',seeds=[0,1,2],attack='signflip',core_pool=128,
                    nested_sizes=[16,64,128],standardization_core=16,
                    private_pool_fixed_across_budgets=True,methods=['ReferenceOnly','MGT-Med','FLTrust'],
                    note='All budgets share scaling fitted to the first 16 core samples, so transformed private observations are fixed. This controlled sensitivity differs from the main scaler fitted to all 64 core samples.')
    ),indent=2))
    print(json.dumps(report,indent=2),flush=True)

if __name__=='__main__':checks()
