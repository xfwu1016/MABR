"""Bounded, fully retained post-review schedule/width sensitivity grid.

No test-based parameter selection: all 180 fits and both 160/320 checkpoints are
reported. Primary default (.15, width24, 160 rounds) remains unchanged.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key]='1'
from concurrent.futures import ProcessPoolExecutor,as_completed
import csv,hashlib,json,platform,sys,time
from pathlib import Path
import numpy as np
import pandas as pd
from run_comparison import base
from author_methods import fltrust_update,root_cone_attack,predict_metrics

HERE=Path(__file__).resolve().parent
OUT=HERE/'sensitivity';OUT.mkdir(exist_ok=True)
METHODS=['Median','FLTrust','FLTrust-CM','MGT-Med','TransportFLTrust']
ATKS=['signflip','root_aligned']
LRS=[.05,.15,.30];HIDDEN=[12,48];SEEDS=[0,1,2]
PROTOCOL=dict(dataset='digits',seeds=SEEDS,methods=METHODS,attacks=ATKS,
              learning_rates=LRS,hidden_widths=HIDDEN,rounds=320,reported_checkpoints=[160,320],
              reference_size=64,reference_batch=64,private_batch=32,n_clients=11,n_byzantine=2,
              purpose='post-review fixed-schedule and width sensitivity; all cells retained, no test selection or replacement of main default',
              FLTrust_numerics='official author-code eps1e-9 at both norms and weight sum; zero-total-score update zero',
              root_cone_knowledge='current actual aggregator root including full CM averaged anchor; omniscient honest reports; no test inputs/labels',
              data_protocol='same prepare and split as primary paired comparison; complete-core StandardScaler; streaming MCAR private mask each access; three fixed test masks at q=.65',
              seed_unit='paired split/initialization/sampling realizations; overlaps in source dataset, not independent populations')

def run_one(job):
    seed,attack,method,lr,hidden=job
    clients,ref,test,meta=base.prepare('digits',seed)
    net=base.MLP(meta['features'],meta['classes'],hidden)
    theta=net.initialize(np.random.default_rng(500+seed))
    rng=np.random.default_rng(600+seed);extra_rng=np.random.default_rng(1600+seed)
    profiles=np.array([.25]*4+[.6]*3+[.9]*4);unique=np.unique(np.r_[profiles,.65])
    zero_rounds=0;weights=[];badcos=[];rows=[];start=time.perf_counter()
    for step in range(320):
        rid=rng.integers(0,len(ref[1]),64);rx,ry=ref[0][rid],ref[1][rid];U=rng.random(rx.shape)
        anchors={float(p):net.loss_grad(theta,rx,ry,U<p)[1] for p in unique}
        a=anchors[.65];D=np.stack([anchors[float(p)]-a for p in profiles])
        raw=[]
        for i,(x,y) in enumerate(clients):
            ids=rng.integers(0,len(y),32);mask=rng.random((32,meta['features']))<profiles[i]
            raw.append(net.loss_grad(theta,x[ids],y[ids],mask)[1])
        G=np.stack(raw);anchor=a
        if method=='FLTrust-CM':
            extra=[]
            for _ in range(3):
                ei=extra_rng.integers(0,len(ref[1]),64);eu=extra_rng.random((64,meta['features']))
                extra.append(net.loss_grad(theta,ref[0][ei],ref[1][ei],eu<.65)[1])
            anchor=(a+np.sum(extra,axis=0))/4.
        H=G[:9]
        if attack=='signflip':G[9:]=-5.*H.mean(axis=0)
        elif attack=='root_aligned':
            G[9:],detail=root_cone_attack(H,anchor,(H-D[:9]).mean(axis=0),2,5.)
            badcos.append(detail['cosine'])
        else:raise ValueError(attack)
        C=G-D
        if method in ('FLTrust','FLTrust-CM','TransportFLTrust'):
            update,info=fltrust_update(C if method=='TransportFLTrust' else G,anchor)
            zero_rounds+=info['fallback'];scores=info['scores']
            weights.append(float(scores[9:].sum()/max(scores.sum(),1e-15)))
        elif method=='Median':update=np.median(G,axis=0)
        elif method=='MGT-Med':update=np.median(C,axis=0)
        else:raise ValueError(method)
        theta-=lr*update
        if not np.isfinite(theta).all():raise FloatingPointError(job+(step,))
        if step+1 in (160,320):
            required=4 if method in ('FLTrust-CM','MGT-Med','TransportFLTrust') else 1 if method=='FLTrust' else 0
            rows.append(dict(dataset='digits',seed=seed,attack=attack,method=method,
                             learning_rate=lr,hidden=hidden,rounds=step+1,
                             **predict_metrics(net,theta,*test),parameter_dim=net.dim,
                             parameter_norm=float(np.linalg.norm(theta)),
                             parameter_sha256=hashlib.sha256(theta.tobytes()).hexdigest(),
                             zero_trust_rounds=zero_rounds,
                             mean_byzantine_weight=float(np.mean(weights)) if weights else float('nan'),
                             mean_root_cone_cosine=float(np.mean(badcos)) if badcos else float('nan'),
                             required_server_example_gradients=required*64*(step+1),
                             wall_seconds=time.perf_counter()-start))
    return rows

def append(path,rows):
    exists=path.exists()
    with path.open('a',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]))
        if not exists:w.writeheader()
        w.writerows(rows)

def summarize():
    df=pd.read_csv(OUT/'sensitivity_runs.csv')
    summary=df.groupby(['dataset','attack','method','learning_rate','hidden','rounds']).agg(
        n=('seed','size'),accuracy_mean=('test_accuracy','mean'),accuracy_sd=('test_accuracy','std'),
        balanced_accuracy_mean=('test_balanced_accuracy','mean'),balanced_accuracy_sd=('test_balanced_accuracy','std'),
        ce_mean=('test_ce','mean'),ce_sd=('test_ce','std')).reset_index()
    summary.to_csv(OUT/'sensitivity_summary.csv',index=False)
    pairs=[]
    for (a,lr,h,R),g in df.groupby(['attack','learning_rate','hidden','rounds']):
        wide=g.pivot(index='seed',columns='method',values='test_accuracy')
        for ref in ['FLTrust','FLTrust-CM','Median','TransportFLTrust']:
            delta=wide['MGT-Med']-wide[ref]
            pairs.append(dict(attack=a,learning_rate=lr,hidden=h,rounds=R,reference=ref,n=len(delta),
                              difference_mean=float(delta.mean()),difference_sd=float(delta.std(ddof=1)),
                              positive_seeds=int((delta>0).sum()),negative_seeds=int((delta<0).sum()),ties=int((delta==0).sum())))
    pd.DataFrame(pairs).to_csv(OUT/'sensitivity_pairs.csv',index=False)
    keys=['seed','attack','method','learning_rate','hidden','rounds']
    checks=dict(expected_fits=180,actual_fits=int((df['rounds']==320).sum()),expected_checkpoint_rows=360,
                actual_checkpoint_rows=len(df),unique_keys=int(df[keys].drop_duplicates().shape[0]),
                finite_metrics=bool(np.isfinite(df[['test_accuracy','test_balanced_accuracy','test_ce','parameter_norm']]).all().all()),
                no_test_selection=True,numerical_version='official_author_rules_float64',
                zero_total_trust_rounds_at_320={m:int(g.zero_trust_rounds.sum()) for m,g in df[df['rounds']==320].groupby('method')})
    assert checks['actual_fits']==180 and checks['actual_checkpoint_rows']==checks['unique_keys']==360 and checks['finite_metrics']
    (OUT/'integrity.json').write_text(json.dumps(checks,indent=2))
    (OUT/'COMPLETE.json').write_text(json.dumps({'status':'COMPLETE_PRIMARY_OFFICIAL_RULES','fits':180,'checkpoint_rows':360,
        'runs_sha256':hashlib.sha256((OUT/'sensitivity_runs.csv').read_bytes()).hexdigest()},indent=2))
    print('COMPLETE: 180 fits, 360 checkpoint rows, all finite, no test selection',flush=True)

def main():
    (OUT/'protocol.json').write_text(json.dumps(PROTOCOL,indent=2))
    (OUT/'environment.json').write_text(json.dumps(dict(python=sys.version,numpy=np.__version__,platform=platform.platform(),workers=2,
        runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        author_methods_sha256=hashlib.sha256((HERE/'author_methods.py').read_bytes()).hexdigest()),indent=2))
    done=set()
    if (OUT/'sensitivity_runs.csv').exists():
        with (OUT/'sensitivity_runs.csv').open() as f:
            done={(int(r['seed']),r['attack'],r['method'],float(r['learning_rate']),int(r['hidden'])) for r in csv.DictReader(f) if int(r['rounds'])==320}
    jobs=[(s,a,m,lr,h) for s in SEEDS for a in ATKS for m in METHODS for lr in LRS for h in HIDDEN if (s,a,m,lr,h) not in done]
    with ProcessPoolExecutor(max_workers=2) as pool:
        futures={pool.submit(run_one,j):j for j in jobs}
        for k,future in enumerate(as_completed(futures),1):
            rows=future.result();append(OUT/'sensitivity_runs.csv',rows)
            r=rows[-1]
            print(f"{k}/{len(jobs)} s{r['seed']} {r['attack']} {r['method']} lr{r['learning_rate']} h{r['hidden']}: acc160={rows[0]['test_accuracy']:.4f}, acc320={r['test_accuracy']:.4f}",flush=True)
    summarize()

if __name__=='__main__':main()
