from pathlib import Path
import hashlib,json
import pandas as pd

HERE=Path(__file__).resolve().parent
OUT=HERE/'sensitivity'
s=pd.read_csv(OUT/'sensitivity_summary.csv');p=pd.read_csv(OUT/'sensitivity_pairs.csv')
assert len(s)==120 and len(p)==96
names={'Median':'Median','FLTrust':'FLTrust','FLTrust-CM':'FLTrust-CM','MGT-Med':'MGT--Med','TransportFLTrust':'Transport+FLTrust'}
methods=list(names)
for attack in ['signflip','root_aligned']:
    lines=[r'\begin{tabular}{rrr'+'r'*5+'}',r'\toprule',r'$\eta$ & Width & $T$ & '+' & '.join(names[m] for m in methods)+r' \\',r'\midrule']
    for lr in [.05,.15,.30]:
        for h in [12,48]:
            for T in [160,320]:
                vals=[]
                for m in methods:
                    r=s[(s.attack==attack)&(s.learning_rate==lr)&(s.hidden==h)&(s['rounds']==T)&(s.method==m)].iloc[0]
                    vals.append(f'${100*r.accuracy_mean:.2f}\\pm{100*r.accuracy_sd:.2f}$')
                lines.append(f'{lr:.2f} & {h} & {T} & '+' & '.join(vals)+r' \\')
        if lr!=.30:lines.append(r'\midrule')
    lines+=[r'\bottomrule',r'\end{tabular}']
    (OUT/f'sensitivity_accuracy_{attack}.tex').write_text('\n'.join(lines)+'\n')

records=[]
for (a,ref),g in p.groupby(['attack','reference']):
    records.append(dict(attack=a,reference=ref,dependent_settings=len(g),
                        positive_mean_settings=int((g.difference_mean>0).sum()),
                        negative_mean_settings=int((g.difference_mean<0).sum()),
                        min_mean_difference_pp=100*float(g.difference_mean.min()),
                        max_mean_difference_pp=100*float(g.difference_mean.max()),
                        all_paired_signs_positive=bool((g.positive_seeds==g.n).all()),
                        all_paired_signs_negative=bool((g.negative_seeds==g.n).all())))
(OUT/'grid_descriptive_summary.json').write_text(json.dumps(records,indent=2))
def interval(a,ref):
    g=p[(p.attack==a)&(p.reference==ref)]
    return f'{100*g.difference_mean.min():+.2f} to {100*g.difference_mean.max():+.2f}'

report=f'''# Bounded schedule and width sensitivity (v3)

VERIFIED: 180 fitted trajectories, 360 checkpoint records. All settings retained, including failures of the proposed correction. Dataset Digits; paired seeds 0,1,2; methods Median, FLTrust, FLTrust-CM, MGT--Med, and TransportFLTrust; attacks sign flip and root-cone; learning rates .05,.15,.30; hidden widths 12,48; 320 rounds per fit with checkpoints at 160 and 320. The main default (width24, learning rate .15, 160 rounds) is unchanged. This is a post-review bounded sensitivity design, not preregistration or test-set selection.

Each setting has three paired seeds, with sample SD; the two checkpoints are on the same trajectory. Twelve hyperparameter/checkpoint settings per attack share source observations and seeds and are not independent replicates. Primary numerical rules are the verified FLTrust author-code epsilon and zero-total-score rules. No numerical failure occurred and zero-total-score round count is zero throughout this sensitivity grid.

Under root-cone stress, MGT--Med minus FLTrust mean accuracy ranges {interval('root_aligned','FLTrust')} percentage points over all twelve settings; versus compute-matched FLTrust it ranges {interval('root_aligned','FLTrust-CM')}. Both differences are positive in every tested setting and every paired seed. The root-cone contrast therefore persists in this limited range of learning rates, widths, and horizons; it is not explained solely by the single main step size or CM's slower fixed-schedule convergence.

The attack-specific restriction remains decisive. Under sign flip, MGT--Med minus FLTrust is {interval('signflip','FLTrust')} percentage points and is negative in every setting and every paired seed. Versus Median, the sign-flip difference ranges {interval('signflip','Median')}; benefits at low rate/early rounds can reverse at larger rate and longer training. This is evidence against a general accuracy-superiority claim.

Under root-cone stress, MGT--Med minus raw Median ranges {interval('root_aligned','Median')} percentage points, and several longer-run differences are close to zero. Most of the large FLTrust contrast is associated with the aggregation rule's behavior under this deliberately targeted attack, rather than an isolated transport contribution. The grid does not estimate the population calibration residual or causally identify why a cell changes, so the discussion must not treat these patterns as proof that calibration noise caused the reversals.

Files: sensitivity_runs.csv has all 360 per-seed checkpoints; sensitivity_summary.csv has all 120 method/setting means and SDs; sensitivity_pairs.csv has paired MGT--Med differences against all four comparators; grid_descriptive_summary.json contains ranges without selecting an optimum. Two sensitivity_accuracy_*.tex files contain all 24 setting rows (12 per attack) and all five methods. COMPLETE.json gives the frozen raw-data hash.
'''
(OUT/'report.md').write_text(report,encoding='utf-8')
print(report)
