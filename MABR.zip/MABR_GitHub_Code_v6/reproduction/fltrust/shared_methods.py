"""Shared, test-data-free FLTrust and root-cone stress definitions for v3."""
import numpy as np

ROOT_CONE_COSINES = np.array([.05, .10, .25, .50, .75, .90, 1.0])


def fltrust_update(G, anchor):
    """NDSS FLTrust Eqs. (2)--(4), with documented zero-score fallback."""
    G = np.asarray(G, dtype=float)
    anchor = np.asarray(anchor, dtype=float)
    norms = np.linalg.norm(G, axis=1)
    an = np.linalg.norm(anchor)
    scores = np.maximum(0.0, (G @ anchor) / (np.maximum(norms, 1e-15) * max(an, 1e-15)))
    if scores.sum() < 1e-15:
        return anchor.copy(), dict(fallback=1, scores=scores)
    normed = G * (an / np.maximum(norms, 1e-15))[:, None]
    return (scores[:, None] * normed).sum(axis=0) / scores.sum(), dict(fallback=0, scores=scores)


def root_cone_attack(honest_reports, anchor, target, f=2, scale=5.0):
    """Finite directional search using training messages and the common root only.

    This is a deliberately specified stress construction, not a reproduction of
    the FLTrust paper's adaptive optimizer or a claim to discover a vulnerability.
    Both Byzantine clients repeat the selected vector. No test inputs are used.
    """
    H = np.asarray(honest_reports, dtype=float)
    a = np.asarray(anchor, dtype=float)
    v = np.asarray(target, dtype=float)
    an = np.linalg.norm(a)
    if an < 1e-15:
        bad = -scale * H.mean(axis=0)
        return np.repeat(bad[None, :], f, axis=0), dict(cosine=float('nan'), objective=float('nan'), degenerate=1)
    e = a / an
    p = v - np.dot(v, e) * e
    pn = np.linalg.norm(p)
    if pn < 1e-15:
        j = np.argmin(np.abs(e))
        p = np.eye(1, len(e), j)[0] - e[j] * e
        pn = np.linalg.norm(p)
    p /= max(pn, 1e-15)
    magnitude = scale * max(np.linalg.norm(H.mean(axis=0)), an, 1e-15)
    best = None
    for c in ROOT_CONE_COSINES:
        z = c * e - np.sqrt(max(0.0, 1.0-c*c)) * p
        bad = np.repeat((magnitude*z)[None, :], f, axis=0)
        out, _ = fltrust_update(np.concatenate([H, bad]), a)
        score = float(np.dot(out, v))
        if best is None or score < best[0]:
            best = (score, c, bad)
    return best[2], dict(cosine=float(best[1]), objective=best[0], degenerate=0)


def predict_metrics(net, theta, x, y, masks):
    """Mean test CE, accuracy, and macro recall over fixed evaluation masks."""
    W, b, V, a = net.unpack(theta)
    rows = []
    for m in masks:
        z = np.concatenate([x*m, m.astype(float)], axis=1)
        logits = np.tanh(z @ W+b) @ V+a
        pred = np.argmax(logits, axis=1)
        ce, accuracy = net.loss_grad(theta, x, y, m, False)
        balanced = float(np.mean([np.mean(pred[y == c] == c) for c in np.unique(y)]))
        rows.append([ce, accuracy, balanced])
    out = np.mean(rows, axis=0)
    return dict(test_ce=float(out[0]), test_accuracy=float(out[1]), test_balanced_accuracy=float(out[2]))
