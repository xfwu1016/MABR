from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
df=pd.read_csv(HERE/'comparison_runs.csv')
s=pd.read_csv(HERE/'comparison_summary.csv')
p=pd.read_csv(HERE/'paired_differences.csv')
assert len(df)==300 and set(df.method)=={'Median','FLTrust','FLTrust-CM','MGT-Med','TransportFLTrust','ReferenceOnly'}
assert json.loads((HERE/'environment.json').read_text())['numerical_version']=='official_author_rules_float64'
METHODS=['Median','FLTrust','FLTrust-CM','MGT-Med','TransportFLTrust','ReferenceOnly']
NAMES={'Median':'Median','FLTrust':'FLTrust','FLTrust-CM':'FLTrust-CM','MGT-Med':'MGT--Med','TransportFLTrust':'Transport+FLTrust','ReferenceOnly':'Reference only'}
ATKS=['none','signflip','alie','transport_aware','root_aligned']
ANAMES={'none':'None','signflip':'Sign flip','alie':'ALIE','transport_aware':'Transport-aware','root_aligned':'Root cone'}
def tab(metric,sd,factor,file,fmt='.2f'):
    lines=['\\begin{tabular}{ll'+'r'*6+'}', '\\toprule', 'Data & Attack & '+' & '.join(NAMES[m] for m in METHODS)+' \\\\', '\\midrule']
    for d,dname in [('breast_cancer','WDBC'),('digits','Digits')]:
        for k,a in enumerate(ATKS):
            vals=[]
            for m in METHODS:
                r=s[(s.dataset==d)&(s.attack==a)&(s.method==m)].iloc[0]
                vals.append('$'+format(r[metric]*factor,fmt)+r'\pm'+format(r[sd]*factor,fmt)+'$')
            lines.append((dname if k==0 else '')+' & '+ANAMES[a]+' & '+' & '.join(vals)+r' \\')
        if d=='breast_cancer':lines.append('\\midrule')
    lines+=['\\bottomrule','\\end{tabular}']
    (HERE/file).write_text('\n'.join(lines)+'\n')
tab('accuracy_mean','accuracy_sd',100,'comparison_accuracy.tex')
tab('balanced_accuracy_mean','balanced_accuracy_sd',100,'comparison_balanced.tex')
tab('ce_mean','ce_sd',1,'comparison_ce.tex',fmt='.3f')

lines=['\\begin{tabular}{llrrr}', '\\toprule', r'Data & Attack & $\Delta$ vs. FLTrust & $\Delta$ vs. CM & $\Delta$ vs. Median \\', '\\midrule']
for d,dname in [('breast_cancer','WDBC'),('digits','Digits')]:
    for k,a in enumerate(ATKS):
        vals=[]
        for ref in ['FLTrust','FLTrust-CM','Median']:
            r=p[(p.dataset==d)&(p.attack==a)&(p.method=='MGT-Med')&(p.reference==ref)&(p.metric=='test_accuracy')].iloc[0]
            vals.append(f"${100*r.difference_mean:+.2f}\\pm{100*r.difference_sd:.2f}$")
        lines.append((dname if k==0 else '')+' & '+ANAMES[a]+' & '+' & '.join(vals)+r' \\')
    if d=='breast_cancer':lines.append('\\midrule')
lines+=['\\bottomrule','\\end{tabular}']
(HERE/'comparison_pairs.tex').write_text('\n'.join(lines)+'\n')

def row(d,a,m):return s[(s.dataset==d)&(s.attack==a)&(s.method==m)].iloc[0]
def format_acc(d,a,m):
    r=row(d,a,m);return f'{r.accuracy_mean*100:.2f} ± {r.accuracy_sd*100:.2f}%'
def delta(d,a,m,ref):
    r=p[(p.dataset==d)&(p.attack==a)&(p.method==m)&(p.reference==ref)&(p.metric=='test_accuracy')].iloc[0]
    return f'{r.difference_mean*100:+.3f} ± {r.difference_sd*100:.3f} percentage points; positive seeds {int(r.positive_seeds)}/5'

fallbacks={m:int(g.fltrust_fallbacks.sum()) for m,g in df.groupby('method')}
source=HERE.parents[0]/'sources'/'author_nd_aggregation.py'
report=f'''# Paired FLTrust comparison, v3 (2026-10-29)

Status: VERIFIED measurements and implementation checks; no universal superiority claim.

## Protocol and fairness

The primary CSV contains 300 final-checkpoint fits: 2 datasets × 5 paired split/training seeds × 5 attacks × 6 methods. Architecture, initial parameters, complete trusted core of 64 distinct examples, reference batch of 64 draws, client minibatches of 32, random-mask schedules, learning rate .15 and final round 160 are shared. The original private masks are independently redrawn at every access, not fixed natural missingness. Five seeds describe stochastic/split variability on overlapping datasets, not five independent populations. No test checkpoint or hyperparameter selection was performed.

FLTrust-CM averages four 64-draw target-root gradients from the same 64 distinct core examples. Its 256 server example-gradient evaluations per round match MGT--Med's target plus three client-profile gradients. It receives no additional unique labeled data. It has the same fixed learning rate and number of rounds; averaging changes the anchor norm as well as its direction, so this is a budget control rather than an optimally tuned FLTrust upper bound. TransportFLTrust uses FLTrust aggregation on G-D, with the identical target anchor. This exploratory combination separates calibration from the aggregation rule and is not claimed to inherit the coordinate-median theorem.

All simulations compute diagnostic profile gradients and, even for ReferenceOnly, private messages; recorded wall times include this extra work. Required algorithmic server-example budgets are 0 (Median), 10,240 (FLTrust/ReferenceOnly), and 40,960 (MGT--Med/TransportFLTrust/FLTrust-CM) over 160 rounds. Wall time is therefore not presented as a fair ranking of implementations.

## Verified FLTrust definition

Official paper: https://www.ndss-symposium.org/wp-content/uploads/2021-434-paper.pdf, Eqs. (2)--(4), Algorithm 2 steps 14--19. Official author code is linked from Neil Gong's institutional Code & Data page (https://people.duke.edu/~zg70/dataset.html) at https://people.duke.edu/~zg70/code/fltrust.zip. Both use ReLU cosine scores, scaling each client report to the root norm, and a trust-weighted aggregate; the root is not itself appended as a trust-1 client.

The v3 primary code adopts the author's numerical placement of epsilon=1e-9 in both norm denominators and in the weight sum, so zero total trust produces a zero update. This is a float64 NumPy single-gradient adaptation, not bitwise MXNet or the original paper's entire evaluation. The v2 numerical root fallback is preserved as a fully recorded legacy experiment. Across primary fits, zero-total-trust round counts (the CSV compatibility column is named fltrust_fallbacks) are {json.dumps(fallbacks)}. Existing original-data/parameter replay checks for Median, MGT--Med and ReferenceOnly are retained; FLTrust parameter hashes intentionally change with author-code numerical rules.

## Attacks

None, sign flip, ALIE, and transport-aware attacks retain the previous definitions. The additional root-cone stress is a new finite directional search for this study, not a reproduction of FLTrust's adaptive optimizer and not proof of a vulnerability. It sees honest training reports and current reference/profile gradients. For FLTrust-CM it sees the actual averaged 256-draw anchor too. There are no test inputs, labels, or test losses in attack generation.

Let e=a/||a|| and v=mean honest corrected report. Let p be the unit component of v orthogonal to e. Candidate malicious directions are z(c)=c e-sqrt(1-c²)p for c∈{{.05,.1,.25,.5,.75,.9,1}}. Both Byzantine clients repeat 5 max(||mean honest raw||,||a||,1e-15)z(c). The chosen c minimizes the inner product of the standard FLTrust aggregate with v. A deterministic orthogonal basis vector handles a degenerate perpendicular component. The attack has positive root cosine; it deliberately targets the trust geometry. Different model trajectories have different current messages; methods share the attack recipe, rather than pretending all poisoned numeric vectors stay identical after models diverge.

## Results to integrate

Digits root-cone accuracy: Median {format_acc('digits','root_aligned','Median')}; FLTrust {format_acc('digits','root_aligned','FLTrust')}; FLTrust-CM {format_acc('digits','root_aligned','FLTrust-CM')}; MGT--Med {format_acc('digits','root_aligned','MGT-Med')}; TransportFLTrust {format_acc('digits','root_aligned','TransportFLTrust')}.

Paired MGT--Med differences on Digits root cone: vs FLTrust {delta('digits','root_aligned','MGT-Med','FLTrust')}; vs FLTrust-CM {delta('digits','root_aligned','MGT-Med','FLTrust-CM')}; vs raw Median {delta('digits','root_aligned','MGT-Med','Median')}.

The large MGT--Med/FLTrust contrast cannot all be attributed to transport: raw Median already retains most of the root-cone performance. Under the same stress, the two malicious Digits clients (2/11 of clients) receive a mean {row('digits','root_aligned','FLTrust').byzantine_share*100:.2f}% of FLTrust weight, versus {row('digits','signflip','FLTrust').byzantine_share*100:.2f}% for sign flip. This is a measured stress-specific diagnostic, not a universal attack law or a causal mediation estimate.

FLTrust remains stronger in important conditions: on Digits sign flip MGT--Med is {format_acc('digits','signflip','MGT-Med')} versus FLTrust {format_acc('digits','signflip','FLTrust')}; on Digits transport-aware MGT--Med is {format_acc('digits','transport_aware','MGT-Med')} versus FLTrust {format_acc('digits','transport_aware','FLTrust')}. WDBC root-cone MGT--Med is {format_acc('breast_cancer','root_aligned','MGT-Med')} versus FLTrust {format_acc('breast_cancer','root_aligned','FLTrust')}, but paired spread is substantial. TransportFLTrust does not establish a general advantage over ordinary FLTrust.

All accuracy, balanced accuracy, cross-entropy, per-seed rows, and unfavorable cells remain in the CSVs. Paired-differences CSV also supplies unadjusted t-intervals as descriptive summaries with five seeds, not confirmatory multiplicity-adjusted significance claims. Manuscript tables should prefer mean ± sample SD and avoid using grid cells as independent replications.

## Files

comparison_runs.csv, comparison_curves.csv, comparison_summary.csv, paired_differences.csv, protocol.json, implementation_audit.json, environment.json and integrity.json are the primary evidence. comparison_accuracy.tex / comparison_balanced.tex / comparison_ce.tex contain all 10 dataset-attack cells and all six methods. comparison_pairs.tex contains paired MGT accuracy differences.

legacy_rules/ contains the complete earlier 300 v2-numerical-rule fits; preliminary_superseded/ additionally preserves the initial partial-knowledge CM root-cone run. These are archival analyses and must not be combined with the final primary CSV as extra statistical replication.
'''
(HERE/'report.md').write_text(report,encoding='utf-8')
print('Wrote primary report and four complete comparison tables; no cells dropped.')
