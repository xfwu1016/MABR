"""Author-code FLTrust numerical rules, evaluated with this study's float64 MLP.

Primary source: https://people.duke.edu/~zg70/code/fltrust.zip,
nd_aggregation.py, verified 2026-10-29. This is the NumPy single-step adaptation,
not a claim of bitwise equivalence to an MXNet float32 training run.
"""
import numpy as np
from shared_methods import ROOT_CONE_COSINES, predict_metrics

EPS=1e-9

def fltrust_update(G, anchor):
    G=np.asarray(G,dtype=float)
    a=np.asarray(anchor,dtype=float)
    norms=np.linalg.norm(G,axis=1)
    an=np.linalg.norm(a)
    scores=np.maximum(0.,(G@a)/(an+EPS)/(norms+EPS))
    weights=scores/(scores.sum()+EPS)
    normed=G/(norms+EPS)[:,None]*an
    update=(weights[:,None]*normed).sum(axis=0)
    return update,dict(fallback=int(scores.sum()==0.),scores=scores)

def root_cone_attack(honest_reports, anchor, target, f=2, scale=5.):
    H=np.asarray(honest_reports,dtype=float);a=np.asarray(anchor,dtype=float);v=np.asarray(target,dtype=float)
    an=np.linalg.norm(a)
    if an<1e-15:
        bad=-scale*H.mean(axis=0)
        return np.repeat(bad[None,:],f,axis=0),dict(cosine=float('nan'),objective=float('nan'),degenerate=1)
    e=a/an;p=v-(v@e)*e;pn=np.linalg.norm(p)
    if pn<1e-15:
        j=np.argmin(np.abs(e));p=np.eye(1,len(e),j)[0]-e[j]*e;pn=np.linalg.norm(p)
    p/=max(pn,1e-15)
    magnitude=scale*max(np.linalg.norm(H.mean(axis=0)),an,1e-15)
    best=None
    for c in ROOT_CONE_COSINES:
        z=c*e-np.sqrt(max(0.,1.-c*c))*p
        bad=np.repeat((magnitude*z)[None,:],f,axis=0)
        out,_=fltrust_update(np.concatenate([H,bad]),a)
        objective=float(out@v)
        if best is None or objective<best[0]:best=(objective,c,bad)
    return best[2],dict(cosine=float(best[1]),objective=best[0],degenerate=0)
