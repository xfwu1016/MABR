# Paired FLTrust comparison, v3 (2026-10-29)

Status: VERIFIED measurements and implementation checks; no universal superiority claim.

## Protocol and fairness

The primary CSV contains 300 final-checkpoint fits: 2 datasets × 5 paired split/training seeds × 5 attacks × 6 methods. Architecture, initial parameters, complete trusted core of 64 distinct examples, reference batch of 64 draws, client minibatches of 32, random-mask schedules, learning rate .15 and final round 160 are shared. The original private masks are independently redrawn at every access, not fixed natural missingness. Five seeds describe stochastic/split variability on overlapping datasets, not five independent populations. No test checkpoint or hyperparameter selection was performed.

FLTrust-CM averages four 64-draw target-root gradients from the same 64 distinct core examples. Its 256 server example-gradient evaluations per round match MGT--Med's target plus three client-profile gradients. It receives no additional unique labeled data. It has the same fixed learning rate and number of rounds; averaging changes the anchor norm as well as its direction, so this is a budget control rather than an optimally tuned FLTrust upper bound. TransportFLTrust uses FLTrust aggregation on G-D, with the identical target anchor. This exploratory combination separates calibration from the aggregation rule and is not claimed to inherit the coordinate-median theorem.

All simulations compute diagnostic profile gradients and, even for ReferenceOnly, private messages; recorded wall times include this extra work. Required algorithmic server-example budgets are 0 (Median), 10,240 (FLTrust/ReferenceOnly), and 40,960 (MGT--Med/TransportFLTrust/FLTrust-CM) over 160 rounds. Wall time is therefore not presented as a fair ranking of implementations.

## Verified FLTrust definition

Official paper: https://www.ndss-symposium.org/wp-content/uploads/2021-434-paper.pdf, Eqs. (2)--(4), Algorithm 2 steps 14--19. Official author code is linked from Neil Gong's institutional Code & Data page (https://people.duke.edu/~zg70/dataset.html) at https://people.duke.edu/~zg70/code/fltrust.zip. Both use ReLU cosine scores, scaling each client report to the root norm, and a trust-weighted aggregate; the root is not itself appended as a trust-1 client.

The v3 primary code adopts the author's numerical placement of epsilon=1e-9 in both norm denominators and in the weight sum, so zero total trust produces a zero update. This is a float64 NumPy single-gradient adaptation, not bitwise MXNet or the original paper's entire evaluation. The v2 numerical root fallback is preserved as a fully recorded legacy experiment. Across primary fits, zero-total-trust round counts (the CSV compatibility column is named fltrust_fallbacks) are {"FLTrust": 5, "FLTrust-CM": 2, "MGT-Med": 0, "Median": 0, "ReferenceOnly": 0, "TransportFLTrust": 0}. Existing original-data/parameter replay checks for Median, MGT--Med and ReferenceOnly are retained; FLTrust parameter hashes intentionally change with author-code numerical rules.

## Attacks

None, sign flip, ALIE, and transport-aware attacks retain the previous definitions. The additional root-cone stress is a new finite directional search for this study, not a reproduction of FLTrust's adaptive optimizer and not proof of a vulnerability. It sees honest training reports and current reference/profile gradients. For FLTrust-CM it sees the actual averaged 256-draw anchor too. There are no test inputs, labels, or test losses in attack generation.

Let e=a/||a|| and v=mean honest corrected report. Let p be the unit component of v orthogonal to e. Candidate malicious directions are z(c)=c e-sqrt(1-c²)p for c∈{.05,.1,.25,.5,.75,.9,1}. Both Byzantine clients repeat 5 max(||mean honest raw||,||a||,1e-15)z(c). The chosen c minimizes the inner product of the standard FLTrust aggregate with v. A deterministic orthogonal basis vector handles a degenerate perpendicular component. The attack has positive root cosine; it deliberately targets the trust geometry. Different model trajectories have different current messages; methods share the attack recipe, rather than pretending all poisoned numeric vectors stay identical after models diverge.

## Results to integrate

Digits root-cone accuracy: Median 84.37 ± 1.18%; FLTrust 67.32 ± 2.85%; FLTrust-CM 73.60 ± 2.25%; MGT--Med 85.09 ± 0.98%; TransportFLTrust 75.25 ± 1.61%.

Paired MGT--Med differences on Digits root cone: vs FLTrust +17.765 ± 2.823 percentage points; positive seeds 5/5; vs FLTrust-CM +11.481 ± 2.032 percentage points; positive seeds 5/5; vs raw Median +0.716 ± 1.004 percentage points; positive seeds 4/5.

The large MGT--Med/FLTrust contrast cannot all be attributed to transport: raw Median already retains most of the root-cone performance. Under the same stress, the two malicious Digits clients (2/11 of clients) receive a mean 40.05% of FLTrust weight, versus 2.77% for sign flip. This is a measured stress-specific diagnostic, not a universal attack law or a causal mediation estimate.

FLTrust remains stronger in important conditions: on Digits sign flip MGT--Med is 83.84 ± 1.34% versus FLTrust 85.17 ± 1.05%; on Digits transport-aware MGT--Med is 84.60 ± 1.18% versus FLTrust 85.70 ± 0.43%. WDBC root-cone MGT--Med is 95.36 ± 0.42% versus FLTrust 94.35 ± 1.32%, but paired spread is substantial. TransportFLTrust does not establish a general advantage over ordinary FLTrust.

All accuracy, balanced accuracy, cross-entropy, per-seed rows, and unfavorable cells remain in the CSVs. Paired-differences CSV also supplies unadjusted t-intervals as descriptive summaries with five seeds, not confirmatory multiplicity-adjusted significance claims. Manuscript tables should prefer mean ± sample SD and avoid using grid cells as independent replications.

## Files

comparison_runs.csv, comparison_curves.csv, comparison_summary.csv, paired_differences.csv, protocol.json, implementation_audit.json, environment.json and integrity.json are the primary evidence. comparison_accuracy.tex / comparison_balanced.tex / comparison_ce.tex contain all 10 dataset-attack cells and all six methods. comparison_pairs.tex contains paired MGT accuracy differences.

legacy_rules/ contains the complete earlier 300 v2-numerical-rule fits; preliminary_superseded/ additionally preserves the initial partial-knowledge CM root-cone run. These are archival analyses and must not be combined with the final primary CSV as extra statistical replication.
