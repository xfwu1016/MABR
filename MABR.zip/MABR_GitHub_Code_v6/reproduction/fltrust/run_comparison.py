"""Fixed-protocol, paired FLTrust comparison. All results, including losses, retained."""
import os
for name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[name] = '1'
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import sys
import time
import numpy as np
from scipy.stats import t as student_t

HERE = Path(__file__).resolve().parent
BASE_PATH = HERE.parent/'run_experiments.py'
spec = importlib.util.spec_from_file_location('mabr_base', BASE_PATH)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
from author_methods import fltrust_update, root_cone_attack, predict_metrics, ROOT_CONE_COSINES

METHODS = ['Median', 'FLTrust', 'FLTrust-CM', 'MGT-Med', 'TransportFLTrust', 'ReferenceOnly']
ATTACKS = ['none', 'signflip', 'alie', 'transport_aware', 'root_aligned']
DATASETS = ['breast_cancer', 'digits']
SEEDS = [0, 1, 2, 3, 4]
CONFIG = {
    'datasets': DATASETS, 'seeds': SEEDS, 'methods': METHODS, 'attacks': ATTACKS,
    'n_clients':11, 'n_byzantine':2, 'byzantine_ids':[9,10],
    'rounds':160, 'learning_rate':.15, 'hidden':24, 'private_batch':32,
    'reference_core_size':64, 'reference_batch':64,
    'profiles':[.25]*4+[.6]*3+[.9]*4, 'target_observation':.65,
    'masks':'redrawn at every client access; evaluation masks fixed and never used in attack or selection',
    'preprocessing':'StandardScaler fit on the identical trusted reference core only',
    'checkpoint':'final round; no test tuning or selection',
    'FLTrust-CM':'same 64 distinct trusted examples; target anchor averages four independent 64-draw batches, first batch shared with ordinary FLTrust and transport; 256 server gradient-example evaluations per round',
    'TransportFLTrust':'apply the original FLTrust trust score and norm projection to G-D, anchored at the same 64-draw target gradient a',
    'root_cone_cosines':ROOT_CONE_COSINES.tolist(),
    'root_cone_knowledge':'omniscient honest raw reports and current reference/profile gradients at current parameter; FLTrust-CM attack also sees its actual 256-draw root anchor; no test values or labels',
    'root_cone_direction':'z(c)=c*a_hat-sqrt(1-c^2)*p; p is normalized component of mean honest corrected reports perpendicular to a_hat; choose c minimizing dot(FLTrust(H, repeated bad),mean honest corrected)',
    'root_cone_magnitude':'5 max(norm(mean honest raw), norm(common root anchor), 1e-15)',
    'root_cone_scope':'finite root-cone directional stress defined for this study; not the original FLTrust adaptive optimizer, not proof of a vulnerability',
    'other_attacks':'signflip=-5 mean honest raw; ALIE=mean+1.5 coordinate SD; transport_aware=D_bad-5 mean honest corrected, as v2',
    'cost_accounting':'server example-gradient count, not measured speed. All runs also compute diagnostic profile anchors and client messages; wall time includes these and cannot rank algorithm speed.',
    'private_budget':'11*32 examples each round for federated rules; ReferenceOnly conceptually requires zero private messages',
    'protocol_status':'fixed before these new runs; exploratory follow-up rather than preregistration'
}
CONFIG['FLTrust_numerics']='author MXNet code numerical rules adapted to float64 NumPy: eps=1e-9 added separately to anchor norm, report norm, and weight sum; zero total trust gives zero update. Legacy root-fallback rows archived separately.'

def audit():
    rng = np.random.default_rng(90123)
    errors=[]
    for _ in range(50):
        G=rng.normal(size=(11,19));a=rng.normal(size=19)
        expected,_=base.aggregate(G,'FLTrust',a,2)
        got,_=fltrust_update(G,a)
        errors.append(float(np.max(np.abs(got-expected))))
        scales=np.exp(rng.normal(size=11))
        scaled,_=fltrust_update(G*scales[:,None],a)
        assert np.allclose(scaled,got,atol=1e-7)
    a=np.array([1.,0.,0.]);G=np.array([[1.,1.,0.],[1.,-1.,0.],[-1.,0.,0.]])
    out,info=fltrust_update(G,a)
    assert np.allclose(out,[np.sqrt(.5),0.,0.])
    assert info['scores'][2]==0
    fallback,extra=fltrust_update(-np.ones((11,3)),np.ones(3))
    assert extra['fallback']==1 and np.array_equal(fallback,np.zeros(3))
    H=rng.normal(size=(9,19));a=rng.normal(size=19);target=H.mean(axis=0)
    bad,attack= root_cone_attack(H,a,target)
    actual_cos=(bad[0]@a)/(np.linalg.norm(bad[0])*np.linalg.norm(a))
    assert actual_cos>0 and np.isclose(actual_cos,attack['cosine'])
    return {
        'official_source':'https://www.ndss-symposium.org/wp-content/uploads/2021-434-paper.pdf',
        'official_author_code':'https://people.duke.edu/~zg70/code/fltrust.zip',
        'verified_date':'2026-10-29',
        'verified_items':['NDSS 2021 Eqs. (2), (3), (4), Algorithm 2 steps 14-19', 'server anchor is not included as an additional trusted client in Eq. (4)'],
        'adaptation':'one gradient per client and root per round, not a replication of all original paper datasets or multi-local-step settings',
        'numeric_rules':'eps=1e-9 at both norms and score sum, as author code; zero scores give zero update',
        'max_difference_from_v2_nonzero_random_inputs':max(errors),
        'positive_rescaling_invariance_up_to_eps_perturbation':True,
        'hand_computed_case':True,
        'negative_cosine_excluded':True,
        'root_cone_positive_cosine':float(actual_cos),
        'gradient_check':base.gradient_check()
    }

def run_one(job):
    dataset,seed,attack,method=job
    clients,ref,test,meta=base.prepare(dataset,seed)
    net=base.MLP(meta['features'],meta['classes'],24)
    theta=net.initialize(np.random.default_rng(500+seed))
    rng=np.random.default_rng(600+seed)
    extra_rng=np.random.default_rng(1600+seed)
    profiles=np.array(CONFIG['profiles'])
    unique=np.unique(np.r_[profiles,.65])
    n=11;f=2;honest=n if attack=='none' else n-f
    curves=[];shares=[];badshares=[];honestscores=[];badcos=[];fallbacks=0
    start=time.perf_counter()
    for step in range(160):
        rid=rng.integers(0,len(ref[1]),64)
        rx,ry=ref[0][rid],ref[1][rid]
        U=rng.random(rx.shape)
        anchors={float(p):net.loss_grad(theta,rx,ry,U<p)[1] for p in unique}
        a=anchors[.65]
        D=np.stack([anchors[float(p)]-a for p in profiles])
        raw=[]
        for i,(x,y) in enumerate(clients):
            ids=rng.integers(0,len(y),32)
            mask=rng.random((len(ids),meta['features']))<profiles[i]
            raw.append(net.loss_grad(theta,x[ids],y[ids],mask)[1])
        G=np.stack(raw)
        anchor=a
        if method=='FLTrust-CM':
            extra=[]
            for _ in range(3):
                ei=extra_rng.integers(0,len(ref[1]),64)
                eu=extra_rng.random((64,meta['features']))
                extra.append(net.loss_grad(theta,ref[0][ei],ref[1][ei],eu<.65)[1])
            anchor=(a+np.sum(extra,axis=0))/4.
        if attack!='none':
            H=G[:honest]
            if attack=='signflip':G[honest:]=-5.*H.mean(axis=0)
            elif attack=='alie':G[honest:]=H.mean(axis=0)+1.5*H.std(axis=0,ddof=0)
            elif attack=='transport_aware':G[honest:]=D[honest:]-5.*(H-D[:honest]).mean(axis=0)
            else:
                # The adversary observes the actual aggregating anchor, including
                # all four root batches for FLTrust-CM: no secret-RNG advantage.
                G[honest:],detail=root_cone_attack(H,anchor,(H-D[:honest]).mean(axis=0),f,5.)
                badcos.append(detail['cosine'])
        corrected=G-D
        if method in ('FLTrust','FLTrust-CM','TransportFLTrust'):
            use=corrected if method=='TransportFLTrust' else G
            update,info=fltrust_update(use,anchor)
            scores=info['scores'];den=max(scores.sum(),1e-15)
            shares.append(float(scores[:4].sum()/den))
            badshares.append(float(scores[honest:].sum()/den) if attack!='none' else 0.)
            honestscores.append(float(scores[:honest].mean()))
            fallbacks+=info['fallback']
        elif method=='MGT-Med':update=np.median(corrected,axis=0)
        elif method=='Median':update=np.median(G,axis=0)
        elif method=='ReferenceOnly':update=a
        else:raise ValueError(method)
        theta-=.15*update
        if not np.isfinite(theta).all():raise FloatingPointError(job+(step,))
        if step%10==0 or step==159:
            curves.append(dict(dataset=dataset,seed=seed,attack=attack,method=method,round=step+1,
                               **predict_metrics(net,theta,*test),parameter_norm=float(np.linalg.norm(theta))))
    ev=predict_metrics(net,theta,*test)
    required_server=4 if method in ('MGT-Med','TransportFLTrust','FLTrust-CM') else 1 if method in ('FLTrust','ReferenceOnly') else 0
    row=dict(dataset=dataset,seed=seed,attack=attack,method=method,rounds=160,**ev,
             parameter_dim=net.dim,parameter_norm=float(np.linalg.norm(theta)),
             fltrust_low_group_weight_share=float(np.mean(shares)) if shares else float('nan'),
             fltrust_byzantine_weight_share=float(np.mean(badshares)) if badshares else float('nan'),
             fltrust_mean_honest_trust=float(np.mean(honestscores)) if honestscores else float('nan'),
             fltrust_fallbacks=fallbacks,
             root_cone_mean_cosine=float(np.nanmean(badcos)) if badcos else float('nan'),
             wall_seconds=time.perf_counter()-start,
             required_server_gradient_evals=required_server*160,
             required_server_example_gradients=required_server*64*160,
             required_private_example_gradients=0 if method=='ReferenceOnly' else 11*32*160,
             diagnostic_profile_gradient_evals=4*160,
             uplink_float64_values=0 if method=='ReferenceOnly' else 11*net.dim*160,
             parameter_sha256=hashlib.sha256(theta.tobytes()).hexdigest())
    return row,curves,meta

def append(path, rows):
    if not rows:return
    exists=path.exists()
    with path.open('a',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]))
        if not exists:w.writeheader()
        w.writerows(rows)

def summarize():
    import pandas as pd
    df=pd.read_csv(HERE/'comparison_runs.csv')
    summary=df.groupby(['dataset','attack','method']).agg(n=('seed','size'),
        accuracy_mean=('test_accuracy','mean'),accuracy_sd=('test_accuracy','std'),
        balanced_accuracy_mean=('test_balanced_accuracy','mean'),balanced_accuracy_sd=('test_balanced_accuracy','std'),
        ce_mean=('test_ce','mean'),ce_sd=('test_ce','std'),
        root_low_share=('fltrust_low_group_weight_share','mean'),byzantine_share=('fltrust_byzantine_weight_share','mean')).reset_index()
    summary.to_csv(HERE/'comparison_summary.csv',index=False)
    pairs=[]
    for (d,a),g in df.groupby(['dataset','attack']):
        for metric in ['test_accuracy','test_balanced_accuracy','test_ce']:
            wide=g.pivot(index='seed',columns='method',values=metric)
            for m,ref in [('MGT-Med','FLTrust'),('MGT-Med','FLTrust-CM'),('TransportFLTrust','FLTrust'),('TransportFLTrust','FLTrust-CM'),('MGT-Med','Median')]:
                delta=(wide[m]-wide[ref]).dropna();n=len(delta);sd=float(delta.std(ddof=1));mean=float(delta.mean())
                half=float(student_t.ppf(.975,n-1)*sd/np.sqrt(n)) if n>1 else float('nan')
                pairs.append(dict(dataset=d,attack=a,metric=metric,method=m,reference=ref,n=n,
                                  difference_mean=mean,difference_sd=sd,ci95_low=mean-half,ci95_high=mean+half,
                                  positive_seeds=int((delta>0).sum()),negative_seeds=int((delta<0).sum()),tie_seeds=int((delta==0).sum())))
    pd.DataFrame(pairs).to_csv(HERE/'paired_differences.csv',index=False)
    old=pd.read_csv(BASE_PATH.parent/'main_runs.csv') if (BASE_PATH.parent/'main_runs.csv').exists() else None
    replays=[]
    if old is not None:
        common=df[df.seed.isin([0,1,2]) & df['method'].isin(['Median','FLTrust','MGT-Med','ReferenceOnly']) & df.attack.isin(base.ATTACKS)]
        merged=common.merge(old,on=['dataset','seed','attack','method'],suffixes=('_new','_old'))
        replays=[dict(dataset=r.dataset,seed=int(r.seed),attack=r.attack,method=r.method,
                      exact_parameter_hash_match=r.parameter_sha256_new==r.parameter_sha256_old)
                 for r in merged.itertuples()]
        assert all(x['exact_parameter_hash_match'] for x in replays if x['method']!='FLTrust')
    record=dict(expected_fits=len(DATASETS)*len(SEEDS)*len(ATTACKS)*len(METHODS),actual_fits=len(df),
                unique_keys=int(df[['dataset','seed','attack','method']].drop_duplicates().shape[0]),
                finite_final_metrics=bool(np.isfinite(df[['test_ce','test_accuracy','test_balanced_accuracy','parameter_norm']]).all().all()),
                original_valid_trajectory_replays=replays,
                replay_scope='Median, MGT-Med and ReferenceOnly old non-rootcone hashes must match; FLTrust intentionally changes to official author-code epsilon/zero-score rules. Exact 96/96 legacy replays are archived in legacy_rules.',
                shared_reference_initialization_private_sampling=True,
                no_test_selection=True,
                seed_unit='paired split, initialization, client and reference sampling; data overlap across seeds, not five independent populations')
    assert record['unique_keys']==record['actual_fits'] and record['finite_final_metrics']
    (HERE/'integrity.json').write_text(json.dumps(record,indent=2))
    print('summary:',len(df),'fits,',sum(r['exact_parameter_hash_match'] for r in replays),'/',len(replays),'original parameter hashes match (FLTrust numerical rules intentionally changed)',flush=True)

def main():
    p=argparse.ArgumentParser();p.add_argument('--workers',type=int,default=2);p.add_argument('--summarize',action='store_true');args=p.parse_args()
    if args.summarize:summarize();return
    HERE.mkdir(exist_ok=True)
    (HERE/'protocol.json').write_text(json.dumps(CONFIG,indent=2))
    (HERE/'implementation_audit.json').write_text(json.dumps(audit(),indent=2))
    (HERE/'environment.json').write_text(json.dumps(dict(python=sys.version,numpy=np.__version__,platform=platform.platform(),
        threads_per_worker=1,workers=args.workers,base_sha256=hashlib.sha256(BASE_PATH.read_bytes()).hexdigest(),
        runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),shared_method_sha256=hashlib.sha256((HERE/'author_methods.py').read_bytes()).hexdigest(),numerical_version='official_author_rules_float64'),indent=2))
    done=set()
    if (HERE/'comparison_runs.csv').exists():
        with (HERE/'comparison_runs.csv').open() as f:done={(r['dataset'],int(r['seed']),r['attack'],r['method']) for r in csv.DictReader(f)}
    jobs=[(d,s,a,m) for d in DATASETS for s in SEEDS for a in ATTACKS for m in METHODS if (d,s,a,m) not in done]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures={pool.submit(run_one,j):j for j in jobs}
        for k,future in enumerate(as_completed(futures),1):
            row,curves,meta=future.result()
            append(HERE/'comparison_runs.csv',[row]);append(HERE/'comparison_curves.csv',curves)
            (HERE/f"data_{row['dataset']}_seed{row['seed']}.json").write_text(json.dumps(meta,indent=2))
            print(f"{k}/{len(jobs)} {row['dataset']} s={row['seed']} {row['attack']} {row['method']}: {row['test_accuracy']:.4f} ce={row['test_ce']:.4f} {row['wall_seconds']:.2f}s",flush=True)
    summarize()

if __name__=='__main__':main()
