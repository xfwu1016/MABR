# Experiment evidence report

Completed 252/252 main neural fits; 84 domain-shift stress fits.
All accuracy and loss summaries are computed from final-round evaluations, never selected by test performance.
Uncertainty is the sample standard deviation across three independent data-split/training seeds; three mask evaluations within a seed are averaged, not treated as independent replicates.

MGT-Med exceeds raw Median in 9/12 dataset-attack cells by mean accuracy. Negative cells are retained.

## Main accuracy and CE

### breast_cancer
Method | Attack | Accuracy (%) | CE
--- | --- | --- | ---
Mean | none | 96.881 ± 0.850 | 0.0949 ± 0.0161
Median | none | 96.166 ± 0.788 | 0.1029 ± 0.0180
TrimmedMean | none | 96.231 ± 0.738 | 0.0979 ± 0.0156
FLTrust | none | 96.101 ± 0.338 | 0.1073 ± 0.0112
ReferenceOnly | none | 95.517 ± 0.850 | 0.1160 ± 0.0141
TransportMean | none | 96.621 ± 0.563 | 0.0995 ± 0.0122
MGT-Med | none | 96.231 ± 0.962 | 0.1029 ± 0.0097
Mean | signflip | 28.200 ± 3.622 | 28.6372 ± 2.7213
Median | signflip | 94.737 ± 1.559 | 0.1448 ± 0.0375
TrimmedMean | signflip | 94.737 ± 1.472 | 0.1427 ± 0.0277
FLTrust | signflip | 95.906 ± 0.585 | 0.1181 ± 0.0123
ReferenceOnly | signflip | 95.517 ± 0.850 | 0.1160 ± 0.0141
TransportMean | signflip | 65.887 ± 4.126 | 2.5903 ± 1.6969
MGT-Med | signflip | 95.192 ± 0.788 | 0.1280 ± 0.0113
Mean | alie | 95.906 ± 0.390 | 0.1251 ± 0.0170
Median | alie | 94.997 ± 0.738 | 0.1329 ± 0.0162
TrimmedMean | alie | 94.997 ± 0.900 | 0.1419 ± 0.0140
FLTrust | alie | 95.906 ± 0.585 | 0.1102 ± 0.0142
ReferenceOnly | alie | 95.517 ± 0.850 | 0.1160 ± 0.0141
TransportMean | alie | 96.166 ± 0.406 | 0.1212 ± 0.0131
MGT-Med | alie | 95.776 ± 0.450 | 0.1212 ± 0.0131
Mean | transport_aware | 8.967 ± 1.522 | 174.4560 ± 7.9571
Median | transport_aware | 94.997 ± 1.175 | 0.1345 ± 0.0401
TrimmedMean | transport_aware | 94.802 ± 0.788 | 0.1355 ± 0.0311
FLTrust | transport_aware | 96.101 ± 0.703 | 0.1100 ± 0.0121
ReferenceOnly | transport_aware | 95.517 ± 0.850 | 0.1160 ± 0.0141
TransportMean | transport_aware | 10.591 ± 2.048 | 42.8758 ± 5.5915
MGT-Med | transport_aware | 95.712 ± 0.338 | 0.1165 ± 0.0053

### digits
Method | Attack | Accuracy (%) | CE
--- | --- | --- | ---
Mean | none | 87.984 ± 0.249 | 0.4749 ± 0.0156
Median | none | 87.078 ± 0.463 | 0.5173 ± 0.0303
TrimmedMean | none | 87.510 ± 0.377 | 0.5004 ± 0.0218
FLTrust | none | 86.914 ± 0.214 | 0.5316 ± 0.0247
ReferenceOnly | none | 78.230 ± 0.899 | 0.7344 ± 0.0469
TransportMean | none | 87.860 ± 0.782 | 0.4532 ± 0.0125
MGT-Med | none | 87.222 ± 0.909 | 0.4808 ± 0.0209
Mean | signflip | 7.469 ± 4.545 | 12.0078 ± 5.8340
Median | signflip | 81.399 ± 2.723 | 0.7766 ± 0.0690
TrimmedMean | signflip | 81.049 ± 3.103 | 0.8166 ± 0.0700
FLTrust | signflip | 85.885 ± 0.411 | 0.5746 ± 0.0167
ReferenceOnly | signflip | 78.230 ± 0.899 | 0.7344 ± 0.0469
TransportMean | signflip | 19.465 ± 5.429 | 2.2316 ± 0.0667
MGT-Med | signflip | 83.251 ± 1.308 | 0.6683 ± 0.0492
Mean | alie | 85.658 ± 0.532 | 0.5521 ± 0.0246
Median | alie | 84.691 ± 0.466 | 0.5910 ± 0.0289
TrimmedMean | alie | 84.239 ± 0.467 | 0.6083 ± 0.0314
FLTrust | alie | 85.864 ± 0.309 | 0.5595 ± 0.0256
ReferenceOnly | alie | 78.230 ± 0.899 | 0.7344 ± 0.0469
TransportMean | alie | 86.276 ± 0.249 | 0.5127 ± 0.0193
MGT-Med | alie | 85.514 ± 0.143 | 0.5355 ± 0.0188
Mean | transport_aware | 10.000 ± 0.185 | 135.6246 ± 3.9020
Median | transport_aware | 81.852 ± 2.567 | 0.7472 ± 0.0695
TrimmedMean | transport_aware | 81.008 ± 2.827 | 0.7825 ± 0.0706
FLTrust | transport_aware | 85.885 ± 0.249 | 0.5504 ± 0.0269
ReferenceOnly | transport_aware | 78.230 ± 0.899 | 0.7344 ± 0.0469
TransportMean | transport_aware | 10.000 ± 0.185 | 21.6853 ± 6.4629
MGT-Med | transport_aware | 84.239 ± 1.372 | 0.6312 ± 0.0486

### synthetic
Method | Attack | Accuracy (%) | CE
--- | --- | --- | ---
Mean | none | 78.843 ± 0.093 | 0.5545 ± 0.0114
Median | none | 78.920 ± 0.279 | 0.5563 ± 0.0132
TrimmedMean | none | 78.904 ± 0.027 | 0.5556 ± 0.0124
FLTrust | none | 78.719 ± 0.175 | 0.5580 ± 0.0099
ReferenceOnly | none | 73.657 ± 3.288 | 0.6970 ± 0.0947
TransportMean | none | 78.997 ± 0.027 | 0.5510 ± 0.0123
MGT-Med | none | 78.657 ± 0.202 | 0.5536 ± 0.0135
Mean | signflip | 33.333 ± 0.139 | 9.6106 ± 4.3173
Median | signflip | 77.438 ± 0.149 | 0.5858 ± 0.0054
TrimmedMean | signflip | 77.037 ± 0.350 | 0.5981 ± 0.0035
FLTrust | signflip | 77.670 ± 1.029 | 0.5811 ± 0.0182
ReferenceOnly | signflip | 73.657 ± 3.288 | 0.6970 ± 0.0947
TransportMean | signflip | 43.580 ± 3.449 | 1.0991 ± 0.0488
MGT-Med | signflip | 77.238 ± 0.632 | 0.5825 ± 0.0114
Mean | alie | 78.873 ± 0.096 | 0.5859 ± 0.0069
Median | alie | 78.889 ± 0.160 | 0.5870 ± 0.0093
TrimmedMean | alie | 78.719 ± 0.360 | 0.6035 ± 0.0076
FLTrust | alie | 78.503 ± 0.149 | 0.5638 ± 0.0091
ReferenceOnly | alie | 73.657 ± 3.288 | 0.6970 ± 0.0947
TransportMean | alie | 79.012 ± 0.141 | 0.5827 ± 0.0060
MGT-Med | alie | 78.611 ± 0.212 | 0.5797 ± 0.0073
Mean | transport_aware | 33.241 ± 0.080 | 75.3769 ± 10.1553
Median | transport_aware | 77.608 ± 0.430 | 0.5825 ± 0.0053
TrimmedMean | transport_aware | 77.052 ± 0.279 | 0.5944 ± 0.0045
FLTrust | transport_aware | 78.565 ± 0.185 | 0.5629 ± 0.0082
ReferenceOnly | transport_aware | 73.657 ± 3.288 | 0.6970 ± 0.0947
TransportMean | transport_aware | 33.333 ± 0.139 | 14.9202 ± 4.7213
MGT-Med | transport_aware | 78.025 ± 0.271 | 0.5677 ± 0.0098

## Method and scope notes
- A client profile is fixed MCAR per coordinate and known to the server. Attacker profiles are fixed, but gradient messages are arbitrary.
- The primary252fits redraw private masks at each minibatch access: a streaming/repeated-acquisition simulation. They do not model a permanently incomplete database. The separate48-fit static stress holds observed masks fixed.
- None: all eleven clients are honest; the other three attacks corrupt clients 9 and 10 (zero-based).
- Sign flip: each malicious raw gradient is -5 times the mean current honest raw gradient.
- ALIE-style: each malicious raw gradient is mean(honest raw) + 1.5 * coordinate population-SD(honest raw). This is a specified experimental variant, not a claim of exact reproduction of an original attack implementation.
- Transport-aware: each malicious raw message is its server correction d_i minus 5 times the current honest corrected-gradient mean. This attacker is granted the realized reference corrections as a deliberately stronger stress test.
- FLTrust follows nonnegative cosine trust scores and server-gradient norm normalization; if their sum is zero it falls back to the reference gradient. Required per-round server reference-gradient counts are one for FLTrust/ReferenceOnly, four for transport methods, zero for raw baselines.
- The StandardScaler is fit only on the complete trusted reference core and its fixed scaling statistics are shared by all methods. No complete private observation or test observation fits preprocessing. Masking is then applied to private examples.
- The complete reference core has 64 labeled samples and is reused adaptively. Population fresh-core concentration statements are not claimed as guarantees for these reused-core fits.
- Diagnostic reference gradients are computed even for raw baselines so paired diagnostics are available. Wall-clock values therefore include diagnostic overhead and must not be interpreted as fair algorithmic timing comparisons.
- The honest dispersion is mean squared distance to the honest-gradient mean; anchor distance is Euclidean distance from the honest coordinate median to the current minibatch target-reference gradient. Both are averaged over all 160 rounds.
- Baseline and proposed networks are the same tanh MLP; no pretrained representation, external images, GPU, or private benchmark data are used.
- Three seeds and two small real datasets plus a synthetic benchmark are initial evidence, not a full Neural Networks acceptance-level validation.

## Exact population counterexample
{
  "setting": "X1=X2=Y in {-1,1}, squared loss, exact population gradients, no Byzantine clients",
  "profiles_a": [
    0.95,
    0.2
  ],
  "profiles_b": [
    0.2,
    0.95
  ],
  "counts": [
    6,
    5
  ],
  "target": [
    0.65,
    0.65
  ],
  "target_optimum": [
    0.606060606060606,
    0.6060606060606061
  ],
  "majority_profile_optimum": [
    0.9876543209876543,
    0.06172839506172862
  ],
  "median_final": [
    0.9876543209876538,
    0.061728395061730085
  ],
  "transport_final": [
    0.606060606060606,
    0.606060606060606
  ],
  "median_target_loss": 0.16192272519432982,
  "transport_target_loss": 0.10606060606060608,
  "transport_max_optimality_error": 1.1102230246251565e-16
}

## Paired accuracy changes against raw Median
[
  {
    "dataset": "breast_cancer",
    "attack": "none",
    "mean_accuracy_difference_pp": 0.06497725795970855,
    "sd_difference_pp": 0.9615756066893315,
    "per_seed_difference_pp": [
      -0.3898635477582957,
      -0.5847953216374324,
      1.1695906432748537
    ]
  },
  {
    "dataset": "breast_cancer",
    "attack": "signflip",
    "mean_accuracy_difference_pp": 0.4548408057180116,
    "sd_difference_pp": 1.9911050612143661,
    "per_seed_difference_pp": [
      -0.9746588693956948,
      -0.3898635477582735,
      2.729044834308003
    ]
  },
  {
    "dataset": "breast_cancer",
    "attack": "alie",
    "mean_accuracy_difference_pp": 0.7797270955165692,
    "sd_difference_pp": 0.702836505938401,
    "per_seed_difference_pp": [
      0.9746588693957059,
      0.0,
      1.3645224171540016
    ]
  },
  {
    "dataset": "breast_cancer",
    "attack": "transport_aware",
    "mean_accuracy_difference_pp": 0.7147498375568644,
    "sd_difference_pp": 1.2532359663408608,
    "per_seed_difference_pp": [
      -0.19493177387912564,
      0.19493177387914784,
      2.1442495126705707
    ]
  },
  {
    "dataset": "digits",
    "attack": "none",
    "mean_accuracy_difference_pp": 0.14403292181069577,
    "sd_difference_pp": 0.7718106721609354,
    "per_seed_difference_pp": [
      0.12345679012345512,
      0.9259259259259078,
      -0.6172839506172756
    ]
  },
  {
    "dataset": "digits",
    "attack": "signflip",
    "mean_accuracy_difference_pp": 1.85185185185186,
    "sd_difference_pp": 1.900593125721061,
    "per_seed_difference_pp": [
      3.4567901234567877,
      2.3456790123456916,
      -0.24691358024689913
    ]
  },
  {
    "dataset": "digits",
    "attack": "alie",
    "mean_accuracy_difference_pp": 0.8230452674897193,
    "sd_difference_pp": 0.3399734905732089,
    "per_seed_difference_pp": [
      0.8024691358024749,
      1.1728395061728403,
      0.4938271604938427
    ]
  },
  {
    "dataset": "digits",
    "attack": "transport_aware",
    "mean_accuracy_difference_pp": 2.3868312757201653,
    "sd_difference_pp": 1.3876308888960789,
    "per_seed_difference_pp": [
      3.580246913580243,
      2.716049382716057,
      0.8641975308641969
    ]
  },
  {
    "dataset": "synthetic",
    "attack": "none",
    "mean_accuracy_difference_pp": -0.2623456790123472,
    "sd_difference_pp": 0.4660391626710416,
    "per_seed_difference_pp": [
      0.23148148148148806,
      -0.6944444444444531,
      -0.3240740740740766
    ]
  },
  {
    "dataset": "synthetic",
    "attack": "signflip",
    "mean_accuracy_difference_pp": -0.2006172839506141,
    "sd_difference_pp": 0.5788580041207009,
    "per_seed_difference_pp": [
      -0.6018518518518423,
      0.4629629629629539,
      -0.4629629629629539
    ]
  },
  {
    "dataset": "synthetic",
    "attack": "alie",
    "mean_accuracy_difference_pp": -0.27777777777778045,
    "sd_difference_pp": 0.2891202777036392,
    "per_seed_difference_pp": [
      -0.04629629629628873,
      -0.18518518518518823,
      -0.6018518518518645
    ]
  },
  {
    "dataset": "synthetic",
    "attack": "transport_aware",
    "mean_accuracy_difference_pp": 0.41666666666666147,
    "sd_difference_pp": 0.6018518518518423,
    "per_seed_difference_pp": [
      1.0185185185185075,
      -0.18518518518517713,
      0.4166666666666541
    ]
  }
]

## Domain-shift stress (20% random sample ordering, remaining samples sorted by class)
Dataset | Attack | Method | Accuracy (%) | CE
--- | --- | --- | --- | ---
digits | none | Mean | 86.95 ± 0.55 | 0.5086
digits | none | Median | 71.36 ± 3.40 | 1.1739
digits | none | TrimmedMean | 77.55 ± 3.21 | 0.9570
digits | none | FLTrust | 79.63 ± 4.30 | 0.8663
digits | none | ReferenceOnly | 78.23 ± 0.90 | 0.7344
digits | none | TransportMean | 86.98 ± 0.97 | 0.4910
digits | none | MGT-Med | 82.84 ± 0.80 | 0.8204
digits | transport_aware | Mean | 9.94 ± 0.11 | 137.6908
digits | transport_aware | Median | 37.98 ± 11.34 | 1.8048
digits | transport_aware | TrimmedMean | 39.67 ± 2.39 | 1.7176
digits | transport_aware | FLTrust | 72.43 ± 1.58 | 0.8996
digits | transport_aware | ReferenceOnly | 78.23 ± 0.90 | 0.7344
digits | transport_aware | TransportMean | 10.00 ± 0.00 | 24.4380
digits | transport_aware | MGT-Med | 71.56 ± 3.00 | 1.2130
breast_cancer | none | Mean | 96.36 ± 0.90 | 0.0995
breast_cancer | none | Median | 94.28 ± 1.30 | 0.1425
breast_cancer | none | TrimmedMean | 95.52 ± 1.03 | 0.1135
breast_cancer | none | FLTrust | 95.45 ± 0.68 | 0.1182
breast_cancer | none | ReferenceOnly | 95.52 ± 0.85 | 0.1160
breast_cancer | none | TransportMean | 88.89 ± 6.95 | 0.3073
breast_cancer | none | MGT-Med | 95.97 ± 0.23 | 0.1074
breast_cancer | transport_aware | Mean | 9.10 ± 0.68 | 181.7463
breast_cancer | transport_aware | Median | 91.62 ± 3.04 | 0.2115
breast_cancer | transport_aware | TrimmedMean | 92.92 ± 1.24 | 0.1636
breast_cancer | transport_aware | FLTrust | 95.52 ± 0.52 | 0.1192
breast_cancer | transport_aware | ReferenceOnly | 95.52 ± 0.85 | 0.1160
breast_cancer | transport_aware | TransportMean | 8.51 ± 2.51 | 40.2202
breast_cancer | transport_aware | MGT-Med | 95.97 ± 0.45 | 0.1175

## Fixed observed-mask stress
Every private example is assigned a single independent mask at setup and that mask is reused at each access. Reference masks remain fresh; server knows the underlying generating profiles as an experimental oracle. Three paired seeds. Same64-sample reference-only standardization as the main experiment.
Dataset | Attack | Method | Accuracy (%) | CE
--- | --- | --- | --- | ---
digits | none | Median | 85.494 ± 0.802 | 0.5383
digits | none | FLTrust | 86.070 ± 0.593 | 0.5455
digits | none | ReferenceOnly | 77.881 ± 1.249 | 0.7372
digits | none | MGT-Med | 86.132 ± 1.675 | 0.4976
digits | transport_aware | Median | 80.844 ± 2.151 | 0.7719
digits | transport_aware | FLTrust | 85.103 ± 0.677 | 0.5676
digits | transport_aware | ReferenceOnly | 77.881 ± 1.249 | 0.7372
digits | transport_aware | MGT-Med | 83.498 ± 1.269 | 0.6458
breast_cancer | none | Median | 94.867 ± 0.450 | 0.1257
breast_cancer | none | FLTrust | 95.387 ± 1.074 | 0.1229
breast_cancer | none | ReferenceOnly | 95.582 ± 0.962 | 0.1167
breast_cancer | none | MGT-Med | 93.957 ± 0.975 | 0.1409
breast_cancer | transport_aware | Median | 94.022 ± 0.921 | 0.1638
breast_cancer | transport_aware | FLTrust | 95.192 ± 1.108 | 0.1289
breast_cancer | transport_aware | ReferenceOnly | 95.582 ± 0.962 | 0.1167
breast_cancer | transport_aware | MGT-Med | 94.022 ± 0.685 | 0.1464

## Nested reference-budget sensitivity
Digits under sign flip. A fixed128-sample reference reserve is removed from private training; reference sizes16/64/128 are nested. Every budget shares a scaler fitted to the first16 reference observations, preventing changing transformed private data. Three paired seeds. This sensitivity differs from the main reference64 scaler.
Reference size | Method | Accuracy (%) | CE
--- | --- | --- | ---
16 | ReferenceOnly | 49.239 ± 6.968 | 2.1812
16 | FLTrust | 62.407 ± 19.635 | 1.2417
16 | MGT-Med | 78.642 ± 1.113 | 0.7570
64 | ReferenceOnly | 78.189 ± 1.574 | 0.7142
64 | FLTrust | 84.609 ± 0.715 | 0.5935
64 | MGT-Med | 82.798 ± 1.197 | 0.6759
128 | ReferenceOnly | 82.490 ± 0.600 | 0.6040
128 | FLTrust | 84.424 ± 0.822 | 0.5910
128 | MGT-Med | 82.551 ± 1.037 | 0.6716

## Independent fixed-parameter diagnostic
A separate8-dimensional synthetic population, three classes, hidden12,60,000 Monte Carlo target examples and12 independent replications. No diagnostic example was used for training/tuning. Same initialized parameter for all profiles;512 fresh examples per client. Population transport is an oracle comparison, not a feasible method.
Reference size | Raw median error | Estimated transport error | MC population correction error | Raw dispersion | Corrected dispersion
--- | --- | --- | --- | --- | ---
16 | 0.05820 ± 0.00799 | 0.23536 ± 0.04722 | 0.03878 ± 0.00899 | 0.03000 ± 0.00297 | 0.08793 ± 0.01768
64 | 0.05820 ± 0.00799 | 0.12861 ± 0.01463 | 0.03878 ± 0.00899 | 0.03000 ± 0.00297 | 0.02753 ± 0.00472
128 | 0.05820 ± 0.00799 | 0.09476 ± 0.01363 | 0.03878 ± 0.00899 | 0.03000 ± 0.00297 | 0.01915 ± 0.00246
512 | 0.05820 ± 0.00799 | 0.05884 ± 0.00754 | 0.03878 ± 0.00899 | 0.03000 ± 0.00297 | 0.01239 ± 0.00170
2048 | 0.05820 ± 0.00799 | 0.04582 ± 0.00809 | 0.03878 ± 0.00899 | 0.03000 ± 0.00297 | 0.01064 ± 0.00154
8192 | 0.05820 ± 0.00799 | 0.03949 ± 0.00917 | 0.03878 ± 0.00899 | 0.03000 ± 0.00297 | 0.00996 ± 0.00136