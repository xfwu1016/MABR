"""Integrity checks for data splits, malformed-message guards and saved results."""
import csv,json,hashlib
from pathlib import Path
import numpy as np
from sklearn.datasets import load_breast_cancer,load_digits,make_classification
from sklearn.model_selection import train_test_split
from run_experiments import aggregate,gradient_check,CONFIG,run
ROOT=Path(__file__).resolve().parent
report={'gradient_check':gradient_check(),'split_checks':[]}
for dataset in ['breast_cancer','digits','synthetic']:
    if dataset=='breast_cancer':ds=load_breast_cancer();y=ds.target
    elif dataset=='digits':ds=load_digits();y=ds.target
    else:
        _,y=make_classification(n_samples=2400,n_features=20,n_informative=12,n_redundant=4,n_classes=3,
                               n_clusters_per_class=1,class_sep=1.,flip_y=.03,random_state=1729)
    for seed in [0,1,2]:
        ids=np.arange(len(y))
        pool,test,yp,_=train_test_split(ids,y,test_size=.3,stratify=y,random_state=100+seed)
        private,core,_,_=train_test_split(pool,yp,test_size=64,stratify=yp,random_state=200+seed)
        groups=[set(z.tolist()) for z in [private,core,test]]
        disjoint=not(groups[0]&groups[1] or groups[0]&groups[2] or groups[1]&groups[2])
        if not disjoint:raise AssertionError((dataset,seed))
        report['split_checks'].append(dict(dataset=dataset,seed=seed,private=len(private),reference=len(core),test=len(test),disjoint=disjoint))
gg=np.zeros((11,5));gg[0]=np.nan
accepted,_=aggregate(gg,'Median',np.ones(5),2)
report['nonfinite_message_rejected']=bool(np.array_equal(accepted,np.zeros(5)))
try:aggregate(np.zeros((11,4)),'Median',np.ones(5),2)
except ValueError:report['wrong_shape_rejected']=True
else:raise AssertionError('Malformed shape accepted')
try:aggregate(np.zeros((4,5)),'Median',np.ones(5),2)
except ValueError:report['accepted_majority_guard_passed']=True
else:raise AssertionError('Insufficient majority accepted')
for name,n in [('main',252),('stress',84),('static',48),('budget',27)]:
    p=ROOT/f'{name}_runs.csv'
    with p.open() as f:rows=list(csv.DictReader(f))
    if len(rows)!=n:raise AssertionError((name,len(rows),n))
    if not all(np.isfinite(float(r['test_ce'])) and 0<=float(r['test_accuracy'])<=1 for r in rows):raise AssertionError(name)
    report[name]=dict(n_rows=len(rows),finite_metrics=True,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
with (ROOT/'main_runs.csv').open() as f:rows=list(csv.DictReader(f))
for d in ['breast_cancer','digits','synthetic']:
    for seed in [0,1,2]:
        rr=[r for r in rows if r['dataset']==d and int(r['seed'])==seed and r['method']=='ReferenceOnly']
        if len({r['parameter_sha256'] for r in rr})!=1:raise AssertionError('ReferenceOnly depends on attack')
report['reference_only_attack_independence']=True
report['current_source_replay_checks']=[]
for d in ['breast_cancer','digits','synthetic']:
    original=next(r for r in rows if r['dataset']==d and r['seed']=='0' and r['attack']=='signflip' and r['method']=='MGT-Med')
    replay,_,_=run(d,0,'signflip','MGT-Med')
    same=replay['parameter_sha256']==original['parameter_sha256']
    if not same:raise AssertionError(('Source replay mismatch',d))
    report['current_source_replay_checks'].append(dict(dataset=d,seed=0,attack='signflip',method='MGT-Med',exact_parameter_hash_match=same))
report['source_sha256']=hashlib.sha256((ROOT/'run_experiments.py').read_bytes()).hexdigest()
(ROOT/'integrity_checks.json').write_text(json.dumps(report,indent=2))
(ROOT/'config.json').write_text(json.dumps(CONFIG,indent=2))
print(json.dumps(report,indent=2))
