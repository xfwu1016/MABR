"""Fixed observed-mask stress; each private example is masked once only."""
import csv,json
from pathlib import Path
from run_experiments import run,append_csv
ROOT=Path(__file__).resolve().parent
rows=ROOT/'static_runs.csv';curves=ROOT/'static_curves.csv'
done=set()
if rows.exists():
    with rows.open() as f:done={(r['dataset'],int(r['seed']),r['attack'],r['method']) for r in csv.DictReader(f)}
for dataset in ['digits','breast_cancer']:
    for seed in [0,1,2]:
        for attack in ['none','transport_aware']:
            for method in ['Median','FLTrust','ReferenceOnly','MGT-Med']:
                if (dataset,seed,attack,method) in done:continue
                row,cs,meta=run(dataset,seed,attack,method,static_masks=True)
                append_csv(rows,[row]);append_csv(curves,cs)
                print(f'static {dataset} seed{seed} {attack} {method}: {row["test_accuracy"]:.4f}',flush=True)
(ROOT/'static_protocol.json').write_text(json.dumps(dict(
    private_masks='One independently generated Bernoulli mask per private example, held fixed across all rounds',
    reference_masks='Fresh coupled Bernoulli masks on the reused complete reference core each round',
    profiles='Generating probabilities treated as known; not estimated from fixed pools',
    seeds=[0,1,2],datasets=['digits','breast_cancer'],attacks=['none','transport_aware'],
    methods=['Median','FLTrust','ReferenceOnly','MGT-Med'],expected_fits=48,
    test='Same target-mask .65, three fixed independent masks per test example',
    no_claim='Does not demonstrate recovery of permanently missing private values or MAR/MNAR handling'),indent=2))
