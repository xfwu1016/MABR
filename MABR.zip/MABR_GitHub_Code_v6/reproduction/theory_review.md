# Theory audit and integration notes

Verified by direct algebra and numerical checks; no literature novelty claim is made here.

## Integration

- `theory.tex` is the main-text module and refers to a parent method section labeled `sec:method`.
- `appendix_proofs.tex` contains full proofs and should follow `\appendix`.
- The parent preamble must load `amsmath`, `amssymb`, and `amsthm` and define `proposition` and `theorem` environments.
- Main algorithm is named MGT-Med. All honest reports are gradients at the same broadcast parameter, with one report per round. Plain gradient descent is the algorithm covered by the descent theorem.
- Symbols: input dimension `s`, network parameter dimension `d`, Byzantine count upper bound `b`, reference population `P_0`, finite reference core separate, target profile `p_\star`.
- The output risk is for the fixed target missingness profile. It is not full-observation test risk unless that profile is all ones.

## Claims and their scope

1. Exact gradient transport is an algebraic identity under the specified mask laws. It removes the mask-shift term when `P_i=P_0`; arbitrary domain shift is an explicit residual.
2. The coordinate-median guarantee is deterministic, requires a strict honest majority, and has a dimension-dependent Euclidean bound. It neither identifies attackers nor promises breakdown robustness above one half.
3. Estimated honest profiles have a provable perturbation bound under bounded coordinate gradients. Maliciously reported profiles remain arbitrary Byzantine reports after a finite correction.
4. The smooth descent theorem establishes stationarity up to a gradient-error floor. It gives neither global optimality, parameter recovery nor improved test accuracy.
5. The paired-reference Bernstein result uses a fixed parameter independent of a fresh calibration draw. It does not yield a round-by-round population rate for an adaptively reused core. Reused-core results must be presented empirically and under the deterministic decomposition.

## Assumptions that must remain visible

- Client masks are product Bernoulli and independent of complete covariates and labels within each client (client-specific MCAR). MAR/MNAR and dependent block masks are not covered by the probability-vector formula.
- The trusted core must be disjoint from client training/evaluation samples and uncorrupted.
- For finite coordinate-gradient bounds, the analyzed data/parameter region must support such bounds. A tanh network alone does not bound every parameter gradient globally, because downstream weights can be arbitrarily large.
- Smoothness is required on every update segment; boundedness of iterates is not established by the current theorem.
- Changing the target profile, using Adam/momentum, adding local epochs, clipping reports or projecting updates requires modifying the theorem or distinguishing an empirical variant.
- For tabular features, missing entries must not be used in preprocessing statistics. A reference-only scaler is simplest and must be disclosed as an additional reference resource.

## What the reference changes

The method uses complete labeled reference data, known/enrolled honest mask profiles and server gradient computations. Fair evaluation should therefore include a reference-only network, a reference-matched uncorrected robust aggregator, and a transport-with-mean ablation. The comparison must count the server work (potentially one reference gradient per profile per round), even though this does not increase gradient-report communication. A general claim of privacy preservation or secure aggregation is unsupported.

## Exact illustrative calculation

For `X1=X2=Y` Rademacher, squared loss and `p=(0.95,0.20)`, the local minimizer is `(0.9876543209876543, 0.06172839506172845)`. At target `(0.65,0.65)`, the optimum is `(0.6060606060606061, 0.6060606060606061)`. The wrong minimizer has target excess risk `0.055862119133724034` and target gradient norm `0.19343709522208`. These are population calculations, not trained experimental results.

## Remaining author/research decisions

- Establish that the reference-assisted mechanism offers useful gains over calibration-matched controls; theory alone does not establish that.
- Determine whether real enrollment profiles are available or estimated; exact profiles used in simulation should be named an oracle-profile setting.
- Independently compare the method against existing reference-assisted FL defenses and covariate-shift gradient corrections before claiming novelty.
- The theorem constants are intentionally conservative. Do not describe them as tight, minimax, or optimal.
