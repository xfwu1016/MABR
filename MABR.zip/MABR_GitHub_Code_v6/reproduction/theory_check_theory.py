"""Reproducible algebra and inequality checks for the theory module.

Dependencies: Python 3 and NumPy only. No trained empirical result is produced.
Run from this directory or any working directory.
"""
from __future__ import annotations

import itertools
import json

import numpy as np


def risk_hessian(p):
    p = np.asarray(p, dtype=float)
    return np.array([[p[0], p.prod()], [p.prod(), p[1]]])


def exact_mask_expectation(p, function):
    p = np.asarray(p, dtype=float)
    total = None
    for bits in itertools.product((0, 1), repeat=len(p)):
        mask = np.asarray(bits, dtype=float)
        prob = np.prod(np.where(mask == 1, p, 1 - p))
        value = np.asarray(function(mask), dtype=float)
        total = prob * value if total is None else total + prob * value
    return total


def main():
    rng = np.random.default_rng(20261028)
    p = np.array([0.95, 0.20])
    q = np.array([0.65, 0.65])
    hp, hq = risk_hessian(p), risk_hessian(q)
    wp, wq = np.linalg.solve(hp, p), np.linalg.solve(hq, q)
    excess = float(0.5 * (wp - wq) @ hq @ (wp - wq))
    assert excess > 0.05
    assert np.linalg.norm(hp @ wp - p) < 1e-14
    assert np.linalg.eigvalsh(hp).min() > 0
    assert np.linalg.eigvalsh(hq).min() > 0

    transport_maxerr = 0.0
    for _ in range(1000):
        w = rng.normal(size=2)
        local_gradient = hp @ w - p
        target_gradient = hq @ w - q
        correction = (hp - hq) @ w - (p - q)
        err = np.max(np.abs(local_gradient - correction - target_gradient))
        transport_maxerr = max(transport_maxerr, float(err))
    assert transport_maxerr < 1e-12

    # Enumerated nonlinear mask-gradient coordinates: arbitrary bounded values
    # are sufficient to check the profile-sensitivity inequality.
    profile_ratios = []
    for _ in range(300):
        a, c = rng.uniform(size=(2, 4))
        lookup = rng.uniform(-1, 1, size=(16, 5))
        def h(mask):
            index = sum(int(v) << k for k, v in enumerate(mask))
            return lookup[index]
        mu_a = exact_mask_expectation(a, h)
        mu_c = exact_mask_expectation(c, h)
        r = 1 - np.prod(1 - np.abs(a - c))
        bound = 2 * r
        gap = float(np.abs(mu_a - mu_c).max())
        assert gap <= bound + 1e-12
        assert r <= min(1.0, np.abs(a - c).sum()) + 1e-12
        profile_ratios.append(gap / bound)

    # Both odd/even medians must remain in the honest common interval.
    median_max_violation = 0.0
    for n, b in ((11, 3), (10, 4), (7, 3), (12, 5)):
        for _ in range(100):
            d = 19
            center = rng.normal(size=d)
            radius = rng.uniform(0.01, 1, size=d)
            honest = center + rng.uniform(-1, 1, size=(n - b, d)) * radius
            byzantine = rng.normal(size=(b, d)) * 1e8
            aggregate = np.median(np.vstack((honest, byzantine)), axis=0)
            violation = float((np.abs(aggregate - center) - radius).max())
            median_max_violation = max(median_max_violation, violation)
            assert violation <= 1e-9

    # Smooth descent for positive-semidefinite quadratics, arbitrary biased
    # directions and admissible step sizes.
    descent_max_violation = 0.0
    for _ in range(1000):
        d = 7
        z = rng.normal(size=(d, d))
        hessian = z.T @ z + 0.01 * np.eye(d)
        L = np.linalg.eigvalsh(hessian).max()
        eta = rng.uniform(0.01, 1.0) / L
        theta = rng.normal(size=d)
        grad = hessian @ theta
        error = rng.normal(size=d) * 2
        theta_next = theta - eta * (grad + error)
        f = 0.5 * theta @ hessian @ theta
        f_next = 0.5 * theta_next @ hessian @ theta_next
        rhs = f - eta / 2 * (grad @ grad) + eta / 2 * (error @ error)
        violation = float(f_next - rhs)
        descent_max_violation = max(descent_max_violation, violation)
        assert violation <= 1e-9

    # Check Bernstein's conservative inversion algebra, not its probability
    # law: epsilon^2 >= 2(v + M*epsilon/3)*a/B.
    bernstein_min_slack = float("inf")
    for _ in range(1000):
        v = rng.uniform(0, 8)
        M = rng.uniform(0.1, 4)
        a = rng.uniform(0.1, 30)
        B = int(rng.integers(1, 1000))
        epsilon = np.sqrt(2 * v * a / B) + 2 * M * a / (3 * B)
        slack = float(epsilon**2 - 2 * (v + M * epsilon / 3) * a / B)
        bernstein_min_slack = min(bernstein_min_slack, slack)
        assert slack >= -1e-12

    result = {
        "status": "PASS",
        "seed": 20261028,
        "checks": {
            "exact_transport_max_absolute_error": transport_maxerr,
            "profile_sensitivity_max_observed_bound_ratio": max(profile_ratios),
            "median_max_positive_violation": median_max_violation,
            "descent_max_positive_violation": descent_max_violation,
            "bernstein_inversion_min_slack": bernstein_min_slack,
        },
        "population_example": {
            "local_profile": p.tolist(),
            "target_profile": q.tolist(),
            "local_minimizer": wp.tolist(),
            "target_minimizer": wq.tolist(),
            "target_excess_risk_at_local_minimizer": excess,
            "target_gradient_norm_at_local_minimizer": float(np.linalg.norm(hq @ wp - q)),
        },
        "note": "These are algebra/inequality checks, not empirical training or a proof substitute.",
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
