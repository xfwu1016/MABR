# Reproducible neural experiments

These files contain initial CPU experiments for Missingness-Aware
Byzantine-Robust Federated Neural Learning. They do not establish state-of-the-art
performance or clinical validity.

Install the versions in `requirements.txt`, then run:

```
python run_experiments.py
python run_experiments.py --stress
python additional_checks.py
python static_checks.py
python validate_experiments.py
python summarize.py
```

The runners resume completed keys from CSV files. To repeat every fit independently,
use a fresh copy of the source directory without the existing result CSV files.
The three main seeds, all seven methods and all four attacks are retained.

`main_runs.csv` contains 252 fits using freshly redrawn private masks at every
minibatch access. `static_runs.csv` contains 48 fits with fixed observed private
masks. `stress_runs.csv` contains 84 fits with class-skewed client partitions.
`budget_runs.csv` contains 27 fits with nested trusted cores and fixed private data.
`fixed_theta_diagnostic.csv` contains 72 independent diagnostic replications
(12 draws at each of six calibration sizes), not extra training runs.

All primary preprocessing is fitted only to the complete trusted reference core.
The reference budget sensitivity uses a fixed128-example reserve, nested cores,
and a common scaler fitted on its first16 examples. Generating mask probabilities
are known in every experiment; profile estimation is not empirically evaluated.

Early pilot runs using latent-private preprocessing are excluded from this delivered research package and every manuscript result. Only the final reference-only preprocessing protocol is included.

`summary.csv`, LaTeX tables and all figures are derived from raw saved records by
`summarize.py`. Uncertainty is sample SD across seeds; three target masks inside
each seed are averaged. Figures are vector PDFs with corresponding PNG previews.
The independent diagnostic uses synthetic examples never used in training,
hyperparameter selection or checkpoint selection. Calibration sizes2048/8192
extend the initial diagnostic range to characterize reference-noise tradeoffs.

Wall-clock values include diagnostic computations even for baselines that do not
need them and must not be treated as fair algorithmic timing comparisons.
Required gradient-evaluation counts and scalar payload counts are recorded
separately. Trusted-core acquisition and preprocessing have additional costs.

Neural derivatives are analytic NumPy derivatives checked by finite differences.
The model uses tanh hidden activations and softmax cross entropy, SGD without
momentum, clipping or projection. `gradient_check.json`, `integrity_checks.json`
and `homogeneous_identity.json` report the implementation checks.
