# Final v3 evidence displays

All figures use the final official FLTrust numerical rules. Legacy, invalid-protocol,
and superseded-RNG records are excluded. No v2 or v3 manuscript source was modified
by this display task.

## Reproduce

Keep `visuals`, `fltrust`, and `natural` as sibling directories. With NumPy and
Matplotlib installed, run `make_figures.py`, `make_extensions.py`, and
`make_sensitivity.py`. The extension and sensitivity scripts require their final
completion markers; the product-natural script verifies its completion hash.
`verify_visuals.py` additionally needs Pillow and pypdf.

The scripts retain all tested settings and all paired seeds. They do not fit
models, tune settings, select test checkpoints, smooth the observations, or
perform significance tests. PDF byte hashes may change on regeneration because
of PDF metadata; the source-data hashes provide the evidence link.

## Outputs

- `figures/fltrust_paired_differences`: both datasets, all five attacks,
  MGT--Med minus Median, FLTrust and FLTrust-CM. Five paired seeds.
- `figures/natural_paired_differences`: both native-missingness datasets,
  all two allocations and three attacks, MGT--Med minus Median and FLTrust.
  Five paired seeds.
- `figures/joint_mask_paired_differences`: all native-missingness cells,
  joint MGT minus product MGT and joint FLTrust. Five paired seeds.
- `figures/width_rate_round160` and `width_rate_round320`: complete Digits
  width/rate grid, all five methods and two attacks at both fixed checkpoints.
  Three paired seeds, 180 fits in total.

The first three figure types are 7.0 by 3.2 inches; the sensitivity types are
7.0 by 4.6 inches. PDF is vector and uses embedded TrueType fonts. PNG uses
300 dpi, with white opaque background. Font sizes are 8.2--9.5 pt in the figure
source, except the global default of 8.5 pt. Final manuscript layout remains
the main integrator's responsibility.

For paired-difference plots, open symbols show every seed; filled symbols and
whiskers show the arithmetic mean and one **sample SD of the paired differences**.
Each dataset panel has its own explicitly labelled horizontal limits. These
are percentage-point differences, not relative percentage changes or patient
confidence intervals. The captions must retain the different-panel-scale note.

The ten unique full-method tables include accuracy, balanced accuracy and
cross-entropy for the main, native-product and native-joint studies, and all
width/rate accuracy results. `joint_{accuracy,balanced_accuracy,ce}.tex` are
aliases of `natural_joint_*` with identical labels (`tab:natural-joint-*`);
input only one set. Tables were precompiled at CAS-DC's 173.8 mm text width
without an overfull box. `figure_blocks.tex` supplies optional insertion blocks.

## Interpretation boundaries

Root-cone is the specified finite directional stress with current-reference
white-box access. A large MGT--Med versus FLTrust difference there must not be
attributed entirely to transport: the corresponding comparison with Median is
also shown. The fixed grid is not a universally optimal adaptive attack.

Original missing masks are preserved in the natural-data studies. Federation
and attacks are simulated, complete-case calibration can introduce selection
bias, and the marginal mask laws do not identify a conditional natural
missingness mechanism. Joint versus product MGT changes the calibration law
and target anchor and, for root-cone, the realized attack. That comparison is
descriptive rather than a one-factor causal experiment.

`provenance.json`, `joint_provenance.json`, and `sensitivity_provenance.json`
record source hashes and transforms. `visual_metadata_checks.json` records
physical size, pixel size, dpi, opacity and final input hashes. All five final
PNG figures were visually inspected for clipping and readability. The
standalone preflight files are QA artifacts, not manuscript deliverables.
