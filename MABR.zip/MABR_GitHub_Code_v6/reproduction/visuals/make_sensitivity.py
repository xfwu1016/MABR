"""All-cell width/step-size sensitivity; final checkpoint fixed by protocol."""
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from make_figures import ROOT,HERE,OUT,TABLES,read,sha,save_csv,style

METHODS=['Median','FLTrust','FLTrust-CM','MGT-Med','TransportFLTrust']
COLORS=['#009E73','#0072B2','#666666','#D55E00','#AA4499']
MARKERS=['o','s','D','^','v']
LINES=['-','--',':','-.',(0,(3,1,1,1))]
LABELS=['Median','FLTrust','FLTrust-CM','MGT–Med','Transport FLTrust']

def main():
    source=ROOT/'fltrust'/'sensitivity'/'sensitivity_runs.csv'
    complete=ROOT/'fltrust'/'sensitivity'/'COMPLETE.json'
    assert complete.exists(),'Sensitivity run not finalized'
    marker=json.loads(complete.read_text(encoding='utf-8'))
    assert marker['status']=='COMPLETE_PRIMARY_OFFICIAL_RULES' and marker['runs_sha256']==sha(source)
    rows=read(source);assert len(rows)==360
    ratevals=[.05,.15,.3]
    fields=['hidden','learning_rate','seed','rounds']
    for row in rows:
        for k in fields:row[k]=float(row[k]) if k=='learning_rate' else int(row[k])
    output_summary=[]
    for rounds in [160,320]:
        with style():
            fig,axes=plt.subplots(2,2,figsize=(7,4.6),sharex=True,sharey=True)
            fig.subplots_adjust(left=.085,right=.985,bottom=.19,top=.925,hspace=.28,wspace=.12)
            all_limits=[]
            for i,width in enumerate([12,48]):
                for j,attack in enumerate(['signflip','root_aligned']):
                    ax=axes[i,j]
                    for k,method in enumerate(METHODS):
                        means=[];sds=[]
                        for xi,rate in enumerate(ratevals):
                            subset=[r for r in rows if r['rounds']==rounds and r['hidden']==width and r['attack']==attack and r['method']==method and abs(r['learning_rate']-rate)<1e-12]
                            assert sorted(r['seed'] for r in subset)==[0,1,2]
                            acc=np.array([float(r['test_accuracy'])*100 for r in sorted(subset,key=lambda r:r['seed'])])
                            means.append(float(acc.mean()));sds.append(float(acc.std(ddof=1)))
                            ax.scatter(rate+np.linspace(-.0025,.0025,3),acc,s=8,color=COLORS[k],marker=MARKERS[k],alpha=.35,edgecolors='none',zorder=2)
                            output_summary.append(dict(rounds=rounds,hidden=width,attack=attack,learning_rate=rate,method=method,n=3,accuracy_mean_percent=float(acc.mean()),accuracy_sample_sd_percent=float(acc.std(ddof=1))))
                        ax.errorbar(ratevals,means,yerr=sds,color=COLORS[k],marker=MARKERS[k],markersize=3.6,ls=LINES[k],lw=.9,elinewidth=.7,capsize=1.8,label=LABELS[k],zorder=3)
                        all_limits.extend(np.array(means)-np.array(sds));all_limits.extend(np.array(means)+np.array(sds))
                    ax.set_title(('Sign flip' if attack=='signflip' else 'Root-cone')+f'; {width} hidden units',loc='left',pad=5)
                    ax.set_xticks(ratevals,['0.05','0.15','0.30']);ax.set_xlim(.035,.315)
                    ax.grid(axis='y',color='#e6e6e6',lw=.5);ax.set_axisbelow(True)
                    if j==0:ax.set_ylabel('Accuracy (%)')
                    if i==1:ax.set_xlabel('Learning rate')
            lo=min(all_limits);hi=max(all_limits);span=max(hi-lo,10)
            axes[0,0].set_ylim(lo-.08*span,hi+.08*span)
            handles,labels=axes[0,0].get_legend_handles_labels()
            fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.52,.015),ncol=5,frameon=False,columnspacing=1.0,handlelength=1.5)
            for fmt in ['pdf','png']:fig.savefig(OUT/f'width_rate_round{rounds}.{fmt}',dpi=300,facecolor='white')
            plt.close(fig)
    save_csv(HERE/'width_rate_summary.csv',output_summary)
    lines=['\\begin{table*}[t]','\\centering',
       '\\caption{Complete Digits width--step-size sensitivity: final accuracy in percent (mean $\\pm$ sample SD over three paired split/training seeds). All 180 fits are retained; each contributes checkpoints at rounds 160 and 320. No setting or checkpoint is selected using test outcomes.}',
       '\\label{tab:width-rate-sensitivity}','\\scriptsize','\\setlength{\\tabcolsep}{4pt}',
       '\\begin{tabular}{llrrrrrr}','\\toprule',
       'Round & Attack & Hidden & $\\eta$ & Median & FLTrust & FLTrust-CM & MGT--Med & Transport-FLTrust\\\\']
    # Nine columns (two labels, two settings, five methods).
    lines[6]='\\begin{tabular}{llrrrrrrr}'
    lines.append('\\midrule')
    for rounds in [160,320]:
        for attack in ['signflip','root_aligned']:
            for width in [12,48]:
                for rate in ratevals:
                    vals=[]
                    for method in METHODS:
                        a=[r for r in output_summary if r['rounds']==rounds and r['attack']==attack and r['hidden']==width and r['learning_rate']==rate and r['method']==method][0]
                        vals.append(f"{a['accuracy_mean_percent']:.2f} $\\pm$ {a['accuracy_sample_sd_percent']:.2f}")
                    lines.append(' & '.join([str(rounds),'Sign flip' if attack=='signflip' else 'Root-cone',str(width),f'{rate:.2f}']+vals)+'\\\\')
        if rounds==160:lines.append('\\midrule')
    lines.extend(['\\bottomrule','\\end{tabular}','\\end{table*}'])
    (TABLES/'width_rate_sensitivity.tex').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    record={'date':'2026-10-29','raw_source':{'path':str(source),'relative_path':source.relative_to(ROOT).as_posix(),'sha256':sha(source),'rows':360,'fits':180},
       'transformations':['Group by attack, width, rate, method and fixed checkpoint.','Multiply accuracy by 100; compute mean and sample SD (ddof=1) across all three paired seeds.','All 180 fits and both fixed checkpoints retained.'],
       'uncertainty':'Sample SD of three paired split/training seeds, not patient-level confidence intervals.',
       'figures':['width_rate_round160','width_rate_round320'],'dimensions_inches':[7,4.6],'dpi':300,
       'plot_selection':'Separate figures for two prespecified checkpoints; manuscript may show final round320 and retain round160/table in supplement. No best-test selection.',
       'packages':{'numpy':np.__version__,'matplotlib':matplotlib.__version__}}
    (HERE/'sensitivity_provenance.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    print('Rendered all 180 fits at both fixed checkpoints.')

if __name__=='__main__':main()
