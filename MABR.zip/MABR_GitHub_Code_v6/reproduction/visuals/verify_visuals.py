"""Metadata and input-completeness checks; visual review remains separate."""
from pathlib import Path
import hashlib, json, csv
from pypdf import PdfReader
from PIL import Image

HERE=Path(__file__).resolve().parent
names=['fltrust_paired_differences','natural_paired_differences','joint_mask_paired_differences','width_rate_round160','width_rate_round320']
report={'date':'2026-10-29','figures':[],'source_integrity':[]}
for name in names:
    pdf=HERE/'figures'/f'{name}.pdf';png=pdf.with_suffix('.png')
    pages=PdfReader(pdf).pages;assert len(pages)==1
    targeth=4.6 if name.startswith('width_rate') else 3.2
    w,h=float(pages[0].mediabox.width)/72,float(pages[0].mediabox.height)/72
    assert abs(w-7)<1e-5 and abs(h-targeth)<1e-5
    im=Image.open(png)
    assert im.size==(2100,round(targeth*300))
    dpi=im.info.get('dpi');assert dpi and all(abs(x-300)<.1 for x in dpi)
    opaque=im.mode!='RGBA' or im.getchannel('A').getextrema()==(255,255)
    assert opaque
    fonts=[]
    for _,ref in pages[0]['/Resources'].get('/Font',{}).items():
        font=ref.get_object()
        candidates=font.get('/DescendantFonts',[font])
        embedded=False
        for candidate in candidates:
            candidate=candidate.get_object()
            desc=candidate.get('/FontDescriptor')
            if desc:
                desc=desc.get_object()
                embedded=embedded or any(k in desc for k in ['/FontFile','/FontFile2','/FontFile3'])
        fonts.append({'font':str(font.get('/BaseFont')),'embedded':embedded})
    assert fonts and all(f['embedded'] for f in fonts)
    report['figures'].append({'file':name,'pdf_pages':len(pages),'inches':[w,h],'png_pixels':im.size,'png_dpi':dpi,'opaque':opaque,'fonts':fonts,'sha256_pdf':hashlib.sha256(pdf.read_bytes()).hexdigest()})
for fname in ['provenance.json','joint_provenance.json','sensitivity_provenance.json']:
    rec=json.loads((HERE/fname).read_text())
    sources=rec.get('raw_sources',[rec.get('raw_source')])
    for s in sources:
        if s is None:continue
        p=HERE.parent/s['relative_path'] if 'relative_path' in s else Path(s['path'])
        actual=hashlib.sha256(p.read_bytes()).hexdigest();assert actual==s['sha256'],(fname,p)
        report['source_integrity'].append({'provenance':fname,'source':str(p),'sha256_matches':True})
report['limits']='Metadata and completeness checks do not certify scientific validity, accessibility, or journal acceptance. All five final PNGs are separately visually inspected.'
(HERE/'visual_metadata_checks.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({'figures_checked':len(report['figures']),'raw_source_hashes_checked':len(report['source_integrity'])}))
