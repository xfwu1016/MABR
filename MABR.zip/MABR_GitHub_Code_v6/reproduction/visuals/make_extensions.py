"""Additional displays for finalized joint-mask and training-sensitivity records."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from make_figures import ROOT,HERE,OUT,TABLES,COLORS,MARKERS,ALABELS,DLABELS,read,sha,save_csv,style,cell

JOINT_METHODS=['Joint-FLTrust','Joint-MGT-Med','Joint-TransportFLTrust','Joint-ReferenceOnly']

def join_differences(joint,product,dataset,partition,attack,reference):
    filt=lambda z:z['dataset']==dataset and z['partition']==partition and z['attack']==attack
    target={int(z['seed']):float(z['test_balanced_accuracy']) for z in joint if filt(z) and z['method']=='Joint-MGT-Med'}
    source=product if reference=='MGT-Med' else joint
    baseline={int(z['seed']):float(z['test_balanced_accuracy']) for z in source if filt(z) and z['method']==reference}
    assert sorted(target)==sorted(baseline)==list(range(5))
    return np.array([100*(target[s]-baseline[s]) for s in range(5)])

def joint_figure(joint,product):
    conditions=[(p,a) for p in ['random','burden'] for a in ['none','signflip','root_aligned']]
    labels=[p.capitalize()+': '+ALABELS[a].lower() for p,a in conditions]
    names=['MGT-Med','Joint-FLTrust'];exports=[]
    with style():
        fig,axes=plt.subplots(1,2,figsize=(7,3.2))
        fig.subplots_adjust(left=.18,right=.98,bottom=.265,top=.89,wspace=.47)
        for panel,(ax,dataset) in enumerate(zip(axes,['mammographic_mass','hepatitis'])):
            values=[]
            for k,(p,a) in enumerate(conditions):
                for j,ref in enumerate(names):
                    delta=join_differences(joint,product,dataset,p,a,ref);y=k+(j-.5)*.24
                    ax.scatter(delta,y+np.linspace(-.055,.055,5),s=11,marker=MARKERS[j],facecolors='none',edgecolors=COLORS[j],linewidths=.65,alpha=.55,zorder=2)
                    mean=float(delta.mean());sd=float(delta.std(ddof=1))
                    ax.errorbar(mean,y,xerr=sd,fmt=MARKERS[j],ms=4,color=COLORS[j],mec='white',mew=.45,elinewidth=1.05,capsize=2,zorder=3)
                    values.extend(delta.tolist()+[mean-sd,mean+sd])
                    for seed,v in enumerate(delta):exports.append(dict(dataset=dataset,partition=p,attack=a,method='Joint-MGT-Med',reference=ref,seed=seed,metric='balanced_accuracy',difference_percentage_points=float(v)))
            lo=min(min(values),0);hi=max(max(values),0);span=max(hi-lo,2)
            ax.set_xlim(lo-.12*span,hi+.12*span)
            ax.axvline(0,color='#555555',lw=.8,ls=(0,(3,2)),zorder=0)
            ax.set_yticks(range(len(conditions)),labels);ax.set_ylim(len(conditions)-.43,-.6)
            ax.grid(axis='x',color='#e5e5e5',lw=.55);ax.set_axisbelow(True)
            ax.set_title(f'({chr(97+panel)}) {DLABELS[dataset]}',loc='left',pad=7)
            ax.set_xlabel(r'$\Delta$ balanced accuracy (pp)',labelpad=5)
        handles=[Line2D([0],[0],color=COLORS[j],marker=MARKERS[j],lw=1,ms=4,label=label) for j,label in enumerate(['Joint MGT minus product MGT','Joint MGT minus joint FLTrust'])]
        fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.53,.02),ncol=2,frameon=False,handlelength=1.2,columnspacing=1.5)
        for fmt in ['pdf','png']:fig.savefig(OUT/f'joint_mask_paired_differences.{fmt}',dpi=300,facecolor='white')
        plt.close(fig)
    save_csv(HERE/'joint_mask_paired_differences_source.csv',exports)

def joint_tables(rows):
    for metric in ['test_accuracy','test_balanced_accuracy','test_ce']:
        display={'test_accuracy':'accuracy in percent','test_balanced_accuracy':'balanced accuracy in percent','test_ce':'cross-entropy'}[metric]
        suffix={'test_accuracy':'accuracy','test_balanced_accuracy':'balanced_accuracy','test_ce':'ce'}[metric]
        lines=['\\begin{table*}[t]','\\centering',
            '\\caption{Empirical joint-mask-pattern extension: '+display+'. All four methods use the same complete-case core and empirical target mask-pattern law. Entries are means $\\pm$ sample SD over five paired split/training seeds. Natural masks are retained; the empirical mask-pattern law remains a working model independent of the reference covariate values.}',
            '\\label{tab:natural-joint-'+suffix.replace('_','-')+'}',
            '\\scriptsize','\\setlength{\\tabcolsep}{4pt}',
            '\\begin{tabular}{lllrrrr}','\\toprule',
            'Dataset & Allocation & Attack & Joint FLTrust & Joint MGT--Med & \\shortstack{Joint transport-\\\\FLTrust} & Joint root only\\\\','\\midrule']
        for di,d in enumerate(['mammographic_mass','hepatitis']):
            if di:lines.append('\\midrule')
            for pi,p in enumerate(['random','burden']):
                for ai,a in enumerate(['none','signflip','root_aligned']):
                    prefix=[DLABELS[d] if pi==0 and ai==0 else '',p.capitalize() if ai==0 else '',ALABELS[a]]
                    lines.append(' & '.join(prefix+[cell(rows,d,a,m,metric,p) for m in JOINT_METHODS])+'\\\\')
        lines.extend(['\\bottomrule','\\end{tabular}','\\end{table*}'])
        content='\n'.join(lines)+'\n'
        (TABLES/f'natural_joint_{suffix}.tex').write_text(content,encoding='utf-8')
        (TABLES/f'joint_{suffix}.tex').write_text(content,encoding='utf-8')

def main():
    jointp=ROOT/'natural'/'extension'/'joint_runs.csv';prod=ROOT/'natural'/'natural_runs.csv'
    status=json.loads((jointp.parent/'status.json').read_text(encoding='utf-8'))
    assert status['status']=='JOINT_OFFICIAL_COMPLETE','Joint extension has not passed its final integrity gate'
    joint=read(jointp);product=read(prod)
    assert len(joint)==240 and len(product)==360
    joint_figure(joint,product);joint_tables(joint)
    provenance={'date':'2026-10-29','raw_sources':[{'path':str(p),'relative_path':p.relative_to(ROOT).as_posix(),'sha256':sha(p)} for p in [jointp,prod]],
        'transformations':['Exact paired seed joins, no exclusions.','Joint-MGT-Med balanced accuracy minus product MGT or joint FLTrust, multiplied by 100.','All five paired seeds as open points; mean and sample SD (ddof=1) as filled point and whisker.'],
        'scope':'Joint MGT versus joint FLTrust uses a matched target law. Joint versus product MGT changes target anchor and, under root-cone stress, the realized attack; not a single-factor causal effect.',
        'dimensions_inches':[7,3.2],'dpi':300,'independent_panel_xlimits':True,
        'packages':{'numpy':np.__version__,'matplotlib':matplotlib.__version__}}
    (HERE/'joint_provenance.json').write_text(json.dumps(provenance,indent=2),encoding='utf-8')
    print('Rendered all-cell joint-pattern differences and three full-method tables.')

if __name__=='__main__':main()
