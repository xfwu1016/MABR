"""Reproducible, all-cell v3 displays. No model selection or data imputation."""
from pathlib import Path
import csv, json, hashlib, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
OUT=HERE/'figures';TABLES=HERE/'tables'
OUT.mkdir(exist_ok=True);TABLES.mkdir(exist_ok=True)
COLORS=['#0072B2','#D55E00','#009E73']
MARKERS=['o','s','D']
METHODS=['Median','FLTrust','FLTrust-CM','MGT-Med','TransportFLTrust','ReferenceOnly']
NAT_METHODS=['Mean','Median','FLTrust','MGT-Med','TransportFLTrust','ReferenceOnly']
ATTACKS=['none','signflip','alie','transport_aware','root_aligned']
ALABELS={'none':'None','signflip':'Sign flip','alie':'ALIE-style','transport_aware':'Transport-aware','root_aligned':'Root-cone'}
DLABELS={'breast_cancer':'WDBC','digits':'Digits','mammographic_mass':'Mammographic Mass','hepatitis':'Hepatitis'}

def read(p):
    with p.open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def save_csv(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def paired(rows,dataset,attack,reference,metric,partition=None):
    r=[z for z in rows if z['dataset']==dataset and z['attack']==attack and (partition is None or z['partition']==partition)]
    target={int(z['seed']):float(z[metric]) for z in r if z['method']=='MGT-Med'}
    base={int(z['seed']):float(z[metric]) for z in r if z['method']==reference}
    assert sorted(target)==sorted(base)==list(range(5)),(dataset,attack,reference,partition,target,base)
    return np.array([100*(target[s]-base[s]) for s in range(5)])

def style():
    return plt.rc_context({'font.family':'DejaVu Sans','font.size':8.5,'axes.labelsize':8.5,'axes.titlesize':9.5,
        'xtick.labelsize':8.2,'ytick.labelsize':8.2,'legend.fontsize':8.2,
        'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65,
        'xtick.major.width':.6,'ytick.major.width':.6,'pdf.fonttype':42,'ps.fonttype':42,
        'savefig.facecolor':'white','figure.facecolor':'white'})

def make_difference_figure(rows,natural=False):
    datasets=['mammographic_mass','hepatitis'] if natural else ['breast_cancer','digits']
    references=['Median','FLTrust'] if natural else ['Median','FLTrust','FLTrust-CM']
    metric='test_balanced_accuracy' if natural else 'test_accuracy'
    name='natural_paired_differences' if natural else 'fltrust_paired_differences'
    conditions=[(p,a) for p in ['random','burden'] for a in ['none','signflip','root_aligned']] if natural else [(None,a) for a in ATTACKS]
    labels=[('Random: ' if p=='random' else 'Burden: ')+ALABELS[a].lower() if natural else ('Transport' if a=='transport_aware' else ALABELS[a]) for p,a in conditions]
    exports=[]
    with style():
        fig,axes=plt.subplots(1,2,figsize=(7.0,3.2))
        fig.subplots_adjust(left=.18 if natural else .13,right=.98,bottom=.265,top=.89,wspace=.47 if natural else .32)
        for panel,(ax,dataset) in enumerate(zip(axes,datasets)):
            allvals=[]
            for k,(p,a) in enumerate(conditions):
                for j,reference in enumerate(references):
                    diff=paired(rows,dataset,a,reference,metric,p)
                    offset=(j-(len(references)-1)/2)*(.24 if natural else .22)
                    y=k+offset
                    jitter=np.linspace(-.055,.055,5)
                    ax.scatter(diff,y+jitter,s=11,marker=MARKERS[j],facecolors='none',edgecolors=COLORS[j],linewidths=.65,alpha=.55,zorder=2)
                    mean=float(diff.mean());sd=float(diff.std(ddof=1))
                    ax.errorbar(mean,y,xerr=sd,fmt=MARKERS[j],ms=4.0,color=COLORS[j],mec='white',mew=.45,elinewidth=1.05,capsize=2.0,zorder=3)
                    allvals.extend(diff.tolist()+[mean-sd,mean+sd])
                    for seed,value in enumerate(diff):exports.append(dict(dataset=dataset,partition=p or '',attack=a,comparison='MGT-Med minus '+reference,seed=seed,metric=metric,difference_percentage_points=float(value)))
            ax.axvline(0,color='#555555',lw=.8,ls=(0,(3,2)),zorder=0)
            # Axes intentionally use their own data ranges, plainly labelled in caption.
            lo=min(min(allvals),0);hi=max(max(allvals),0);span=max(hi-lo,2)
            ax.set_xlim(lo-.12*span,hi+.12*span)
            ax.set_yticks(range(len(conditions)),labels)
            ax.set_ylim(len(conditions)-.43,-.6)
            ax.grid(axis='x',color='#e5e5e5',lw=.55)
            ax.set_axisbelow(True)
            ax.set_title(f'({chr(97+panel)}) {DLABELS[dataset]}',loc='left',pad=7)
            ax.set_xlabel(r'$\Delta$ balanced accuracy (pp)' if natural else r'$\Delta$ accuracy (percentage points)',labelpad=5)
        legend=[Line2D([0],[0],marker=MARKERS[i],color=COLORS[i],lw=1,markersize=4,label='MGT–Med minus '+r) for i,r in enumerate(references)]
        fig.legend(handles=legend,loc='lower center',bbox_to_anchor=(.53,.02),ncol=len(references),frameon=False,handlelength=1.2,columnspacing=1.7)
        for fmt in ('pdf','png'):fig.savefig(OUT/f'{name}.{fmt}',dpi=300,facecolor='white')
        plt.close(fig)
    save_csv(HERE/f'{name}_source.csv',exports)
    return name

def cell(rows,dataset,attack,method,metric,partition=None):
    vals=np.array([float(z[metric]) for z in rows if z['dataset']==dataset and z['attack']==attack and z['method']==method and (partition is None or z['partition']==partition)])
    assert len(vals)==5 and np.isfinite(vals).all(),(dataset,attack,method,metric,partition,len(vals))
    scale=1 if metric=='test_ce' else 100
    vals*=scale
    return f'{vals.mean():.3f} $\\pm$ {vals.std(ddof=1):.3f}' if metric=='test_ce' else f'{vals.mean():.2f} $\\pm$ {vals.std(ddof=1):.2f}'

def make_table(rows,natural=False,metric='test_accuracy'):
    datasets=['mammographic_mass','hepatitis'] if natural else ['breast_cancer','digits']
    methods=NAT_METHODS if natural else METHODS
    attacks=['none','signflip','root_aligned'] if natural else ATTACKS
    metricname={'test_accuracy':'accuracy','test_balanced_accuracy':'balanced accuracy','test_ce':'cross-entropy'}[metric]
    unit='' if metric=='test_ce' else ' in percent'
    name=('natural_' if natural else 'fltrust_extended_')+{'test_accuracy':'accuracy','test_balanced_accuracy':'balanced_accuracy','test_ce':'ce'}[metric]
    caption=('Native-missingness stress test: ' if natural else 'Five-seed reference-assisted comparison: ')+metricname+unit+'. Entries are means $\\pm$ sample SD over five paired split/training seeds. All tested methods and conditions are retained.'
    if natural:caption+=' Random and burden denote simulated client allocations; no private or test entries are artificially deleted. Complete-case reference cores can have selection bias.'
    else:caption+=' FLTrust-CM uses the same 64 distinct core examples and four target-gradient batches per round; Transport-FLTrust applies FLTrust to transported reports.'
    lines=['\\begin{table*}[t]','\\centering','\\caption{'+caption+'}','\\label{tab:'+name.replace('_','-')+'}','\\scriptsize','\\setlength{\\tabcolsep}{3pt}',
        '\\begin{tabular}{'+('lll' if natural else 'll')+'rrrrrr}','\\toprule',
        ('Dataset & Allocation & Attack & ' if natural else 'Dataset & Attack & ')+ ' & '.join({'TransportFLTrust':'\\shortstack{Transport-\\\\FLTrust}','ReferenceOnly':'Root only'}.get(m,m) for m in methods)+'\\\\','\\midrule']
    for di,d in enumerate(datasets):
        if di:lines.append('\\midrule')
        for pi,p in enumerate(['random','burden'] if natural else [None]):
            for ai,a in enumerate(attacks):
                prefix=[DLABELS[d] if ai==0 and pi==0 else '']
                if natural:prefix.append(p.capitalize() if ai==0 else '')
                prefix.append(ALABELS[a])
                lines.append(' & '.join(prefix+[cell(rows,d,a,m,metric,p) for m in methods])+'\\\\')
    lines.extend(['\\bottomrule','\\end{tabular}','\\end{table*}'])
    (TABLES/f'{name}.tex').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return name

def main():
    flp=ROOT/'fltrust'/'comparison_runs.csv';natp=ROOT/'natural'/'natural_runs.csv'
    jobs=[(flp,False,300),(natp,True,360)]
    if '--fltrust' in sys.argv:jobs=jobs[:1]
    if '--natural' in sys.argv:jobs=jobs[1:]
    names=[];tables=[];sources=[]
    for path,natural,count in jobs:
        if natural:
            status=json.loads((path.parent/'status.json').read_text(encoding='utf-8'))
            assert status['status']=='PRODUCT_OFFICIAL_COMPLETE' and status['primary_results_final']
            assert status['files_sha256']['natural_runs.csv']==sha(path)
        rows=read(path);assert len(rows)==count
        names.append(make_difference_figure(rows,natural))
        for metric in ['test_accuracy','test_balanced_accuracy','test_ce']:tables.append(make_table(rows,natural,metric))
        sources.append({'path':str(path),'relative_path':path.relative_to(ROOT).as_posix(),'sha256':sha(path),'rows':count})
    provenance={
        'created':'2026-10-29','destination':'Neural Networks research draft, full-width 7.0 inch figures',
        'raw_sources':sources,
        'transformations':['Join MGT-Med and each comparator exactly by dataset/partition/attack/seed.','Multiply seed-level accuracy or balanced-accuracy difference by 100.','Small open markers show all five paired seed differences; filled markers and horizontal whiskers show their arithmetic mean and sample SD (ddof=1).','No filtering, smoothing, model selection, or significance annotation.'],
        'axes':'Each dataset panel has independently labelled horizontal limits; differences are in percentage points, with zero reference shown. This must be stated in captions.',
        'replication':'Five paired split/training seeds, conditional on shared historical datasets; overlapping observations and conditions are not independent patients or trials.',
        'dimensions_inches':[7.0,3.2],'png_pixels':[2100,960],'dpi':300,'pdf_fonttype':42,
        'palette':dict(zip(['Median','FLTrust','FLTrust-CM'],COLORS)),'redundant_encoding':'circle, square, diamond markers and labelled legend',
        'packages':{'numpy':np.__version__,'matplotlib':matplotlib.__version__},
        'figures':names,'tables':tables,
        'alt_text':{
            'fltrust_paired_differences':'Two panels show paired MGT-Med accuracy differences against raw Median, FLTrust and budget-matched FLTrust over five attacks. Differences are small on WDBC. On Digits MGT-Med is substantially above both FLTrust variants under root-cone stress, while it can be below ordinary FLTrust under sign flip and transport-aware attacks; its advantage over Median is much smaller.',
            'natural_paired_differences':'Two panels show balanced-accuracy differences on Mammographic Mass and Hepatitis with original missing masks under random or missingness-burden simulated client allocations and three attacks. Every measured paired seed is displayed, including negative differences. Actual pattern must be interpreted from all cells, not as validation of a Bernoulli missingness law.'}
    }
    (HERE/'provenance.json').write_text(json.dumps(provenance,indent=2),encoding='utf-8')
    print(json.dumps({'figures':names,'tables':tables,'sources':sources},indent=2))

if __name__=='__main__':main()
