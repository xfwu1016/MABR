# Reproduce the current v3 evidence

Use Python 3.12 with numpy, scipy, scikit-learn, pandas, matplotlib, pypdf and Pillow. Exact versions are recorded per block; no automatic package installation is performed. Existing endpoint files are resumed. A full independent rerun should use a separate copy without the relevant generated endpoint files, leaving this release intact.

Controlled primary study: `python fltrust/run_comparison.py --workers 2`.
Width/rate study: `python fltrust/run_sensitivity.py` (160/320 checkpoints from 180 fits).
Native product study: `python natural/run_natural.py`, then `python natural/audit_natural.py`.
Native joint study: `python natural/extension/run_joint.py`, then its documented audit.
Conditional variance diagnostic: `python natural/extension/variance_diagnostic.py`.
Display regeneration: run `visuals/make_figures.py`, `visuals/make_extensions.py`, and `visuals/make_sensitivity.py`.

The official raw UCI archives are included, so network access is unnecessary for training. The download script is only needed if archives are absent. Dataset attribution/CC BY 4.0 and original documentation are in natural/raw and sources.json. Observation-law metadata is trusted pre-attack in these simulations; no privacy or clinical utility claim follows.

The reference-only and target/coupling random-stream checks, source hashes, allowed grids, parameter replays, source/claim audit and complete adverse results are included. Historical versions are described in ARCHIVE_SCOPE.txt. The original README.md describes only the initial study.
