from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
df=pd.read_csv(ROOT/'natural_runs.csv')
assert len(df)==360
summary=pd.read_csv(ROOT/'natural_summary.csv')
paired=pd.read_csv(ROOT/'paired_differences_vs_fltrust.csv')
audit=json.loads((ROOT/'data_audit.json').read_text())
integrity=json.loads((ROOT/'integrity.json').read_text())
integrity['unique_final_parameter_hashes']=int(df.parameter_sha256.nunique())
integrity['reference_only_distinct_parameter_hashes']=int(df[df.method=='ReferenceOnly'].parameter_sha256.nunique())
integrity['reference_only_partition_and_attack_invariance']=all(g.parameter_sha256.nunique()==1 for _,g in df[df.method=='ReferenceOnly'].groupby(['dataset','seed']))
assert integrity['reference_only_partition_and_attack_invariance']
(ROOT/'integrity.json').write_text(json.dumps(integrity,indent=2))

def condition_table(metric):
    rows=['| Dataset | Partition | Attack | Mean | Median | FLTrust | MGT-Med | TransportFLTrust | ReferenceOnly |',
          '|---|---|---|---:|---:|---:|---:|---:|---:|']
    scale=1 if metric=='test_ce' else 100
    precision=3 if metric=='test_ce' else 2
    for (dataset,part,attack),g in summary.groupby(['dataset','partition','attack'],sort=False):
        values=[]
        for method in ['Mean','Median','FLTrust','MGT-Med','TransportFLTrust','ReferenceOnly']:
            r=g[g.method==method].iloc[0]
            values.append(f'{scale*r[metric+"_mean"]:.{precision}f} ± {scale*r[metric+"_std"]:.{precision}f}')
        rows.append('| '+' | '.join([dataset,part,attack]+values)+' |')
    return '\n'.join(rows)

comp=df.pivot(index=['dataset','partition','seed','attack'],columns='method',values='test_accuracy')
avg=comp.groupby(level=['dataset','partition','attack']).mean()
count_vs_fltrust=int((avg['MGT-Med']>avg['FLTrust']).sum())
count_vs_median=int((avg['MGT-Med']>avg['Median']).sum())
root=avg.loc[avg.index.get_level_values('attack')=='root_aligned']
lines=['# Natural missingness external-data stress study (v3)',
       '',
       'Completed 2026-10-29. Evidence status: VERIFIED for downloads, measured results, code checks and tabular metadata. AUTHOR_INPUT_NEEDED for any clinical interpretation or author approval of the final manuscript. The experiment is exploratory and was not externally preregistered.',
       '',
       '## Source and natural-missingness provenance',
       '',
       '- [UCI Mammographic Mass](https://archive.ics.uci.edu/dataset/161/mammographic+mass), DOI [10.24432/C53K6Z](https://doi.org/10.24432/C53K6Z), dataset by Matthias Elter (2007), CC BY 4.0. BI-RADS assessment is excluded because the distributed documentation calls it non-predictive. Retained original predictors: Age, Shape, Margin, Density. Shape and Margin are one-hot encoded with the documented levels, yielding 11 neural input features before mask concatenation.',
       '- [UCI Hepatitis](https://archive.ics.uci.edu/dataset/46/hepatitis), DOI [10.24432/C5Q59J](https://doi.org/10.24432/C5Q59J), CC BY 4.0. The repository citation year is 1983 although donation is dated 1988; no individual creator was invented. All 19 documented covariates are retained, including continuous Bilirubin. Class is outcome only. Measurement timing is unavailable, so these are computational classification benchmarks rather than prospective clinical prediction.',
       '- Official ZIPs and distributed names files are retained in raw/. sources.json records URLs, access date, licenses and byte hashes. The literal question marks are the only missing-value code. No artificial deletion is applied to private or test data.',
       '',
       '| Dataset | Rows | Original variables | Natural missing entries | Missing cells | Complete rows | Distinct natural mask patterns |',
       '|---|---:|---:|---:|---:|---:|---:|']
for r in audit['datasets']:
    lines.append(f'| {r["dataset"]} | {r["n_rows"]} | {r["original_features"]} | {r["missing_entries"]} | {100*r["missing_fraction"]:.3f}% | {r["complete_rows"]} | {r["distinct_mask_patterns"]} |')
lines += ['',
          '## Frozen protocol and assumptions',
          '',
          'All 961 and 155 raw rows are retained. The absence of patient IDs prevents verification of patient independence. Exact raw predictor representations are grouped when splitting train/test, so no identical observed representation crosses the boundary. GroupShuffleSplit uses 30% of groups for testing; outcome labels are not used for grouping. Mammographic test sets contain 283–329 rows and 32–42 incomplete rows; Hepatitis test sets contain 47 rows and 21–28 incomplete rows. Group sampling can change test class proportions.',
          '',
          'A stratified sample from complete training records supplies 64 trusted Mammographic or 16 trusted Hepatitis examples. All are excluded from private training. Only this complete core fits StandardScaler. Missing transformed values are zero-filled and the original observation mask is supplied to the network. Shape/Margin one-hot coordinates share a single original-variable observation event; the same grouping is used for reference masks.',
          '',
          'Eleven simulated clients are formed either randomly, or by placing a random 20% prefix before sorting the remaining records by original missing-variable count, splitting into 11 blocks and randomly permuting client IDs. The burden partition changes allocation but does not change an observed value or mask. It is a sensitivity condition, not evidence of a real multisite cohort.',
          '',
          'For each original variable q_i=(local observed count+1)/(local size+2). The target profile is the corresponding pooled-private training frequency, without test entries or outcomes. The study curator supplies this target as trusted pre-attack metadata; no robustness to malicious target-profile aggregation or differential privacy is established. The independent product mask law used for reference transport is only a working approximation. Natural missingness can correlate with covariates, outcomes and other missing entries. The complete-case trusted reference can be selected relative to the target population. Thus these data do not validate the common-complete-data-law or MCAR assumptions in the population theorem.',
          '',
          'Five paired split/training seeds (0–4), 24 tanh hidden units, softmax cross entropy, learning rate 0.15, 160 rounds, private batch 32 and reference batch 64 with replacement are fixed without test-based tuning. Six methods × two datasets × two partitions × three attacks × five seeds give 360 named fits. ReferenceOnly repeats are controls, not independent extra evidence. The 10 dataset/seed ReferenceOnly parameter states repeat exactly across attacks and partitions.',
          '',
          'The root_aligned CSV label denotes the shared finite root-cone stress search, not an optimized reproduction of the original FLTrust adaptive attack. It uses the current anchor, honest raw and corrected reports and a fixed positive-cosine candidate set; it uses no test data. All methods receive the same attack policy, data, initialization and random-number plan. Signflip uses -5 times the mean honest raw report. Under none all 11 clients are honest; under the two attacks IDs 9 and 10 are Byzantine.',
          '',
          'Distinct vector profiles require 7–12 reference gradient evaluations per round for MGT-Med and TransportFLTrust, versus one for FLTrust and ReferenceOnly; b0 stays 64. Raw baselines require no algorithmic server gradient. The recorded wall times include common diagnostics, so they are not fair algorithm-speed comparisons.',
          '',
          '## What the results establish',
          '',
          f'MGT-Med exceeds FLTrust in mean accuracy in {count_vs_fltrust}/12 conditions and exceeds raw Median in {count_vs_median}/12. These are dependent descriptive condition counts, not independent replications. Every favorable and unfavorable condition is retained.',
          '',
          'For root-cone stress, MGT-Med minus FLTrust mean accuracy is +3.005 pp (Mammographic random), +3.660 pp (Mammographic burden), +5.106 pp (Hepatitis random), and +5.957 pp (Hepatitis burden). The corresponding balanced-accuracy differences are +3.240, +3.739, +6.518 and +9.773 pp. Raw Median is already comparable or better in three of those four conditions. Therefore the root-cone gap versus FLTrust cannot be attributed to transport correction alone.',
          '',
          'Without attacks, MGT-Med has lower mean accuracy than FLTrust in all four dataset/partition conditions, and lower mean balanced accuracy in three of four (Hepatitis/random is slightly higher). Under signflip the result is generally tied or worse. On Hepatitis the outcome imbalance makes accuracy and balanced accuracy materially different. TransportFLTrust does not consistently improve FLTrust under natural missingness. These findings delimit the method: the study supports a conditional alignment mechanism and an honest comparison boundary, not universal performance or a validation of the natural missingness model.',
          '',
          'Sample SD describes five paired split/training seeds. paired_differences_vs_fltrust.csv also saves all per-seed differences and descriptive t intervals; records overlap across splits, and these intervals are not patient-level clinical confidence intervals. No selective significance claim is made.',
          '',
          '## Accuracy (%) — mean ± sample SD over five paired seeds',
          '',condition_table('test_accuracy'),'',
          '## Balanced accuracy (%) — mean ± sample SD over five paired seeds',
          '',condition_table('test_balanced_accuracy'),'',
          '## Cross entropy — mean ± sample SD over five paired seeds',
          '',condition_table('test_ce'),'',
          '## Verification and files',
          '',
          '- integrity.json: exactly 360 named fits, no duplicated run keys, all endpoint metrics and parameters finite; all 20 dataset/partition/seed ReferenceOnly controls are attack-invariant and all 10 dataset/seed controls also partition-invariant.',
          '- data_audit.json: raw missing-value counts, masks unchanged, complete-core and row/group separation, target-profile recomputation, training-only product-mask approximation diagnostic. Three independently replayed runs reproduce exact final parameter hashes.',
          '- gradient_check.json: original analytic MLP derivatives pass finite differences. environment.json and sources.json preserve code/environment/raw data provenance.',
          '- author_methods.py follows the FLTrust authors\' numerical stabilization (eps=1e-9) and returns a zero aggregate when total trust is zero. The CSV column fltrust_fallbacks is retained as a historical field name but now counts zero-score rounds; it does NOT mean root-gradient substitution. The original eps1e-15/root-fallback batch is fully preserved in legacy_rules/ and excluded from primary results. All 360 fits and root-cone candidate searches were rerun under the author numerical rule, for source fidelity rather than test performance. Primary implementation source: https://people.duke.edu/~zg70/code/fltrust.zip, nd_aggregation.py, audited 2026-10-29.',
          '- natural_runs.csv: all 360 endpoints; natural_curves.csv: all evaluation curves at fixed checkpoints; models/: final parameter arrays; splits/: every row allocation, profile and scaler.',
          '- protocol.json: frozen settings, inference limits and attack formula; run_natural.py: resumable complete runner; base_experiments.py and shared_methods.py: frozen model and attack/aggregation definitions.',
          '',
          'Run `python download_data.py` only if raw archives are absent, then `python run_natural.py`, `python audit_natural.py`, `python make_report.py`. Existing named keys are resumed; use a new folder without existing endpoint CSVs for a full rerun. No dependencies are downloaded by the runner itself.']
(ROOT/'report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
(ROOT/'README.md').write_text('''# Natural-missingness validation, v3

Read report.md and protocol.json before interpreting any accuracy difference.
All 360 named fits are complete. This is a natural-missingness benchmark with
simulated clients and attacks, not a real multisite clinical validation.

Reproduce with Python 3.11+, NumPy, SciPy, scikit-learn and pandas:

    python download_data.py
    python run_natural.py
    python audit_natural.py
    python make_report.py

The runner resumes endpoint keys already present in natural_runs.csv. A full
independent rerun requires a fresh copy without natural_runs.csv and
natural_curves.csv. The --pilot option is only a ten-round execution check,
is saved separately and is excluded from all manuscript results.

Raw public UCI datasets, original names files and attribution are retained.
Both datasets are licensed CC BY 4.0; see sources.json and natural_sources.bib.
Standardization, profiles and all modeling choices exclude the test set.
The trusted complete-case core can be selected relative to the natural
target population; independent product masks are only a working model.
The active 360-fit results use author_methods.py: eps1e-9, zero update if
all trust scores are zero. The historical fltrust_fallbacks CSV field now
counts zero-score rounds, not root substitution. Earlier numerical-rule
results are preserved in legacy_rules/ and excluded from primary results.
''',encoding='utf-8')
print(json.dumps(dict(n_fits=len(df),unique_final_hashes=integrity['unique_final_parameter_hashes'],MGT_accuracy_conditions_above_FLTrust=count_vs_fltrust,MGT_accuracy_conditions_above_Median=count_vs_median),indent=2))
