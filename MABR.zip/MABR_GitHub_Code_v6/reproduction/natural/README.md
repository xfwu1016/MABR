# Natural-missingness validation, v3

Read report.md and protocol.json before interpreting any accuracy difference.
All 360 named fits are complete. This is a natural-missingness benchmark with
simulated clients and attacks, not a real multisite clinical validation.

Reproduce with Python 3.11+, NumPy, SciPy, scikit-learn and pandas:

    python download_data.py
    python run_natural.py
    python audit_natural.py
    python make_report.py

The runner resumes endpoint keys already present in natural_runs.csv. A full
independent rerun requires a fresh copy without natural_runs.csv and
natural_curves.csv. The --pilot option is only a ten-round execution check,
is saved separately and is excluded from all manuscript results.

Raw public UCI datasets, original names files and attribution are retained.
Both datasets are licensed CC BY 4.0; see sources.json and natural_sources.bib.
Standardization, profiles and all modeling choices exclude the test set.
The trusted complete-case core can be selected relative to the natural
target population; independent product masks are only a working model.
The active 360-fit results use author_methods.py: eps1e-9, zero update if
all trust scores are zero. The historical fltrust_fallbacks CSV field now
counts zero-score rounds, not root substitution. Earlier numerical-rule
results are preserved in legacy_rules/ and excluded from primary results.
