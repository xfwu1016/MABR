"""Reproducible CPU experiments for mask-conditioned gradient transport.

No external data downloads are used. All neural derivatives are implemented in
NumPy and checked against finite differences before any training run.
"""
import os
for name in ('OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'OMP_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[name] = '1'
import argparse, csv, hashlib, json, platform, sys, time
from pathlib import Path
import numpy as np
import scipy
import sklearn
from sklearn.datasets import load_breast_cancer, load_digits, make_classification
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parent
METHODS = ['Mean', 'Median', 'TrimmedMean', 'FLTrust', 'ReferenceOnly', 'TransportMean', 'MGT-Med']
ATTACKS = ['none', 'signflip', 'alie', 'transport_aware']
DATASETS = ['breast_cancer', 'digits', 'synthetic']
CONFIG = dict(n_clients=11, n_byzantine=2, profiles=[.25]*4+[.6]*3+[.9]*4,
              target_observation=.65, hidden=24, rounds=160, learning_rate=.15,
              private_batch=32, reference_batch=64, reference_size=64,
              evaluation_masks=3, test_fraction=.3, seeds=[0,1,2],
              attacks=ATTACKS, methods=METHODS, datasets=DATASETS,
              attack_scale=5., alie_z=1.5, initialization='Glorot normal, factor 0.7',
              preprocessing='StandardScaler fit on complete trusted reference core only',
              regularization='none', local_steps=1, update='SGD, no momentum or clipping',
              dtype='float64', partition='random-IID samples; profile-specific MCAR masks',
              byzantine_ids=[9,10], checkpoint_interval=10,
              final_selection='final round; no best-test checkpoint selection',
              reference_reused=True,
              private_masks='Independent mask redrawn on each private minibatch access (streaming/repeated acquisition simulation)',
              output_scope='initial experimental evidence; no state-of-the-art or clinical utility claim')

class MLP:
    def __init__(self, d, c, hidden=24):
        self.d, self.c, self.h = d,c,hidden
        self.s1=2*d*hidden; self.s2=self.s1+hidden
        self.s3=self.s2+hidden*c; self.dim=self.s3+c
    def initialize(self, rng):
        return np.r_[rng.normal(0,.7*np.sqrt(2/(2*self.d+self.h)),self.s1),
                     np.zeros(self.h),
                     rng.normal(0,.7*np.sqrt(2/(self.h+self.c)),self.h*self.c),np.zeros(self.c)]
    def unpack(self,t):
        return (t[:self.s1].reshape(2*self.d,self.h),t[self.s1:self.s2],
                t[self.s2:self.s3].reshape(self.h,self.c),t[self.s3:])
    def loss_grad(self,t,x,y,m,grad=True):
        W,b,V,a=self.unpack(t)
        z=np.concatenate((x*m,m.astype(np.float64)),axis=1)
        h=np.tanh(z@W+b)
        logits=h@V+a
        mx=logits.max(axis=1,keepdims=True)
        ee=np.exp(logits-mx); prob=ee/ee.sum(axis=1,keepdims=True)
        loss=float(np.mean(np.log(ee.sum(axis=1))+mx[:,0]-logits[np.arange(len(y)),y]))
        if not grad:
            return loss, float(np.mean(prob.argmax(axis=1)==y))
        dd=prob.copy();dd[np.arange(len(y)),y]-=1;dd/=len(y)
        dh=(dd@V.T)*(1-h*h)
        return loss,np.r_[(z.T@dh).ravel(),dh.sum(axis=0),(h.T@dd).ravel(),dd.sum(axis=0)]

def gradient_check():
    r=np.random.default_rng(237)
    net=MLP(4,3,5); t=net.initialize(r)
    x=r.normal(size=(7,4));y=r.integers(0,3,size=7);m=r.random((7,4))<.6
    _,g=net.loss_grad(t,x,y,m)
    ids=r.choice(len(t),min(70,len(t)),replace=False); eps=1e-5; err=[]
    for j in ids:
        a=t.copy();b=t.copy();a[j]+=eps;b[j]-=eps
        fd=(net.loss_grad(a,x,y,m,False)[0]-net.loss_grad(b,x,y,m,False)[0])/(2*eps)
        err.append(abs(fd-g[j]))
    report=dict(checked_coordinates=len(ids),epsilon=eps,max_absolute_error=max(err),
                passed=bool(max(err)<1e-7),all_gradient_finite=bool(np.isfinite(g).all()))
    if not report['passed']:raise RuntimeError(report)
    return report

def prepare(dataset,seed,skew=False,reference_size=None,core_pool=None,scaler_subset=None):
    if dataset=='breast_cancer':
        ds=load_breast_cancer();x,y=ds.data,ds.target
    elif dataset=='digits':
        ds=load_digits();x,y=ds.data,ds.target
    else:
        x,y=make_classification(n_samples=2400,n_features=20,n_informative=12,
                               n_redundant=4,n_classes=3,n_clusters_per_class=1,
                               class_sep=1.,flip_y=.03,random_state=1729)
    xpool,xt,ypool,yt=train_test_split(x,y,test_size=.3,stratify=y,random_state=100+seed)
    reference_size=reference_size or CONFIG['reference_size']
    xp,xr,yp,yr=train_test_split(xpool,ypool,test_size=core_pool or reference_size,
                               stratify=ypool,random_state=200+seed)
    if core_pool:
        order=np.random.default_rng(220+seed).permutation(len(xr))
        xr,yr=xr[order[:reference_size]],yr[order[:reference_size]]
    scaler=StandardScaler().fit(xr[:scaler_subset] if scaler_subset else xr)
    xp=scaler.transform(xp);xr=scaler.transform(xr);xt=scaler.transform(xt)
    # The complete trusted core is already an explicitly granted resource;
    # no unobserved complete private value or test observation fits the scaler.
    rng=np.random.default_rng(300+seed)
    perm=rng.permutation(len(xp))
    if skew:
        # Sort most samples by label while retaining a random 20% prefix.
        k=int(.2*len(perm));tail=perm[k:];tail=tail[np.argsort(yp[tail],kind='stable')]
        perm=np.r_[perm[:k],tail]
    clients=[(xp[q],yp[q]) for q in np.array_split(perm,CONFIG['n_clients'])]
    erng=np.random.default_rng(400+seed)
    masks=[erng.random(xt.shape)<CONFIG['target_observation'] for _ in range(CONFIG['evaluation_masks'])]
    return clients,(xr,yr),(xt,yt,masks),dict(n_total=len(x),n_private=len(xp),
        n_reference=len(xr),n_test=len(xt),features=x.shape[1],classes=int(y.max()+1),
        private_client_sizes=[len(a[1]) for a in clients],skew=skew)

def evaluate(net,t,test):
    x,y,masks=test
    out=np.array([net.loss_grad(t,x,y,m,False) for m in masks])
    return dict(test_ce=float(out[:,0].mean()),test_accuracy=float(out[:,1].mean()))

def aggregate(G,method,anchor,f):
    if G.ndim!=2 or G.shape[1]!=len(anchor):
        raise ValueError('Malformed gradient dimensions')
    G=G[np.isfinite(G).all(axis=1)]
    if len(G)<=2*f:
        raise ValueError('Insufficient accepted reports for the configured Byzantine bound')
    if not np.isfinite(anchor).all():
        raise ValueError('Invalid trusted-reference gradient')
    if method in ('Mean','TransportMean'):return G.mean(axis=0),{}
    if method in ('Median','MGT-Med'):return np.median(G,axis=0),{}
    if method=='TrimmedMean':return np.sort(G,axis=0)[f:len(G)-f].mean(axis=0),{}
    if method=='ReferenceOnly':return anchor,{}
    norms=np.linalg.norm(G,axis=1);an=np.linalg.norm(anchor)
    scores=np.maximum(0,(G@anchor)/(np.maximum(norms,1e-15)*max(an,1e-15)))
    if scores.sum()<1e-15:return anchor,{'fltrust_fallback':1,'fltrust_low_weight_share':float('nan')}
    normed=G*(an/np.maximum(norms,1e-15))[:,None]
    return (scores[:,None]*normed).sum(axis=0)/scores.sum(),dict(fltrust_fallback=0,
         fltrust_low_weight_share=float(scores[:4].sum()/scores.sum()))

def run(dataset,seed,attack,method,skew=False,rounds=None,reference_size=None,core_pool=None,profiles_override=None,scaler_subset=None,static_masks=False):
    clients,ref,test,meta=prepare(dataset,seed,skew,reference_size,core_pool,scaler_subset)
    net=MLP(meta['features'],meta['classes'],CONFIG['hidden'])
    t=net.initialize(np.random.default_rng(500+seed))
    rng=np.random.default_rng(600+seed)
    profiles=np.asarray(CONFIG['profiles'] if profiles_override is None else profiles_override,dtype=float)
    if profiles.shape!=(CONFIG['n_clients'],) or not np.isfinite(profiles).all() or np.any(profiles<=0) or np.any(profiles>1):
        raise ValueError('Enrolled observation profiles must be finite, have one entry per client, and lie in (0,1].')
    unique=np.unique(np.r_[profiles,CONFIG['target_observation']])
    static_rng=np.random.default_rng(7000+seed)
    fixed_masks=[static_rng.random(x.shape)<profiles[i] for i,(x,y) in enumerate(clients)] if static_masks else None
    curves=[];R=rounds or CONFIG['rounds'];f=CONFIG['n_byzantine'];n=CONFIG['n_clients']
    honest=n if attack=='none' else n-f
    raw_disp=[];corr_disp=[];raw_anchor=[];corr_anchor=[];wshares=[];fallbacks=0
    start=time.perf_counter()
    for step in range(R):
        rid=rng.integers(0,len(ref[1]),CONFIG['reference_batch'])
        rx,ry=ref[0][rid],ref[1][rid]
        U=rng.random(rx.shape)
        # Evaluate all profile anchors for diagnostics even for plain baselines;
        # counted separately from their required algorithmic server cost.
        anchors={float(p):net.loss_grad(t,rx,ry,U<p)[1] for p in unique}
        a=anchors[CONFIG['target_observation']]
        D=np.stack([anchors[float(p)]-a for p in profiles])
        raw=[]
        for i,(x,y) in enumerate(clients):
            ids=rng.integers(0,len(y),CONFIG['private_batch'])
            mask=fixed_masks[i][ids] if static_masks else rng.random((len(ids),meta['features']))<profiles[i]
            raw.append(net.loss_grad(t,x[ids],y[ids],mask)[1])
        G=np.stack(raw)
        if attack!='none':
            hg=G[:honest]
            if attack=='signflip':G[honest:]=-CONFIG['attack_scale']*hg.mean(axis=0)
            elif attack=='alie':G[honest:]=hg.mean(axis=0)+CONFIG['alie_z']*hg.std(axis=0,ddof=0)
            else:G[honest:]=D[honest:]-CONFIG['attack_scale']*(hg-D[:honest]).mean(axis=0)
        corrected=G-D
        raw_disp.append(float(np.mean(np.sum((G[:honest]-G[:honest].mean(axis=0))**2,axis=1))))
        corr_disp.append(float(np.mean(np.sum((corrected[:honest]-corrected[:honest].mean(axis=0))**2,axis=1))))
        raw_anchor.append(float(np.linalg.norm(np.median(G[:honest],axis=0)-a)))
        corr_anchor.append(float(np.linalg.norm(np.median(corrected[:honest],axis=0)-a)))
        use=corrected if method in ('MGT-Med','TransportMean') else G
        update,extra=aggregate(use,method,a,f)
        fallbacks+=extra.get('fltrust_fallback',0)
        if 'fltrust_low_weight_share' in extra:wshares.append(extra['fltrust_low_weight_share'])
        t-=CONFIG['learning_rate']*update
        if not np.isfinite(t).all():raise FloatingPointError((dataset,seed,attack,method,step))
        if step%CONFIG['checkpoint_interval']==0 or step==R-1:
            ev=evaluate(net,t,test)
            curves.append(dict(dataset=dataset,seed=seed,attack=attack,method=method,skew=skew,
                               round=step+1,**ev,parameter_norm=float(np.linalg.norm(t))))
    ev=evaluate(net,t,test)
    server=(len(unique) if method in ('MGT-Med','TransportMean') else 1 if method in ('FLTrust','ReferenceOnly') else 0)
    row=dict(dataset=dataset,seed=seed,attack=attack,method=method,skew=skew,rounds=R,**ev,
             parameter_dim=net.dim,parameter_norm=float(np.linalg.norm(t)),
             raw_dispersion=float(np.mean(raw_disp)),corrected_dispersion=float(np.mean(corr_disp)),
             raw_median_anchor_error=float(np.mean(raw_anchor)),corrected_median_anchor_error=float(np.mean(corr_anchor)),
             fltrust_low_weight_share=float(np.nanmean(wshares)) if wshares else float('nan'),
             fltrust_fallbacks=fallbacks,wall_seconds=time.perf_counter()-start,
             required_server_gradient_evals=server*R,diagnostic_server_gradient_evals=len(unique)*R,
             required_private_gradient_evals=n*R if method!='ReferenceOnly' else 0,
             uplink_float64_values=n*net.dim*R if method!='ReferenceOnly' else 0,
             downlink_float64_values=n*net.dim*R if method!='ReferenceOnly' else 0,
             parameter_sha256=hashlib.sha256(t.tobytes()).hexdigest(),static_masks=static_masks)
    return row,curves,meta

def append_csv(path,rows):
    if not rows:return
    exists=path.exists()
    with path.open('a',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]))
        if not exists:w.writeheader()
        w.writerows(rows)

def main():
    p=argparse.ArgumentParser();p.add_argument('--pilot',action='store_true');p.add_argument('--stress',action='store_true')
    p.add_argument('--summarize',action='store_true');args=p.parse_args()
    if args.summarize:
        from summarize import summarize
        summarize();return
    ROOT.mkdir(parents=True,exist_ok=True)
    check=gradient_check();(ROOT/'gradient_check.json').write_text(json.dumps(check,indent=2))
    env=dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__,
             platform=platform.platform(),processor=platform.processor(),threads=1,
             executable=sys.executable,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (ROOT/'environment.json').write_text(json.dumps(env,indent=2))
    (ROOT/'config.json').write_text(json.dumps(CONFIG,indent=2))
    name='pilot' if args.pilot else 'stress' if args.stress else 'main'
    result=ROOT/f'{name}_runs.csv';curve=ROOT/f'{name}_curves.csv'
    done=set()
    if result.exists():
        with result.open() as f:
            done={(r['dataset'],int(r['seed']),r['attack'],r['method']) for r in csv.DictReader(f)}
    jobs=[]
    ds=['digits'] if args.pilot else ['digits','breast_cancer'] if args.stress else DATASETS
    seeds=[0] if args.pilot else [0,1,2]
    ats=['none','signflip'] if args.pilot else ['none','transport_aware'] if args.stress else ATTACKS
    methods=METHODS
    for d in ds:
        for s in seeds:
            for a in ats:
                for m in methods:
                    if (d,s,a,m) not in done:jobs.append((d,s,a,m))
    for k,(d,s,a,m) in enumerate(jobs,1):
        row,cs,meta=run(d,s,a,m,args.stress)
        append_csv(result,[row]);append_csv(curve,cs)
        (ROOT/f'data_{d}_seed{s}_{name}.json').write_text(json.dumps(meta,indent=2))
        print(f'{name} {k}/{len(jobs)} {d} seed={s} {a} {m}: acc={row["test_accuracy"]:.4f} ce={row["test_ce"]:.4f} sec={row["wall_seconds"]:.2f}',flush=True)
    print('completed',name,flush=True)

if __name__=='__main__':main()
