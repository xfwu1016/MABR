from pathlib import Path
import json
import numpy as np
import pandas as pd
from run_joint import ROOT,CFG,run,sampling_plans,prepare

controls=[]
for dataset in ['mammographic_mass','hepatitis']:
    for seed in [0,1]:
        hashes=[]
        for partition in ['random','burden']:
            for attack in ['none','signflip','root_aligned']:
                row,_,_,_=run(dataset,partition,seed,attack,'Joint-ReferenceOnly',rounds=2)
                hashes.append(row['parameter_sha256'])
        assert len(set(hashes))==1,(dataset,seed,hashes)
        controls.append(dict(dataset=dataset,seed=seed,rounds=2,all_attacks_and_partitions_hash_invariant=True))

plan_checks=[]
for dataset in ['mammographic_mass','hepatitis']:
    for partition in ['random','burden']:
        for seed in [0,1]:
            clients,ref,_,_,meta=prepare(dataset,seed,partition)
            rp,cp,pp=sampling_plans(seed,len(ref[1]),meta['original_variables'],[len(c[1]) for c in clients],160)
            rng=np.random.default_rng(600+seed)
            for step in range(160):
                assert np.array_equal(rp[step],rng.integers(0,len(ref[1]),CFG['reference_batch']))
                assert np.array_equal(cp[step],rng.random((CFG['reference_batch'],meta['original_variables'])))
                for i,c in enumerate(clients):assert np.array_equal(pp[step][i],rng.integers(0,len(c[1]),CFG['private_batch']))
            plan_checks.append(dict(dataset=dataset,partition=partition,seed=seed,all_160_round_plans_match_product=True))

equivalence=[]
if (ROOT/'joint_runs.csv').exists():
    df=pd.read_csv(ROOT/'joint_runs.csv')
    candidates=[df.iloc[0],df[df.method=='Joint-MGT-Med'].iloc[-1]]
    for saved in candidates:
        row,_,_,_=run(saved.dataset,saved.partition,int(saved.seed),saved.attack,saved.method)
        assert row['parameter_sha256']==saved.parameter_sha256
        equivalence.append(dict(dataset=saved.dataset,partition=saved.partition,seed=int(saved.seed),attack=saved.attack,method=saved.method,exact_hash_after_readonly_plan_refactor=True))

out=dict(two_round_controls=controls,read_only_plans_equal_product=plan_checks,completed_160_round_equivalence=equivalence)
(ROOT/'rng_control_checks.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
