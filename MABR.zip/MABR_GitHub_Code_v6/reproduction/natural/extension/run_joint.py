"""Joint empirical natural-mask extension with maximal paired reference masks."""
import os
for key in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
from pathlib import Path
import csv,hashlib,json,sys,time,argparse
import numpy as np
import pandas as pd
from scipy.stats import t as tdist

ROOT=Path(__file__).resolve().parent
PARENT=ROOT.parent
sys.path.insert(0,str(PARENT))
from run_natural import CFG,MLP,prepare,load_data,evaluate,append,METRICS
from author_methods import fltrust_update,root_cone_attack

def unique_json_keys(pairs):
    result={}
    for k,v in pairs:
        if k in result:raise ValueError('Duplicate JSON protocol key: '+k)
        result[k]=v
    return result

PROTOCOL=json.loads((ROOT/'protocol.json').read_text(),object_pairs_hook=unique_json_keys)
assert PROTOCOL['attacks']==['none','signflip','root_aligned']
assert len(PROTOCOL['methods'])==4 and len(set(PROTOCOL['methods']))==4

def sample_indices(prob,u):
    cdf=np.cumsum(prob);cdf[-1]=1.
    return np.searchsorted(cdf,u,side='right')

def coupled_pattern_indices(pi,target,target_indices,rng):
    overlap=np.minimum(pi,target); c=float(overlap.sum())
    if np.array_equal(pi,target):return target_indices.copy()
    denom=target[target_indices]
    assert np.all(denom>0)
    keep=rng.random(len(target_indices))<overlap[target_indices]/denom
    residual=np.maximum(0.,pi-overlap)
    if residual.sum()<=1e-14:
        # Floating representation of distributions equal to machine precision.
        assert np.max(np.abs(pi-target))<1e-14
        return target_indices.copy()
    residual/=residual.sum()
    out=sample_indices(residual,rng.random(len(target_indices)))
    out[keep]=target_indices[keep]
    return out

def joint_laws(dataset,meta):
    _,_,m=load_data(dataset)
    private=np.asarray(meta['row_ids']['private'])
    support,inv=np.unique(m[private],axis=0,return_inverse=True)
    target=np.bincount(inv,minlength=len(support))/len(private)
    # Private row order is used only to look up the exact original mask pattern.
    row2pattern={int(row):int(pattern) for row,pattern in zip(private,inv)}
    client=[]
    for ids in meta['row_ids']['clients']:
        idx=np.array([row2pattern[row] for row in ids])
        client.append(np.bincount(idx,minlength=len(support))/len(idx))
    client=np.stack(client)
    unique,ix=np.unique(np.vstack([target,client]),axis=0,return_inverse=True)
    assert np.allclose(unique.sum(axis=1),1.) and np.all(unique>=0)
    tv=.5*np.abs(client-target).sum(axis=1)
    return support,target,unique,ix,tv

def coupling_check():
    rng=np.random.default_rng(414)
    cases=[(np.array([.1,.2,.3,.4]),np.array([.4,.3,.2,.1])),
           (np.array([.5,.5,0.,0.]),np.array([0.,0.,.6,.4])),
           (np.array([.1,.2,.3,.4]),np.array([.1,.2,.3,.4]))]
    rows=[]
    for pi,target in cases:
        targetidx=sample_indices(target,rng.random(200000))
        ii=coupled_pattern_indices(pi,target,targetidx,rng)
        marginal=np.bincount(ii,minlength=4)/len(ii)
        mismatch=float(np.mean(ii!=targetidx));tv=.5*np.abs(pi-target).sum()
        err=float(np.max(np.abs(marginal-pi)))
        assert err<.004 and abs(mismatch-tv)<.004
        rows.append(dict(pi=pi.tolist(),target=target.tolist(),max_marginal_error=err,measured_mismatch=mismatch,expected_tv=float(tv),n=200000))
    return rows

def sampling_plans(seed,reference_size,original_variables,client_sizes,rounds):
    """Immutable, separately consumed streams matching the original product run.

    Pregeneration preserves the original common-random-number plan exactly;
    no diagnostic or client-profile calculation can advance another stream.
    """
    source=np.random.default_rng(600+seed)
    reference=[];canonical=[];private=[]
    for _ in range(rounds):
        reference.append(source.integers(0,reference_size,CFG['reference_batch']))
        canonical.append(source.random((CFG['reference_batch'],original_variables)))
        private.append([source.integers(0,n,CFG['private_batch']) for n in client_sizes])
    for a in reference+canonical+[x for step in private for x in step]:a.setflags(write=False)
    return reference,canonical,private

def run(dataset,partition,seed,attack,method,rounds=None):
    assert attack in ('none','signflip','root_aligned') and method in PROTOCOL['methods']
    clients,ref,test,(product_unique,product_ix,group),meta=prepare(dataset,seed,partition)
    support,target,unique,ix,tv=joint_laws(dataset,meta)
    net=MLP(meta['encoded_features'],2,CFG['hidden']);theta=net.initialize(np.random.default_rng(500+seed))
    target_rng=np.random.default_rng(7600+seed)
    coupling_rng=np.random.default_rng(7700+seed)
    n=CFG['n_clients'];f=CFG['n_byzantine'];honest=n if attack=='none' else n-f
    R=rounds or CFG['rounds'];curves=[];zero_scores=0;bad_shares=[];mismatch=[];cones=[];rawdisp=[];corrdisp=[]
    reference_plan,canonical_plan,private_plan=sampling_plans(seed,len(ref[1]),meta['original_variables'],[len(c[1]) for c in clients],R)
    start=time.perf_counter()
    for step in range(R):
        rid=reference_plan[step];rx,ry=ref[0][rid],ref[1][rid]
        # Preserve the original natural run's private sampling stream exactly.
        product_u=canonical_plan[step]
        target_indices=sample_indices(target,target_rng.random(len(rid)))
        target_mask=support[target_indices][:,group]
        a=net.loss_grad(theta,rx,ry,target_mask)[1]
        gradients=[]; mismatch_by_profile=[]
        for pi in unique:
            ii=coupled_pattern_indices(pi,target,target_indices,coupling_rng)
            mismatch_by_profile.append(float(np.mean(ii!=target_indices)))
            gradients.append(a if np.array_equal(pi,target) else net.loss_grad(theta,rx,ry,support[ii][:,group])[1])
        D=np.stack(gradients)[ix[1:]]-a
        mismatch.append(np.array(mismatch_by_profile)[ix[1:]])
        G=[]
        for client_idx,(x,y,m) in enumerate(clients):
            jj=private_plan[step][client_idx]
            G.append(net.loss_grad(theta,x[jj],y[jj],m[jj])[1])
        G=np.stack(G)
        if attack=='signflip':G[honest:]=-5*G[:honest].mean(axis=0)
        elif attack=='root_aligned':
            # Use the same canonical product-corrected honest objective for all
            # joint variants; joint correction cannot alter the attack target.
            pa=np.stack([net.loss_grad(theta,rx,ry,(product_u<q)[:,group])[1] for q in product_unique])
            productD=pa[product_ix[1:]]-pa[product_ix[0]]
            G[honest:],am=root_cone_attack(G[:honest],a,(G[:honest]-productD[:honest]).mean(axis=0),f=f,scale=5.)
            cones.append(am['cosine'])
        corrected=G-D
        rawdisp.append(np.mean(np.sum((G[:honest]-G[:honest].mean(axis=0))**2,axis=1)))
        corrdisp.append(np.mean(np.sum((corrected[:honest]-corrected[:honest].mean(axis=0))**2,axis=1)))
        use=corrected if method in ('Joint-MGT-Med','Joint-TransportFLTrust') else G
        if method in ('Joint-FLTrust','Joint-TransportFLTrust'):
            update,extra=fltrust_update(use,a);zero_scores+=extra['fallback']
            scores=extra['scores'];bad_shares.append(float(scores[honest:].sum()/(scores.sum()+1e-9)) if attack!='none' else 0.)
        elif method=='Joint-MGT-Med':update=np.median(use,axis=0)
        else:update=a
        theta-=CFG['learning_rate']*update
        assert np.isfinite(theta).all()
        if (step+1)%10==0:curves.append(dict(dataset=dataset,partition=partition,seed=seed,attack=attack,method=method,round=step+1,**evaluate(net,theta,test)))
    wall=time.perf_counter()-start
    transport=method in ('Joint-MGT-Med','Joint-TransportFLTrust')
    server=len(unique) if transport else 1
    row=dict(dataset=dataset,partition=partition,seed=seed,attack=attack,method=method,rounds=R,**evaluate(net,theta,test),
             n_private=meta['n_private'],n_reference=meta['n_reference'],n_test=meta['n_test'],incomplete_test_cases=meta['incomplete_test_cases'],
             parameter_dim=net.dim,parameter_norm=float(np.linalg.norm(theta)),parameter_sha256=hashlib.sha256(theta.tobytes()).hexdigest(),
             raw_dispersion=float(np.mean(rawdisp)),corrected_dispersion=float(np.mean(corrdisp)),
             mean_client_tv=float(np.mean(tv)),max_client_tv=float(tv.max()),mean_measured_pair_mismatch=float(np.mean(mismatch)),
             max_pair_mismatch_calibration_error=float(np.max(np.abs(np.mean(mismatch,axis=0)-tv))),
             fltrust_zero_score_rounds=zero_scores,fltrust_bad_weight_share=float(np.mean(bad_shares)) if bad_shares else float('nan'),
             root_cone_mean_cosine=float(np.mean(cones)) if cones else float('nan'),wall_seconds=wall,
             required_server_gradient_evals_per_round=server,required_server_gradient_evals=server*R,
             diagnostic_joint_gradient_evals=len(unique)*R,
             attack_construction_product_gradient_evals=len(product_unique)*R if attack=='root_aligned' else 0,
             reference_batch=CFG['reference_batch'],n_distinct_client_laws=len(np.unique(unique[ix[1:]],axis=0)),
             profile_support_size=len(support),
             required_private_gradient_evals=0 if method=='Joint-ReferenceOnly' else n*R,
             uplink_float64_values=0 if method=='Joint-ReferenceOnly' else n*net.dim*R,
             downlink_float64_values=0 if method=='Joint-ReferenceOnly' else n*net.dim*R)
    jmeta=dict(**meta,joint_pattern_support=support.astype(int).tolist(),target_joint_pattern_probabilities=target.tolist(),
               client_joint_pattern_probabilities=unique[ix[1:]].tolist(),client_tv_to_target=tv.tolist(),
               required_transport_reference_gradients_per_round=len(unique))
    return row,curves,theta,jmeta

def summarize():
    df=pd.read_csv(ROOT/'joint_runs.csv');assert len(df)==240
    keys=['dataset','partition','attack','method']
    summary=df.groupby(keys)[METRICS].agg(['mean','std','count']);summary.columns=['_'.join(c) for c in summary.columns]
    summary.reset_index().to_csv(ROOT/'joint_summary.csv',index=False)
    product=pd.read_csv(PARENT/'natural_runs.csv')
    pairs=[]
    for key,g in df.groupby(['dataset','partition','attack']):
        for method,comparator in [('Joint-MGT-Med','Joint-FLTrust'),('Joint-TransportFLTrust','Joint-FLTrust'),('Joint-MGT-Med','MGT-Med'),('Joint-FLTrust','FLTrust')]:
            l=g[g.method==method].set_index('seed')
            if comparator.startswith('Joint-'):r=g[g.method==comparator].set_index('seed')
            else:r=product[(product.dataset==key[0])&(product.partition==key[1])&(product.attack==key[2])&(product.method==comparator)].set_index('seed')
            assert len(l)==len(r)==5
            for metric in METRICS:
                diff=l[metric]-r[metric];mean=float(diff.mean());sd=float(diff.std(ddof=1));half=float(tdist.ppf(.975,4)*sd/np.sqrt(5))
                pairs.append(dict(dataset=key[0],partition=key[1],attack=key[2],method=method,comparator=comparator,metric=metric,mean_difference=mean,sd_difference=sd,n=5,descriptive_t95_low=mean-half,descriptive_t95_high=mean+half,**{'seed'+str(s)+'_difference':float(v) for s,v in diff.items()}))
    pd.DataFrame(pairs).to_csv(ROOT/'joint_paired_differences.csv',index=False)
    controls=[]
    for key,g in df[df.method=='Joint-ReferenceOnly'].groupby(['dataset','seed']):
        controls.append(dict(dataset=key[0],seed=int(key[1]),all_attacks_and_partitions_hash_invariant=bool(g.parameter_sha256.nunique()==1)))
    assert all(c['all_attacks_and_partitions_hash_invariant'] for c in controls)
    integrity=dict(n_fits=len(df),duplicate_keys=int(df.duplicated(['dataset','partition','seed','attack','method']).sum()),
                   all_endpoints_finite=bool(np.isfinite(df[METRICS+['parameter_norm']]).all().all()),
                   reference_only_controls=controls,coupling_sanity=coupling_check(),
                   transport_gradient_evals_per_round=sorted(df[df.method=='Joint-MGT-Med'].required_server_gradient_evals_per_round.unique().astype(int).tolist()),
                   max_measured_pairing_tv_discrepancy=float(df.max_pair_mismatch_calibration_error.max()),
                   unique_parameter_hashes=int(df.parameter_sha256.nunique()),
                   numerical_rule='FLTrust author eps1e-9 / zero update at zero total scores; source-fidelity repair, not test-selected.')
    assert integrity['all_endpoints_finite'] and integrity['duplicate_keys']==0
    (ROOT/'integrity.json').write_text(json.dumps(integrity,indent=2))
    print(json.dumps(integrity,indent=2))

def main():
    p=argparse.ArgumentParser();p.add_argument('--summarize',action='store_true');args=p.parse_args()
    if args.summarize:summarize();return
    checks=coupling_check();(ROOT/'coupling_check.json').write_text(json.dumps(checks,indent=2))
    (ROOT/'source_hashes.json').write_text(json.dumps({str(p.relative_to(PARENT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),ROOT/'protocol.json',PARENT/'run_natural.py',PARENT/'author_methods.py']},indent=2))
    output=ROOT/'joint_runs.csv';done=set()
    if output.exists():
        with output.open() as f:done={(r['dataset'],r['partition'],int(r['seed']),r['attack'],r['method']) for r in csv.DictReader(f)}
    jobs=[(d,p,s,a,m) for d in PROTOCOL['datasets'] for p in PROTOCOL['partitions'] for s in PROTOCOL['seeds'] for a in PROTOCOL['attacks'] for m in PROTOCOL['methods']]
    assert len(jobs)==len(set(jobs))==PROTOCOL['n_fits']==240
    jobs=[x for x in jobs if x not in done]
    (ROOT/'models').mkdir(exist_ok=True);(ROOT/'splits').mkdir(exist_ok=True)
    for k,(d,p,s,a,m) in enumerate(jobs,1):
        row,cs,theta,meta=run(d,p,s,a,m);append(output,[row]);append(ROOT/'joint_curves.csv',cs)
        np.save(ROOT/'models'/f'{d}_{p}_seed{s}_{a}_{m}.npy',theta)
        (ROOT/'splits'/f'{d}_{p}_seed{s}.json').write_text(json.dumps(meta,indent=2))
        print(f'{k}/{len(jobs)} {d} {p} seed{s} {a} {m}: acc={row["test_accuracy"]:.4f} BA={row["test_balanced_accuracy"]:.4f} CE={row["test_ce"]:.4f} sec={row["wall_seconds"]:.2f}',flush=True)
    summarize()

if __name__=='__main__':main()
