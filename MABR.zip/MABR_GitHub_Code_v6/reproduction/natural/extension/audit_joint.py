from pathlib import Path
import json,hashlib,itertools
import numpy as np
import pandas as pd
from run_joint import ROOT,PARENT,PROTOCOL,run

df=pd.read_csv(ROOT/'joint_runs.csv')
keycols=['dataset','partition','seed','attack','method']
expected=set(itertools.product(PROTOCOL['datasets'],PROTOCOL['partitions'],PROTOCOL['seeds'],PROTOCOL['attacks'],PROTOCOL['methods']))
actual=set(map(tuple,df[keycols].to_records(index=False)))
assert len(df)==len(actual)==240 and actual==expected
assert (df['rounds']==160).all()
arrays=[]
for row in df.itertuples():
    p=ROOT/'models'/f'{row.dataset}_{row.partition}_seed{row.seed}_{row.attack}_{row.method}.npy'
    theta=np.load(p)
    assert np.isfinite(theta).all() and hashlib.sha256(theta.tobytes()).hexdigest()==row.parameter_sha256
    arrays.append(dict(file=str(p.relative_to(ROOT)),parameter_sha256=row.parameter_sha256))
replays=[]
for d,p,s,a,m in [
    ('mammographic_mass','random',0,'root_aligned','Joint-MGT-Med'),
    ('hepatitis','burden',1,'none','Joint-FLTrust'),
    ('hepatitis','random',2,'signflip','Joint-TransportFLTrust')]:
    row,_,_,_=run(d,p,s,a,m)
    saved=df[(df.dataset==d)&(df.partition==p)&(df.seed==s)&(df.attack==a)&(df.method==m)].iloc[0]
    assert row['parameter_sha256']==saved.parameter_sha256
    replays.append(dict(dataset=d,partition=p,seed=s,attack=a,method=m,exact_parameter_hash_match=True))
var=np.load(ROOT/'variance_raw_gradients.npz')
variance_checks=[]
vsum=pd.read_csv(ROOT/'variance_summary.csv')
for dataset in PROTOCOL['datasets']:
    exact=var[dataset+'_exact_transport']
    for method in ['maximal','independent_masks']:
        grad=var[dataset+'_'+method]
        measured_var=grad.var(axis=0,ddof=1).sum(axis=1)
        mse=((grad-exact[None,:,:])**2).sum(axis=2).mean(axis=0)
        saved=vsum[(vsum.dataset==dataset)&(vsum.method==method)].sort_values('client')
        assert np.allclose(measured_var,saved.trace_sample_variance,rtol=1e-12,atol=1e-14)
        assert np.allclose(mse,saved.mean_squared_transport_error,rtol=1e-12,atol=1e-14)
        variance_checks.append(dict(dataset=dataset,method=method,variance_and_mse_recomputed_from_all_raw_gradients=True))
out=dict(status='VERIFIED',exact_legal_grid=True,n_fits=240,all_parameter_arrays_match_endpoint_hash=True,
         replays=replays,variance_raw_recomputations=variance_checks,
         active_source_sha256={str(p.relative_to(PARENT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'run_joint.py',ROOT/'protocol.json',PARENT/'run_natural.py',PARENT/'protocol.json',PARENT/'author_methods.py']},
         excluded_directories=['invalid_protocol_key','superseded_rng'],
         scope='Implementation and finite-sample evidence audit, not proof certification or population/clinical validation.')
(ROOT/'audit.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
