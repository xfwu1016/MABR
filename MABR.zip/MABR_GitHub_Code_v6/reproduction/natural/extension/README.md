# Joint natural-mask extension

Read report.md and protocol.json. Active primary analysis is exactly 240
legal fits marked JOINT_OFFICIAL_COMPLETE in status.json. Product-mask
results remain in the parent folder. No artificial private/test deletion
is used; representation is reference-scaled zero-fill with original masks,
without a fitted imputation model or outcome-based reconstruction.

From this folder, with the parent natural/ files and raw data retained:

    python check_rng_control.py
    python run_joint.py
    python variance_diagnostic.py
    python audit_joint.py
    python make_report.py

The training runner resumes legal endpoint keys in joint_runs.csv. For an
independent full rerun use a fresh copy without joint_runs.csv and
joint_curves.csv. There is no test-based hyperparameter selection.

Do not merge invalid_protocol_key/ or superseded_rng/ into analysis.
The empirical pattern law captures unconditional mask correlations only;
informative missingness and complete-case selection residuals remain.
Raw gradient NPZ is retained for the separate fixed-core diagnostic.
