"""Fixed-theta finite-core calibration Monte Carlo diagnostic (no test use)."""
from pathlib import Path
import csv,json,hashlib
import numpy as np
from run_joint import ROOT,PARENT,MLP,CFG,prepare,joint_laws,sample_indices,coupled_pattern_indices

REPS=200
summaries=[];raw=[];arrays={}
for dataset in ['mammographic_mass','hepatitis']:
    clients,ref,_,(_,_,group),meta=prepare(dataset,0,'random')
    support,target,unique,ix,tv=joint_laws(dataset,meta)
    net=MLP(meta['encoded_features'],2,CFG['hidden']);theta=net.initialize(np.random.default_rng(500))
    # Exact expectation: finite reference core x finite pattern support. No test
    # record, fitted training trajectory or Monte Carlo approximation to D.
    pattern_grads=np.stack([net.loss_grad(theta,ref[0],ref[1],np.repeat(pattern[None,:],len(ref[1]),axis=0)[:,group])[1] for pattern in support])
    exact=(unique[ix[1:]]-target)@pattern_grads
    rr=np.random.default_rng(38000)
    cr=np.random.default_rng(39000)
    ir=np.random.default_rng(40000)
    maximal=[];independent=[]
    for rep in range(REPS):
        ids=rr.integers(0,len(ref[1]),CFG['reference_batch']);rx,ry=ref[0][ids],ref[1][ids]
        star_indices=sample_indices(target,rr.random(len(ids)))
        a=net.loss_grad(theta,rx,ry,support[star_indices][:,group])[1]
        maxgrad=[];indgrad=[]
        for pi in unique[ix[1:]]:
            ci=coupled_pattern_indices(pi,target,star_indices,cr)
            ii=sample_indices(pi,ir.random(len(ids)))
            maxgrad.append(net.loss_grad(theta,rx,ry,support[ci][:,group])[1]-a)
            indgrad.append(net.loss_grad(theta,rx,ry,support[ii][:,group])[1]-a)
        maximal.append(maxgrad);independent.append(indgrad)
    for method,grad in [('maximal',np.asarray(maximal)),('independent_masks',np.asarray(independent))]:
        assert np.isfinite(grad).all()
        errors=grad-exact[None,:,:]
        means=grad.mean(axis=0)
        variances=grad.var(axis=0,ddof=1).sum(axis=1)
        mse=(errors**2).sum(axis=2).mean(axis=0)
        bias2=((means-exact)**2).sum(axis=1)
        # Finite-sample decomposition MSE=(R-1)/R * sample trace variance+bias².
        assert np.allclose(mse,(REPS-1)/REPS*variances+bias2,rtol=1e-10,atol=1e-14)
        for client in range(11):
            summaries.append(dict(dataset=dataset,partition='random',seed=0,theta='fixed_initialization',method=method,client=client,
                                  repetitions=REPS,reference_size=len(ref[1]),reference_batch=CFG['reference_batch'],tv_to_target=float(tv[client]),
                                  trace_sample_variance=float(variances[client]),mean_squared_transport_error=float(mse[client]),
                                  squared_monte_carlo_sample_bias=float(bias2[client]),exact_transport_norm=float(np.linalg.norm(exact[client]))))
        for rep in range(REPS):
            for client in range(11):
                raw.append(dict(dataset=dataset,method=method,repetition=rep,client=client,
                                squared_error=float(np.sum(errors[rep,client]**2)),squared_estimate_norm=float(np.sum(grad[rep,client]**2))))
        arrays[dataset+'_'+method]=grad
    arrays[dataset+'_exact_transport']=exact
    arrays[dataset+'_pattern_gradients']=pattern_grads
    arrays[dataset+'_theta']=theta
    arrays[dataset+'_support']=support
    arrays[dataset+'_target_probabilities']=target
    arrays[dataset+'_client_probabilities']=unique[ix[1:]]
    print(dataset,'completed 200 paired core/mask replications',flush=True)

for name,rows in [('variance_summary.csv',summaries),('variance_replicates.csv',raw)]:
    with (ROOT/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
np.savez_compressed(ROOT/'variance_raw_gradients.npz',**arrays)
import pandas as pd
summary=pd.DataFrame(summaries)
pivot=summary.pivot(index=['dataset','client'],columns='method',values=['trace_sample_variance','mean_squared_transport_error'])
details=[]
for dataset in ['mammographic_mass','hepatitis']:
    d=pivot.loc[dataset]
    vr=d['trace_sample_variance']['maximal']/d['trace_sample_variance']['independent_masks']
    mr=d['mean_squared_transport_error']['maximal']/d['mean_squared_transport_error']['independent_masks']
    details.append(dict(dataset=dataset,clients_with_lower_measured_variance=int((vr<1).sum()),n_clients=11,
                        ratio_of_summed_trace_variances=float(d['trace_sample_variance']['maximal'].sum()/d['trace_sample_variance']['independent_masks'].sum()),
                        ratio_of_summed_mean_squared_errors=float(d['mean_squared_transport_error']['maximal'].sum()/d['mean_squared_transport_error']['independent_masks'].sum()),
                        min_client_variance_ratio=float(vr.min()),max_client_variance_ratio=float(vr.max())))
record=dict(status='COMPLETE',datasets=details,repetitions_per_configuration=REPS,configurations=2,
            frozen_theta='Same Glorot initialization seed500 used by corresponding training run; no test values or outcomes enter this diagnostic.',
            target='Exact expected gradient transport over the fixed, reused complete core and finite empirical joint mask patterns.',
            comparison='Both methods share reference indices and target-mask draw; client mask has either maximal coupling or independent law. Cross-client dependence is allowed.',
            scope='Conditional finite-core Monte Carlo error only; neither population error nor complete-case bias is evaluated. Maximal mismatch coupling does not imply a universal ordering of gradient variance.',
            files_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'variance_summary.csv',ROOT/'variance_replicates.csv',ROOT/'variance_raw_gradients.npz']})
(ROOT/'variance_diagnostic.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
