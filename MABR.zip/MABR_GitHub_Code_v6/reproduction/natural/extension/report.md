# Empirical joint-mask extension: evidence and limits

Completed 2026-10-29. Primary outputs have the JOINT_OFFICIAL_COMPLETE marker in status.json. This is a post-review mechanism extension, motivated by natural cross-variable missing-pattern dependence. It was not preregistered, and no test-based hyperparameter/checkpoint search was performed.

## Construction and fair comparators

For each of the two natural datasets, the original 360-fit data splits, complete reference cores, reference-only scaler, encoded features, original private/test masks and simulated clients are unchanged. An empirical law pi_i counts complete original-variable mask patterns in client training data; pi_star counts those in the pooled private training set. No test mask or outcome enters these distributions. The curator provides pi_star as trusted pre-attack metadata. The larger pattern-frequency message is extra metadata compared with a vector of marginal observation rates; it has no differential privacy guarantee.

The joint law preserves unconditional cross-variable mask dependence in the training data. It does not recover unobserved values or identify whether a mask depends on feature values or outcomes. The complete-case reference core may have a selected population distribution. Consequently the empirical working-law correction does not remove natural informative-missingness or reference-selection residuals.

Reference transport uses maximal coupling: draw one shared target pattern Mstar from pi_star; retain it for client i with probability min(pi_i(Mstar),pi_star(Mstar))/pi_star(Mstar); on rejection draw from the positive client residual law. The mismatch probability equals total variation. One-hot levels for Mammographic Shape/Margin share the original variable event. Each pair uses the same complete reference observation. Exactly identical laws are collapsed, giving 6–12 required reference minibatch gradients per round for Joint-MGT-Med/Joint-TransportFLTrust, versus one for Joint-FLTrust and Joint-ReferenceOnly. The reference batch stays 64, with replacement.

All four comparators use the same joint target anchor. FLTrust uses the authors' eps1e-9/zero-score numerical rule, and this rule is also used by root-cone selection. The model and optimization remain 24 tanh hidden units, SGD .15, 160 rounds, private batch32, cores64/16, and five paired seeds. All 240 endpoints are retained.

Core indices, canonical product-mask uniforms and private minibatches are consumed as separate immutable plans, reproducing the product run's sampling plan exactly. Target joint patterns and client coupling have separate RNG streams. The finite root-cone search uses the current JOINT root anchor but the uniformly defined ORIGINAL PRODUCT corrected honest mean as its objective. Thus a joint method cannot change attack selection by changing its own correction. However the root anchor law changes between product and joint variants, so their root-cone differences are system comparisons rather than isolated causal effects of the mask model. White-box product-gradient computations used only to construct attacks are counted separately.

## Observed comparison boundary

Under root-cone stress, Joint-MGT-Med exceeds Joint-FLTrust in all four dataset/partition mean accuracy and balanced-accuracy cells. Mean accuracy gaps are +2.680 pp (Mammographic/random), +2.975 pp (Mammographic/burden), +7.660 pp (Hepatitis/random), and +4.681 pp (Hepatitis/burden). These conditional advantages do not establish an all-attack or all-data advantage.

Without attacks Joint-MGT-Med has lower mean accuracy and balanced accuracy than Joint-FLTrust in all four conditions. Under signflip its balanced accuracy is lower in both Hepatitis partitions and nearly tied on Mammographic. Against product MGT-Med, joint MGT has higher mean balanced accuracy in six of 12 conditions and lower in six. The richer mask model therefore has no established universal predictive advantage. The full product Median baseline remains in the companion 360-fit analysis and is frequently competitive; robust aggregation itself must not be confused with a correction-specific benefit.

All condition counts share datasets and seeds. Means and sample SD reflect five paired split/training realizations, not independent clinical cohorts. Complete per-seed differences and descriptive t intervals are in joint_paired_differences.csv; no selective significance conclusion is made.

## Conditional finite-core variance diagnostic

A separate diagnostic fixes initialization and the complete core for random partition/seed0 in each dataset. The exact expected transport is enumerated over every reference-core example and every finite observed pattern. It uses neither test data nor a trained/selected parameter. Each of 200 repetitions draws the same core indices and target patterns for two schemes; only the client mask coupling changes (maximal versus independent). The full float64 estimated gradients and exact D are in variance_raw_gradients.npz; per-client variance and MSE are in variance_summary.csv.

The ratio of summed coordinate sample variances (maximal/independent) is 0.3110945 for Mammographic and 0.6276087 for Hepatitis. All 22 client-profile comparisons have lower measured variance at this fixed parameter. Ratios of summed MSE to exact finite-core transport are 0.3112931 and 0.6285224. These are observed conditional Monte Carlo reductions; they do not establish population bias removal, generalization, or a universal ordering of gradient variance under maximal coupling.

## Accuracy (%) — mean ± sample SD, five paired seeds

| Dataset | Partition | Attack | Joint-FLTrust | Joint-MGT-Med | Joint-TransportFLTrust | Joint-ReferenceOnly |
|---|---|---|---:|---:|---:|---:|
| hepatitis | burden | none | 86.81 ± 1.78 | 84.68 ± 3.81 | 84.68 ± 3.50 | 80.43 ± 4.36 |
| hepatitis | burden | root_aligned | 77.87 ± 3.23 | 82.55 ± 5.90 | 77.45 ± 3.23 | 80.43 ± 4.36 |
| hepatitis | burden | signflip | 83.40 ± 2.33 | 80.85 ± 4.99 | 80.85 ± 3.01 | 80.43 ± 4.36 |
| hepatitis | random | none | 85.53 ± 3.50 | 83.83 ± 3.23 | 84.68 ± 4.09 | 80.43 ± 4.36 |
| hepatitis | random | root_aligned | 77.87 ± 2.85 | 85.53 ± 3.50 | 78.72 ± 3.01 | 80.43 ± 4.36 |
| hepatitis | random | signflip | 82.98 ± 3.98 | 82.55 ± 6.45 | 84.68 ± 3.50 | 80.43 ± 4.36 |
| mammographic_mass | burden | none | 79.40 ± 1.21 | 79.06 ± 1.02 | 79.13 ± 1.37 | 75.81 ± 2.41 |
| mammographic_mass | burden | root_aligned | 75.87 ± 3.00 | 78.84 ± 1.27 | 76.14 ± 2.67 | 75.81 ± 2.41 |
| mammographic_mass | burden | signflip | 78.78 ± 1.51 | 78.99 ± 2.23 | 78.91 ± 1.77 | 75.81 ± 2.41 |
| mammographic_mass | random | none | 79.46 ± 1.38 | 78.60 ± 1.47 | 79.26 ± 1.43 | 75.81 ± 2.41 |
| mammographic_mass | random | root_aligned | 75.94 ± 2.97 | 78.62 ± 2.47 | 75.89 ± 2.94 | 75.81 ± 2.41 |
| mammographic_mass | random | signflip | 78.85 ± 1.33 | 79.17 ± 1.82 | 78.83 ± 1.01 | 75.81 ± 2.41 |

## Balanced accuracy (%) — mean ± sample SD, five paired seeds

| Dataset | Partition | Attack | Joint-FLTrust | Joint-MGT-Med | Joint-TransportFLTrust | Joint-ReferenceOnly |
|---|---|---|---:|---:|---:|---:|
| hepatitis | burden | none | 77.86 ± 5.84 | 75.61 ± 4.92 | 75.22 ± 8.39 | 69.18 ± 12.02 |
| hepatitis | burden | root_aligned | 64.59 ± 12.55 | 72.53 ± 8.19 | 63.68 ± 13.32 | 69.18 ± 12.02 |
| hepatitis | burden | signflip | 73.52 ± 5.32 | 66.25 ± 3.80 | 68.45 ± 9.58 | 69.18 ± 12.02 |
| hepatitis | random | none | 74.39 ± 9.72 | 73.68 ± 5.28 | 72.30 ± 8.89 | 69.18 ± 12.02 |
| hepatitis | random | root_aligned | 64.24 ± 12.05 | 73.72 ± 10.51 | 65.42 ± 11.35 | 69.18 ± 12.02 |
| hepatitis | random | signflip | 75.04 ± 8.47 | 70.33 ± 9.75 | 74.59 ± 8.15 | 69.18 ± 12.02 |
| mammographic_mass | burden | none | 79.81 ± 1.31 | 79.19 ± 1.25 | 79.50 ± 1.48 | 76.19 ± 2.75 |
| mammographic_mass | burden | root_aligned | 76.09 ± 3.16 | 79.15 ± 1.13 | 76.38 ± 2.85 | 76.19 ± 2.75 |
| mammographic_mass | burden | signflip | 79.24 ± 1.55 | 79.22 ± 2.09 | 79.36 ± 1.73 | 76.19 ± 2.75 |
| mammographic_mass | random | none | 79.78 ± 1.66 | 78.57 ± 1.85 | 79.59 ± 1.78 | 76.19 ± 2.75 |
| mammographic_mass | random | root_aligned | 76.10 ± 3.21 | 78.86 ± 2.64 | 76.01 ± 3.23 | 76.19 ± 2.75 |
| mammographic_mass | random | signflip | 79.35 ± 1.39 | 79.43 ± 1.85 | 79.38 ± 0.93 | 76.19 ± 2.75 |

## Cross entropy — mean ± sample SD, five paired seeds

| Dataset | Partition | Attack | Joint-FLTrust | Joint-MGT-Med | Joint-TransportFLTrust | Joint-ReferenceOnly |
|---|---|---|---:|---:|---:|---:|
| hepatitis | burden | none | 0.536 ± 0.228 | 0.568 ± 0.260 | 0.463 ± 0.122 | 0.710 ± 0.235 |
| hepatitis | burden | root_aligned | 0.975 ± 0.449 | 0.524 ± 0.151 | 0.940 ± 0.433 | 0.710 ± 0.235 |
| hepatitis | burden | signflip | 0.614 ± 0.084 | 0.625 ± 0.237 | 0.588 ± 0.098 | 0.710 ± 0.235 |
| hepatitis | random | none | 0.622 ± 0.356 | 0.503 ± 0.184 | 0.484 ± 0.143 | 0.710 ± 0.235 |
| hepatitis | random | root_aligned | 0.885 ± 0.352 | 0.486 ± 0.181 | 0.861 ± 0.350 | 0.710 ± 0.235 |
| hepatitis | random | signflip | 0.609 ± 0.154 | 0.578 ± 0.260 | 0.511 ± 0.085 | 0.710 ± 0.235 |
| mammographic_mass | burden | none | 0.480 ± 0.022 | 0.470 ± 0.026 | 0.479 ± 0.021 | 0.566 ± 0.075 |
| mammographic_mass | burden | root_aligned | 0.592 ± 0.107 | 0.480 ± 0.016 | 0.583 ± 0.100 | 0.566 ± 0.075 |
| mammographic_mass | burden | signflip | 0.512 ± 0.044 | 0.488 ± 0.026 | 0.510 ± 0.040 | 0.566 ± 0.075 |
| mammographic_mass | random | none | 0.479 ± 0.021 | 0.473 ± 0.030 | 0.479 ± 0.020 | 0.566 ± 0.075 |
| mammographic_mass | random | root_aligned | 0.586 ± 0.098 | 0.484 ± 0.022 | 0.582 ± 0.095 | 0.566 ± 0.075 |
| mammographic_mass | random | signflip | 0.507 ± 0.044 | 0.487 ± 0.028 | 0.507 ± 0.043 | 0.566 ± 0.075 |

## Integrity and history

- audit.json verifies the exact 240 legal run keys, all 240 model hashes, three full-fit exact replays and raw-gradient recalculation of the diagnostic variances/MSE. rng_control_checks.json records quick two-round reference-only controls, exact compatibility with all 160-round product sampling plans and full-fit hash equivalence after plan refactoring.
- integrity.json records finite endpoints and the 10 Joint-ReferenceOnly dataset/seed parameter hashes invariant across every attack and both partitions. Coupling tests cover equal, disjoint and partially overlapping laws; measured mismatch agrees with TV up to Monte Carlo error.
- invalid_protocol_key/ retains an excluded task-enumeration failure; superseded_rng/ retains an excluded batch whose shared target/coupling RNG failed the planned ReferenceOnly control. Neither directory contributes to primary tables, figures, fit counts or paired differences. Corrections were triggered by configuration/hash checks, not performance selection.
- Historical product numerical-rule runs remain in ../legacy_rules/ and are excluded. Active product and joint results both use the author-code numerical rule.
- No source or result is a formal proof certificate or a clinical/deployment validation.
