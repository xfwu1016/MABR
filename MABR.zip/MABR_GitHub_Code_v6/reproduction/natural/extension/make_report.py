from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
df=pd.read_csv(ROOT/'joint_runs.csv')
summary=pd.read_csv(ROOT/'joint_summary.csv')
paired=pd.read_csv(ROOT/'joint_paired_differences.csv')
assert len(df)==240

def metric_table(metric):
    lines=['| Dataset | Partition | Attack | Joint-FLTrust | Joint-MGT-Med | Joint-TransportFLTrust | Joint-ReferenceOnly |',
           '|---|---|---|---:|---:|---:|---:|']
    factor=1 if metric=='test_ce' else 100
    precision=3 if metric=='test_ce' else 2
    for key,g in summary.groupby(['dataset','partition','attack'],sort=False):
        vals=[]
        for method in ['Joint-FLTrust','Joint-MGT-Med','Joint-TransportFLTrust','Joint-ReferenceOnly']:
            r=g[g.method==method].iloc[0]
            vals.append(f'{factor*r[metric+"_mean"]:.{precision}f} ± {factor*r[metric+"_std"]:.{precision}f}')
        lines.append('| '+' | '.join(list(key)+vals)+' |')
    return '\n'.join(lines)

contrasts=[]
for comparator in ['Joint-FLTrust','MGT-Med']:
    d=paired[(paired.method=='Joint-MGT-Med')&(paired.comparator==comparator)&(paired.metric=='test_balanced_accuracy')]
    contrasts.append(dict(comparator=comparator,n_conditions=len(d),n_conditions_higher_mean_BA=int((d.mean_difference>0).sum()),mean_BA_difference_pp=float(100*d.mean_difference.mean()),min_condition_difference_pp=float(100*d.mean_difference.min()),max_condition_difference_pp=float(100*d.mean_difference.max())))
variance=json.loads((ROOT/'variance_diagnostic.json').read_text())
lines=['# Empirical joint-mask extension: evidence and limits',
       '',
       'Completed 2026-10-29. Primary outputs have the JOINT_OFFICIAL_COMPLETE marker in status.json. This is a post-review mechanism extension, motivated by natural cross-variable missing-pattern dependence. It was not preregistered, and no test-based hyperparameter/checkpoint search was performed.',
       '',
       '## Construction and fair comparators',
       '',
       'For each of the two natural datasets, the original 360-fit data splits, complete reference cores, reference-only scaler, encoded features, original private/test masks and simulated clients are unchanged. An empirical law pi_i counts complete original-variable mask patterns in client training data; pi_star counts those in the pooled private training set. No test mask or outcome enters these distributions. The curator provides pi_star as trusted pre-attack metadata. The larger pattern-frequency message is extra metadata compared with a vector of marginal observation rates; it has no differential privacy guarantee.',
       '',
       'The joint law preserves unconditional cross-variable mask dependence in the training data. It does not recover unobserved values or identify whether a mask depends on feature values or outcomes. The complete-case reference core may have a selected population distribution. Consequently the empirical working-law correction does not remove natural informative-missingness or reference-selection residuals.',
       '',
       'Reference transport uses maximal coupling: draw one shared target pattern Mstar from pi_star; retain it for client i with probability min(pi_i(Mstar),pi_star(Mstar))/pi_star(Mstar); on rejection draw from the positive client residual law. The mismatch probability equals total variation. One-hot levels for Mammographic Shape/Margin share the original variable event. Each pair uses the same complete reference observation. Exactly identical laws are collapsed, giving 6–12 required reference minibatch gradients per round for Joint-MGT-Med/Joint-TransportFLTrust, versus one for Joint-FLTrust and Joint-ReferenceOnly. The reference batch stays 64, with replacement.',
       '',
       'All four comparators use the same joint target anchor. FLTrust uses the authors\' eps1e-9/zero-score numerical rule, and this rule is also used by root-cone selection. The model and optimization remain 24 tanh hidden units, SGD .15, 160 rounds, private batch32, cores64/16, and five paired seeds. All 240 endpoints are retained.',
       '',
       'Core indices, canonical product-mask uniforms and private minibatches are consumed as separate immutable plans, reproducing the product run\'s sampling plan exactly. Target joint patterns and client coupling have separate RNG streams. The finite root-cone search uses the current JOINT root anchor but the uniformly defined ORIGINAL PRODUCT corrected honest mean as its objective. Thus a joint method cannot change attack selection by changing its own correction. However the root anchor law changes between product and joint variants, so their root-cone differences are system comparisons rather than isolated causal effects of the mask model. White-box product-gradient computations used only to construct attacks are counted separately.',
       '',
       '## Observed comparison boundary',
       '',
       'Under root-cone stress, Joint-MGT-Med exceeds Joint-FLTrust in all four dataset/partition mean accuracy and balanced-accuracy cells. Mean accuracy gaps are +2.680 pp (Mammographic/random), +2.975 pp (Mammographic/burden), +7.660 pp (Hepatitis/random), and +4.681 pp (Hepatitis/burden). These conditional advantages do not establish an all-attack or all-data advantage.',
       '',
       'Without attacks Joint-MGT-Med has lower mean accuracy and balanced accuracy than Joint-FLTrust in all four conditions. Under signflip its balanced accuracy is lower in both Hepatitis partitions and nearly tied on Mammographic. Against product MGT-Med, joint MGT has higher mean balanced accuracy in six of 12 conditions and lower in six. The richer mask model therefore has no established universal predictive advantage. The full product Median baseline remains in the companion 360-fit analysis and is frequently competitive; robust aggregation itself must not be confused with a correction-specific benefit.',
       '',
       'All condition counts share datasets and seeds. Means and sample SD reflect five paired split/training realizations, not independent clinical cohorts. Complete per-seed differences and descriptive t intervals are in joint_paired_differences.csv; no selective significance conclusion is made.',
       '',
       '## Conditional finite-core variance diagnostic',
       '',
       'A separate diagnostic fixes initialization and the complete core for random partition/seed0 in each dataset. The exact expected transport is enumerated over every reference-core example and every finite observed pattern. It uses neither test data nor a trained/selected parameter. Each of 200 repetitions draws the same core indices and target patterns for two schemes; only the client mask coupling changes (maximal versus independent). The full float64 estimated gradients and exact D are in variance_raw_gradients.npz; per-client variance and MSE are in variance_summary.csv.',
       '',
       'The ratio of summed coordinate sample variances (maximal/independent) is 0.3110945 for Mammographic and 0.6276087 for Hepatitis. All 22 client-profile comparisons have lower measured variance at this fixed parameter. Ratios of summed MSE to exact finite-core transport are 0.3112931 and 0.6285224. These are observed conditional Monte Carlo reductions; they do not establish population bias removal, generalization, or a universal ordering of gradient variance under maximal coupling.',
       '',
       '## Accuracy (%) — mean ± sample SD, five paired seeds',
       '',metric_table('test_accuracy'),'',
       '## Balanced accuracy (%) — mean ± sample SD, five paired seeds',
       '',metric_table('test_balanced_accuracy'),'',
       '## Cross entropy — mean ± sample SD, five paired seeds',
       '',metric_table('test_ce'),'',
       '## Integrity and history',
       '',
       '- audit.json verifies the exact 240 legal run keys, all 240 model hashes, three full-fit exact replays and raw-gradient recalculation of the diagnostic variances/MSE. rng_control_checks.json records quick two-round reference-only controls, exact compatibility with all 160-round product sampling plans and full-fit hash equivalence after plan refactoring.',
       '- integrity.json records finite endpoints and the 10 Joint-ReferenceOnly dataset/seed parameter hashes invariant across every attack and both partitions. Coupling tests cover equal, disjoint and partially overlapping laws; measured mismatch agrees with TV up to Monte Carlo error.',
       '- invalid_protocol_key/ retains an excluded task-enumeration failure; superseded_rng/ retains an excluded batch whose shared target/coupling RNG failed the planned ReferenceOnly control. Neither directory contributes to primary tables, figures, fit counts or paired differences. Corrections were triggered by configuration/hash checks, not performance selection.',
       '- Historical product numerical-rule runs remain in ../legacy_rules/ and are excluded. Active product and joint results both use the author-code numerical rule.',
       '- No source or result is a formal proof certificate or a clinical/deployment validation.']
(ROOT/'report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
(ROOT/'comparison_counts.json').write_text(json.dumps(contrasts,indent=2))
(ROOT/'README.md').write_text('''# Joint natural-mask extension

Read report.md and protocol.json. Active primary analysis is exactly 240
legal fits marked JOINT_OFFICIAL_COMPLETE in status.json. Product-mask
results remain in the parent folder. No artificial private/test deletion
is used; representation is reference-scaled zero-fill with original masks,
without a fitted imputation model or outcome-based reconstruction.

From this folder, with the parent natural/ files and raw data retained:

    python check_rng_control.py
    python run_joint.py
    python variance_diagnostic.py
    python audit_joint.py
    python make_report.py

The training runner resumes legal endpoint keys in joint_runs.csv. For an
independent full rerun use a fresh copy without joint_runs.csv and
joint_curves.csv. There is no test-based hyperparameter selection.

Do not merge invalid_protocol_key/ or superseded_rng/ into analysis.
The empirical pattern law captures unconditional mask correlations only;
informative missingness and complete-case selection residuals remain.
Raw gradient NPZ is retained for the separate fixed-core diagnostic.
''',encoding='utf-8')
print(json.dumps(contrasts,indent=2))
