# Natural missingness external-data stress study (v3)

Completed 2026-10-29. Evidence status: VERIFIED for downloads, measured results, code checks and tabular metadata. AUTHOR_INPUT_NEEDED for any clinical interpretation or author approval of the final manuscript. The experiment is exploratory and was not externally preregistered.

## Source and natural-missingness provenance

- [UCI Mammographic Mass](https://archive.ics.uci.edu/dataset/161/mammographic+mass), DOI [10.24432/C53K6Z](https://doi.org/10.24432/C53K6Z), dataset by Matthias Elter (2007), CC BY 4.0. BI-RADS assessment is excluded because the distributed documentation calls it non-predictive. Retained original predictors: Age, Shape, Margin, Density. Shape and Margin are one-hot encoded with the documented levels, yielding 11 neural input features before mask concatenation.
- [UCI Hepatitis](https://archive.ics.uci.edu/dataset/46/hepatitis), DOI [10.24432/C5Q59J](https://doi.org/10.24432/C5Q59J), CC BY 4.0. The repository citation year is 1983 although donation is dated 1988; no individual creator was invented. All 19 documented covariates are retained, including continuous Bilirubin. Class is outcome only. Measurement timing is unavailable, so these are computational classification benchmarks rather than prospective clinical prediction.
- Official ZIPs and distributed names files are retained in raw/. sources.json records URLs, access date, licenses and byte hashes. The literal question marks are the only missing-value code. No artificial deletion is applied to private or test data.

| Dataset | Rows | Original variables | Natural missing entries | Missing cells | Complete rows | Distinct natural mask patterns |
|---|---:|---:|---:|---:|---:|---:|
| mammographic_mass | 961 | 4 | 160 | 4.162% | 831 | 8 |
| hepatitis | 155 | 19 | 167 | 5.671% | 80 | 21 |

## Frozen protocol and assumptions

All 961 and 155 raw rows are retained. The absence of patient IDs prevents verification of patient independence. Exact raw predictor representations are grouped when splitting train/test, so no identical observed representation crosses the boundary. GroupShuffleSplit uses 30% of groups for testing; outcome labels are not used for grouping. Mammographic test sets contain 283–329 rows and 32–42 incomplete rows; Hepatitis test sets contain 47 rows and 21–28 incomplete rows. Group sampling can change test class proportions.

A stratified sample from complete training records supplies 64 trusted Mammographic or 16 trusted Hepatitis examples. All are excluded from private training. Only this complete core fits StandardScaler. Missing transformed values are zero-filled and the original observation mask is supplied to the network. Shape/Margin one-hot coordinates share a single original-variable observation event; the same grouping is used for reference masks.

Eleven simulated clients are formed either randomly, or by placing a random 20% prefix before sorting the remaining records by original missing-variable count, splitting into 11 blocks and randomly permuting client IDs. The burden partition changes allocation but does not change an observed value or mask. It is a sensitivity condition, not evidence of a real multisite cohort.

For each original variable q_i=(local observed count+1)/(local size+2). The target profile is the corresponding pooled-private training frequency, without test entries or outcomes. The study curator supplies this target as trusted pre-attack metadata; no robustness to malicious target-profile aggregation or differential privacy is established. The independent product mask law used for reference transport is only a working approximation. Natural missingness can correlate with covariates, outcomes and other missing entries. The complete-case trusted reference can be selected relative to the target population. Thus these data do not validate the common-complete-data-law or MCAR assumptions in the population theorem.

Five paired split/training seeds (0–4), 24 tanh hidden units, softmax cross entropy, learning rate 0.15, 160 rounds, private batch 32 and reference batch 64 with replacement are fixed without test-based tuning. Six methods × two datasets × two partitions × three attacks × five seeds give 360 named fits. ReferenceOnly repeats are controls, not independent extra evidence. The 10 dataset/seed ReferenceOnly parameter states repeat exactly across attacks and partitions.

The root_aligned CSV label denotes the shared finite root-cone stress search, not an optimized reproduction of the original FLTrust adaptive attack. It uses the current anchor, honest raw and corrected reports and a fixed positive-cosine candidate set; it uses no test data. All methods receive the same attack policy, data, initialization and random-number plan. Signflip uses -5 times the mean honest raw report. Under none all 11 clients are honest; under the two attacks IDs 9 and 10 are Byzantine.

Distinct vector profiles require 7–12 reference gradient evaluations per round for MGT-Med and TransportFLTrust, versus one for FLTrust and ReferenceOnly; b0 stays 64. Raw baselines require no algorithmic server gradient. The recorded wall times include common diagnostics, so they are not fair algorithm-speed comparisons.

## What the results establish

MGT-Med exceeds FLTrust in mean accuracy in 5/12 conditions and exceeds raw Median in 4/12. These are dependent descriptive condition counts, not independent replications. Every favorable and unfavorable condition is retained.

For root-cone stress, MGT-Med minus FLTrust mean accuracy is +3.005 pp (Mammographic random), +3.660 pp (Mammographic burden), +5.106 pp (Hepatitis random), and +5.957 pp (Hepatitis burden). The corresponding balanced-accuracy differences are +3.240, +3.739, +6.518 and +9.773 pp. Raw Median is already comparable or better in three of those four conditions. Therefore the root-cone gap versus FLTrust cannot be attributed to transport correction alone.

Without attacks, MGT-Med has lower mean accuracy than FLTrust in all four dataset/partition conditions, and lower mean balanced accuracy in three of four (Hepatitis/random is slightly higher). Under signflip the result is generally tied or worse. On Hepatitis the outcome imbalance makes accuracy and balanced accuracy materially different. TransportFLTrust does not consistently improve FLTrust under natural missingness. These findings delimit the method: the study supports a conditional alignment mechanism and an honest comparison boundary, not universal performance or a validation of the natural missingness model.

Sample SD describes five paired split/training seeds. paired_differences_vs_fltrust.csv also saves all per-seed differences and descriptive t intervals; records overlap across splits, and these intervals are not patient-level clinical confidence intervals. No selective significance claim is made.

## Accuracy (%) — mean ± sample SD over five paired seeds

| Dataset | Partition | Attack | Mean | Median | FLTrust | MGT-Med | TransportFLTrust | ReferenceOnly |
|---|---|---|---:|---:|---:|---:|---:|---:|
| hepatitis | burden | none | 84.26 ± 3.23 | 85.53 ± 3.81 | 85.96 ± 2.43 | 84.26 ± 5.55 | 84.26 ± 5.34 | 81.28 ± 4.85 |
| hepatitis | burden | root_aligned | 82.55 ± 6.80 | 84.26 ± 4.90 | 77.87 ± 3.23 | 83.83 ± 5.75 | 77.02 ± 2.77 | 81.28 ± 4.85 |
| hepatitis | burden | signflip | 21.28 ± 5.63 | 82.13 ± 4.66 | 82.55 ± 4.09 | 78.30 ± 6.63 | 82.13 ± 5.34 | 81.28 ± 4.85 |
| hepatitis | random | none | 84.68 ± 4.61 | 83.83 ± 4.90 | 85.11 ± 4.26 | 82.98 ± 6.56 | 83.40 ± 4.61 | 81.28 ± 4.85 |
| hepatitis | random | root_aligned | 82.55 ± 3.50 | 84.26 ± 4.41 | 77.87 ± 2.85 | 82.98 ± 5.42 | 77.87 ± 2.85 | 81.28 ± 4.85 |
| hepatitis | random | signflip | 21.28 ± 5.63 | 84.68 ± 5.30 | 82.13 ± 3.56 | 80.43 ± 5.08 | 82.98 ± 4.76 | 81.28 ± 4.85 |
| mammographic_mass | burden | none | 78.61 ± 1.57 | 78.99 ± 1.11 | 79.77 ± 1.22 | 79.47 ± 1.19 | 79.52 ± 1.73 | 75.39 ± 2.72 |
| mammographic_mass | burden | root_aligned | 77.42 ± 1.49 | 79.05 ± 1.04 | 75.18 ± 3.54 | 78.84 ± 1.32 | 75.52 ± 3.08 | 75.39 ± 2.72 |
| mammographic_mass | burden | signflip | 49.41 ± 7.98 | 78.86 ± 1.73 | 78.90 ± 1.24 | 78.97 ± 1.93 | 78.79 ± 1.51 | 75.39 ± 2.72 |
| mammographic_mass | random | none | 79.48 ± 1.69 | 78.73 ± 1.42 | 79.32 ± 1.39 | 78.73 ± 1.62 | 79.51 ± 1.63 | 75.39 ± 2.72 |
| mammographic_mass | random | root_aligned | 77.00 ± 1.22 | 78.70 ± 2.10 | 75.88 ± 2.96 | 78.88 ± 2.32 | 75.59 ± 3.18 | 75.39 ± 2.72 |
| mammographic_mass | random | signflip | 49.41 ± 7.98 | 79.11 ± 1.86 | 78.92 ± 1.06 | 78.89 ± 2.20 | 78.79 ± 1.02 | 75.39 ± 2.72 |

## Balanced accuracy (%) — mean ± sample SD over five paired seeds

| Dataset | Partition | Attack | Mean | Median | FLTrust | MGT-Med | TransportFLTrust | ReferenceOnly |
|---|---|---|---:|---:|---:|---:|---:|---:|
| hepatitis | burden | none | 74.21 ± 6.02 | 77.56 ± 6.29 | 76.65 ± 7.79 | 75.10 ± 6.37 | 75.49 ± 9.53 | 70.75 ± 10.15 |
| hepatitis | burden | root_aligned | 75.16 ± 12.55 | 71.81 ± 6.32 | 65.22 ± 12.19 | 75.00 ± 5.75 | 63.20 ± 12.71 | 70.75 ± 10.15 |
| hepatitis | burden | signflip | 50.00 ± 0.00 | 68.01 ± 3.40 | 71.35 ± 8.74 | 65.26 ± 2.00 | 69.87 ± 10.28 | 70.75 ± 10.15 |
| hepatitis | random | none | 75.14 ± 6.70 | 72.52 ± 7.12 | 72.06 ± 12.29 | 72.49 ± 8.28 | 70.05 ± 9.68 | 70.75 ± 10.15 |
| hepatitis | random | root_aligned | 72.98 ± 7.65 | 70.86 ± 11.37 | 64.24 ± 12.05 | 70.75 ± 12.95 | 64.24 ± 12.05 | 70.75 ± 10.15 |
| hepatitis | random | signflip | 50.00 ± 0.00 | 69.19 ± 8.73 | 72.48 ± 6.84 | 66.09 ± 9.39 | 70.73 ± 9.33 | 70.75 ± 10.15 |
| mammographic_mass | burden | none | 78.57 ± 2.08 | 79.08 ± 1.45 | 80.20 ± 1.22 | 79.62 ± 1.42 | 79.85 ± 1.95 | 75.76 ± 2.95 |
| mammographic_mass | burden | root_aligned | 77.79 ± 1.77 | 79.31 ± 1.19 | 75.46 ± 3.54 | 79.20 ± 1.32 | 75.79 ± 3.06 | 75.76 ± 2.95 |
| mammographic_mass | burden | signflip | 50.00 ± 0.00 | 79.07 ± 1.59 | 79.34 ± 1.20 | 79.28 ± 1.78 | 79.23 ± 1.53 | 75.76 ± 2.95 |
| mammographic_mass | random | none | 79.33 ± 2.21 | 78.70 ± 1.81 | 79.64 ± 1.72 | 78.65 ± 2.00 | 79.89 ± 1.86 | 75.76 ± 2.95 |
| mammographic_mass | random | root_aligned | 77.34 ± 1.58 | 79.02 ± 2.11 | 75.97 ± 3.24 | 79.21 ± 2.26 | 75.79 ± 3.29 | 75.76 ± 2.95 |
| mammographic_mass | random | signflip | 50.00 ± 0.00 | 79.36 ± 1.88 | 79.39 ± 1.11 | 79.13 ± 2.06 | 79.26 ± 1.13 | 75.76 ± 2.95 |

## Cross entropy — mean ± sample SD over five paired seeds

| Dataset | Partition | Attack | Mean | Median | FLTrust | MGT-Med | TransportFLTrust | ReferenceOnly |
|---|---|---|---:|---:|---:|---:|---:|---:|
| hepatitis | burden | none | 0.532 ± 0.153 | 0.531 ± 0.250 | 0.546 ± 0.254 | 0.639 ± 0.344 | 0.464 ± 0.148 | 0.697 ± 0.216 |
| hepatitis | burden | root_aligned | 0.986 ± 0.319 | 0.481 ± 0.124 | 0.964 ± 0.433 | 0.544 ± 0.118 | 0.969 ± 0.441 | 0.697 ± 0.216 |
| hepatitis | burden | signflip | 58.708 ± 2.676 | 0.565 ± 0.117 | 0.660 ± 0.147 | 0.686 ± 0.190 | 0.582 ± 0.152 | 0.697 ± 0.216 |
| hepatitis | random | none | 0.532 ± 0.156 | 0.488 ± 0.205 | 0.635 ± 0.384 | 0.583 ± 0.288 | 0.494 ± 0.171 | 0.697 ± 0.216 |
| hepatitis | random | root_aligned | 1.326 ± 0.934 | 0.477 ± 0.173 | 0.882 ± 0.339 | 0.608 ± 0.282 | 0.882 ± 0.324 | 0.697 ± 0.216 |
| hepatitis | random | signflip | 59.586 ± 3.636 | 0.548 ± 0.236 | 0.646 ± 0.160 | 0.728 ± 0.365 | 0.488 ± 0.112 | 0.697 ± 0.216 |
| mammographic_mass | burden | none | 0.470 ± 0.028 | 0.470 ± 0.026 | 0.479 ± 0.023 | 0.470 ± 0.025 | 0.479 ± 0.023 | 0.568 ± 0.077 |
| mammographic_mass | burden | root_aligned | 0.538 ± 0.045 | 0.478 ± 0.016 | 0.597 ± 0.111 | 0.479 ± 0.015 | 0.586 ± 0.099 | 0.568 ± 0.077 |
| mammographic_mass | burden | signflip | 20.785 ± 4.169 | 0.487 ± 0.025 | 0.514 ± 0.044 | 0.487 ± 0.025 | 0.512 ± 0.040 | 0.568 ± 0.077 |
| mammographic_mass | random | none | 0.472 ± 0.029 | 0.473 ± 0.030 | 0.480 ± 0.022 | 0.472 ± 0.030 | 0.481 ± 0.022 | 0.568 ± 0.077 |
| mammographic_mass | random | root_aligned | 0.543 ± 0.045 | 0.481 ± 0.021 | 0.591 ± 0.103 | 0.481 ± 0.020 | 0.588 ± 0.100 | 0.568 ± 0.077 |
| mammographic_mass | random | signflip | 20.871 ± 3.412 | 0.486 ± 0.027 | 0.508 ± 0.045 | 0.485 ± 0.026 | 0.508 ± 0.044 | 0.568 ± 0.077 |

## Verification and files

- integrity.json: exactly 360 named fits, no duplicated run keys, all endpoint metrics and parameters finite; all 20 dataset/partition/seed ReferenceOnly controls are attack-invariant and all 10 dataset/seed controls also partition-invariant.
- data_audit.json: raw missing-value counts, masks unchanged, complete-core and row/group separation, target-profile recomputation, training-only product-mask approximation diagnostic. Three independently replayed runs reproduce exact final parameter hashes.
- gradient_check.json: original analytic MLP derivatives pass finite differences. environment.json and sources.json preserve code/environment/raw data provenance.
- author_methods.py follows the FLTrust authors' numerical stabilization (eps=1e-9) and returns a zero aggregate when total trust is zero. The CSV column fltrust_fallbacks is retained as a historical field name but now counts zero-score rounds; it does NOT mean root-gradient substitution. The original eps1e-15/root-fallback batch is fully preserved in legacy_rules/ and excluded from primary results. All 360 fits and root-cone candidate searches were rerun under the author numerical rule, for source fidelity rather than test performance. Primary implementation source: https://people.duke.edu/~zg70/code/fltrust.zip, nd_aggregation.py, audited 2026-10-29.
- natural_runs.csv: all 360 endpoints; natural_curves.csv: all evaluation curves at fixed checkpoints; models/: final parameter arrays; splits/: every row allocation, profile and scaler.
- protocol.json: frozen settings, inference limits and attack formula; run_natural.py: resumable complete runner; base_experiments.py and shared_methods.py: frozen model and attack/aggregation definitions.

Run `python download_data.py` only if raw archives are absent, then `python run_natural.py`, `python audit_natural.py`, `python make_report.py`. Existing named keys are resumed; use a new folder without existing endpoint CSVs for a full rerun. No dependencies are downloaded by the runner itself.
