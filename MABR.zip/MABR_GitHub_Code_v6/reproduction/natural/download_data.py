from pathlib import Path
import hashlib, json, urllib.request, zipfile, io

ROOT=Path(__file__).resolve().parent
RAW=ROOT/'raw'; RAW.mkdir(exist_ok=True)
SOURCES=[
    dict(dataset='mammographic_mass',uci_id=161,url='https://archive.ics.uci.edu/static/public/161/mammographic+mass.zip',
         page='https://archive.ics.uci.edu/dataset/161/mammographic+mass',doi='10.24432/C53K6Z',license='CC BY 4.0',
         citation='Elter, M. (2007). Mammographic Mass [Dataset]. UCI Machine Learning Repository.',
         exclusions='BI-RADS assessment excluded because original documentation calls it non-predictive; use age, shape, margin, density only.'),
    dict(dataset='hepatitis',uci_id=46,url='https://archive.ics.uci.edu/static/public/46/hepatitis.zip',
         page='https://archive.ics.uci.edu/dataset/46/hepatitis',doi='10.24432/C5Q59J',license='CC BY 4.0',
         citation='Hepatitis [Dataset]. (1983). UCI Machine Learning Repository.',
         exclusions='Class is the outcome and excluded from features. No identifiers in the 19 documented covariates.')
]
for source in SOURCES:
    dest=RAW/(source['dataset']+'.zip')
    if not dest.exists():
        req=urllib.request.Request(source['url'],headers={'User-Agent':'Scientific reproducibility study/1.0'})
        with urllib.request.urlopen(req,timeout=60) as response: dest.write_bytes(response.read())
    source['archive_sha256']=hashlib.sha256(dest.read_bytes()).hexdigest()
    out=RAW/source['dataset']; out.mkdir(exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(dest.read_bytes())) as z:
        for name in z.namelist():
            if not name.endswith('/'):
                # Flatten distributed files; no execution of downloaded content.
                (out/Path(name).name).write_bytes(z.read(name))
    source['files']=[dict(file=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(out.iterdir()) if p.is_file()]
    source['access_date']='2026-10-29'
    source['primary_metadata_verified']=True
(ROOT/'sources.json').write_text(json.dumps(SOURCES,indent=2),encoding='utf-8')
print(json.dumps(SOURCES,indent=2))
