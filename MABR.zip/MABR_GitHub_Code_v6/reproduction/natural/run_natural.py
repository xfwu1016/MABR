"""Natural missingness with simulated federation; protocol frozen before fits.

The raw '?' entries and all observed values are retained. Only reference-core
Monte Carlo masks are synthetic. This does not identify the natural mechanism.
"""
import os
for name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[name]='1'
from pathlib import Path
import argparse, csv, hashlib, json, platform, sys, time
import numpy as np
import scipy, sklearn
from sklearn.model_selection import GroupShuffleSplit, train_test_split
from sklearn.preprocessing import StandardScaler
from scipy.stats import t as tdist
from base_experiments import MLP, gradient_check
from author_methods import fltrust_update, root_cone_attack, predict_metrics

ROOT=Path(__file__).resolve().parent
CFG=json.loads((ROOT/'protocol.json').read_text(encoding='utf-8'))
METRICS=['test_accuracy','test_balanced_accuracy','test_ce','incomplete_accuracy']

def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def load_data(dataset):
    if dataset=='mammographic_mass':
        arr=np.genfromtxt(ROOT/'raw/mammographic_mass/mammographic_masses.data',delimiter=',',missing_values='?',filling_values=np.nan)
        x=arr[:,1:5]; y=arr[:,5].astype(int)
        assert arr.shape==(961,6)
    else:
        arr=np.genfromtxt(ROOT/'raw/hepatitis/hepatitis.data',delimiter=',',missing_values='?',filling_values=np.nan)
        x=arr[:,1:];y=arr[:,0].astype(int)-1
        assert arr.shape==(155,20)
    assert np.isfinite(y).all() and set(y)=={0,1}
    m=np.isfinite(x)
    return x,y,m

def encode(dataset,x,m):
    if dataset=='mammographic_mass':
        # Fixed documented levels: no fitting categories to the test set.
        assert set(x[np.isfinite(x[:,1]),1]).issubset({1,2,3,4})
        assert set(x[np.isfinite(x[:,2]),2]).issubset({1,2,3,4,5})
        xx=np.column_stack([x[:,0],*[x[:,1]==k for k in range(1,5)],*[x[:,2]==k for k in range(1,6)],x[:,3]])
        group=np.array([0]+[1]*4+[2]*5+[3])
    else:
        xx=x.copy();group=np.arange(x.shape[1])
    return xx,m[:,group],group

def prepare(dataset,seed,partition):
    raw,y,m=load_data(dataset)
    # Group only observed predictor representations, not outcomes or test metrics.
    _,groups=np.unique(np.nan_to_num(raw,nan=-999999.),axis=0,return_inverse=True)
    train,test=next(GroupShuffleSplit(n_splits=1,test_size=.3,random_state=100+seed).split(raw,y,groups))
    assert set(groups[train]).isdisjoint(set(groups[test]))
    complete=train[m[train].all(axis=1)]
    nr=CFG['datasets'][dataset]['reference_size']
    _,ref=train_test_split(complete,test_size=nr,stratify=y[complete],random_state=200+seed)
    private=train[~np.isin(train,ref)]
    assert set(private).isdisjoint(ref) and set(train).isdisjoint(test)
    assert m[ref].all() and len(ref)==nr
    xx,mm,group=encode(dataset,raw,m)
    scaler=StandardScaler().fit(xx[ref])
    x=np.nan_to_num(scaler.transform(xx),nan=0.)
    assert np.isfinite(x).all()
    rng=np.random.default_rng(300+seed)
    order=rng.permutation(private)
    if partition=='burden':
        k=int(.2*len(order));tail=order[k:]
        tail=tail[np.argsort((~m[tail]).sum(axis=1),kind='stable')]
        order=np.r_[order[:k],tail]
    ids=list(np.array_split(order,CFG['n_clients']))
    if partition=='burden': ids=[ids[j] for j in rng.permutation(CFG['n_clients'])]
    profiles=np.stack([(m[ii].sum(axis=0)+1)/(len(ii)+2) for ii in ids])
    target=(m[private].sum(axis=0)+1)/(len(private)+2)
    allp=np.vstack([target,profiles])
    unique,ix=np.unique(allp,axis=0,return_inverse=True)
    assert np.all((unique>0)&(unique<1))
    clients=[(x[ii],y[ii],mm[ii]) for ii in ids]
    metadata=dict(dataset=dataset,seed=seed,partition=partition,n_total=len(y),n_train=len(train),n_reference=nr,n_private=len(private),n_test=len(test),
                  original_variables=raw.shape[1],encoded_features=x.shape[1],n_complete_total=int(m.all(axis=1).sum()),n_complete_train=len(complete),
                  natural_missing_entries=int((~m).sum()),natural_missing_fraction=float((~m).mean()),
                  incomplete_test_cases=int((~m[test]).any(axis=1).sum()),test_class_counts=np.bincount(y[test],minlength=2).tolist(),
                  n_unique_predictor_representations=int(groups.max()+1),train_test_predictor_groups_disjoint=True,
                  reference_missing_fraction=0.,private_missing_fraction=float((~m[private]).mean()),test_missing_fraction=float((~m[test]).mean()),
                  reference_class_counts=np.bincount(y[ref],minlength=2).tolist(),private_class_counts=np.bincount(y[private],minlength=2).tolist(),
                  private_client_sizes=[len(ii) for ii in ids],private_client_class_counts=[np.bincount(y[ii],minlength=2).tolist() for ii in ids],
                  private_client_observation_probabilities=profiles.tolist(),target_observation_probabilities=target.tolist(),
                  n_distinct_client_profiles=int(len(np.unique(profiles,axis=0))),n_required_transport_anchor_profiles=len(unique),
                  row_ids=dict(train=train.tolist(),reference=ref.tolist(),private=private.tolist(),test=test.tolist(),clients=[ii.tolist() for ii in ids]),
                  scaler_mean=scaler.mean_.tolist(),scaler_scale=scaler.scale_.tolist(),encoded_to_original_variable=group.tolist())
    return clients,(x[ref],y[ref]),(x[test],y[test],mm[test]),(unique,ix,group),metadata

def evaluate(net,theta,test):
    x,y,m=test
    metrics=predict_metrics(net,theta,x,y,[m])
    inc=(~m).any(axis=1)
    metrics['incomplete_accuracy']=net.loss_grad(theta,x[inc],y[inc],m[inc],False)[1] if np.any(inc) else float('nan')
    return metrics

def run(dataset,seed,partition,attack,method,rounds=None):
    clients,ref,test,pinfo,meta=prepare(dataset,seed,partition)
    unique,ix,group=pinfo
    n=CFG['n_clients']; f=CFG['n_byzantine'];honest=n if attack=='none' else n-f
    net=MLP(meta['encoded_features'],2,CFG['hidden'])
    theta=net.initialize(np.random.default_rng(500+seed))
    rng=np.random.default_rng(600+seed)
    R=rounds or CFG['rounds']; curves=[];fallbacks=0;bad_shares=[];honest_cos=[];cones=[];rawdisp=[];corrdisp=[]
    start=time.perf_counter()
    for step in range(R):
        rid=rng.integers(0,len(ref[1]),CFG['reference_batch'])
        rx,ry=ref[0][rid],ref[1][rid]
        U=rng.random((len(rid),meta['original_variables']))
        # One uniform per original variable: all indicators in a one-hot group
        # share their natural observation event and their reference mask event.
        anchors=np.stack([net.loss_grad(theta,rx,ry,(U<q)[:,group])[1] for q in unique])
        a=anchors[ix[0]]; D=anchors[ix[1:]]-a
        G=[]
        for x,y,m in clients:
            jj=rng.integers(0,len(y),CFG['private_batch'])
            G.append(net.loss_grad(theta,x[jj],y[jj],m[jj])[1])
        G=np.stack(G)
        if attack=='signflip': G[honest:]=-5*G[:honest].mean(axis=0)
        elif attack=='root_aligned':
            G[honest:],attackmeta=root_cone_attack(G[:honest],a,(G[:honest]-D[:honest]).mean(axis=0),f=f,scale=5.)
            cones.append(attackmeta['cosine'])
        corrected=G-D
        rawdisp.append(np.mean(np.sum((G[:honest]-G[:honest].mean(axis=0))**2,axis=1)))
        corrdisp.append(np.mean(np.sum((corrected[:honest]-corrected[:honest].mean(axis=0))**2,axis=1)))
        use=corrected if method in ('MGT-Med','TransportFLTrust') else G
        extra={}
        if method in ('FLTrust','TransportFLTrust'):
            update,extra=fltrust_update(use,a)
            fallbacks+=extra['fallback']
            total=extra['scores'].sum()
            bad_shares.append(float(extra['scores'][honest:].sum()/total) if total>1e-15 and attack!='none' else 0.)
            hn=np.linalg.norm(use[:honest],axis=1);an=np.linalg.norm(a)
            honest_cos.append(float(np.mean((use[:honest]@a)/(np.maximum(hn,1e-15)*max(an,1e-15)))))
        elif method=='ReferenceOnly':update=a
        elif method in ('Median','MGT-Med'):update=np.median(use,axis=0)
        else:update=use.mean(axis=0)
        theta-=CFG['learning_rate']*update
        assert np.isfinite(theta).all(),(dataset,seed,partition,attack,method,step)
        if (step+1)%10==0 or step==R-1:
            curves.append(dict(dataset=dataset,seed=seed,partition=partition,attack=attack,method=method,round=step+1,**evaluate(net,theta,test)))
    wall=time.perf_counter()-start
    transport=method in ('MGT-Med','TransportFLTrust')
    sg=len(unique) if transport else 1 if method in ('FLTrust','ReferenceOnly') else 0
    row=dict(dataset=dataset,seed=seed,partition=partition,attack=attack,method=method,rounds=R,**evaluate(net,theta,test),
             n_private=meta['n_private'],n_reference=meta['n_reference'],n_test=meta['n_test'],incomplete_test_cases=meta['incomplete_test_cases'],
             parameter_dim=net.dim,parameter_norm=float(np.linalg.norm(theta)),parameter_sha256=hashlib.sha256(theta.tobytes()).hexdigest(),
             raw_dispersion=float(np.mean(rawdisp)),corrected_dispersion=float(np.mean(corrdisp)),
             fltrust_bad_weight_share=float(np.mean(bad_shares)) if bad_shares else float('nan'),
             fltrust_honest_mean_cosine=float(np.mean(honest_cos)) if honest_cos else float('nan'),fltrust_fallbacks=fallbacks,
             root_cone_mean_cosine=float(np.mean(cones)) if cones else float('nan'),wall_seconds=wall,
             required_server_gradient_evals=sg*R,required_server_gradient_evals_per_round=sg,
             n_distinct_client_profiles=meta['n_distinct_client_profiles'],reference_batch=CFG['reference_batch'],
             diagnostic_server_gradient_evals=len(unique)*R,
             required_private_gradient_evals=0 if method=='ReferenceOnly' else n*R,
             uplink_float64_values=0 if method=='ReferenceOnly' else n*net.dim*R,
             downlink_float64_values=0 if method=='ReferenceOnly' else n*net.dim*R)
    return row,curves,meta,theta

def append(path,rows):
    if not rows:return
    exists=path.exists()
    with path.open('a',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]))
        if not exists:w.writeheader()
        w.writerows(rows)

def summarize():
    import pandas as pd
    df=pd.read_csv(ROOT/'natural_runs.csv')
    keys=['dataset','partition','attack','method']
    summary=df.groupby(keys)[METRICS].agg(['mean','std','count'])
    summary.columns=['_'.join(c) for c in summary.columns]
    summary.reset_index().to_csv(ROOT/'natural_summary.csv',index=False)
    pairs=[]
    for key,g in df.groupby(['dataset','partition','attack']):
        for method in ['MGT-Med','TransportFLTrust','Median','ReferenceOnly']:
            left=g[g.method==method].set_index('seed');right=g[g.method=='FLTrust'].set_index('seed')
            for metric in METRICS:
                diff=left[metric]-right[metric];mean=float(diff.mean());sd=float(diff.std(ddof=1));n=len(diff)
                half=float(tdist.ppf(.975,n-1)*sd/np.sqrt(n))
                pairs.append(dict(dataset=key[0],partition=key[1],attack=key[2],method=method,comparator='FLTrust',metric=metric,
                                  mean_difference=mean,sd_difference=sd,n=n,descriptive_t95_low=mean-half,descriptive_t95_high=mean+half,
                                  **{'seed'+str(k)+'_difference':float(v) for k,v in diff.items()}))
    pd.DataFrame(pairs).to_csv(ROOT/'paired_differences_vs_fltrust.csv',index=False)
    controls=[]
    for key,g in df[df.method=='ReferenceOnly'].groupby(['dataset','partition','seed']):
        controls.append(dict(dataset=key[0],partition=key[1],seed=int(key[2]),attack_invariant=bool(g.parameter_sha256.nunique()==1)))
    assert all(c['attack_invariant'] for c in controls)
    out=dict(expected_fits=360,actual_fits=len(df),all_results_finite=bool(np.isfinite(df[['test_ce','test_accuracy','test_balanced_accuracy','incomplete_accuracy','parameter_norm']]).all().all()),
             reference_only_attack_invariance=controls,
             per_round_transport_server_gradient_evals=sorted(df[df.method=='MGT-Med'].required_server_gradient_evals_per_round.unique().astype(int).tolist()),
             duplicate_keys=int(df.duplicated(['dataset','partition','seed','attack','method']).sum()),
             caution='Rows share datasets and paired seeds; cells and fits are not independent population replications. Timing includes common diagnostics and is not a fair algorithm-speed comparison.')
    assert out['actual_fits']==out['expected_fits'] and out['all_results_finite'] and out['duplicate_keys']==0
    (ROOT/'integrity.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2))

def main():
    p=argparse.ArgumentParser();p.add_argument('--summarize',action='store_true');p.add_argument('--pilot',action='store_true');args=p.parse_args()
    if args.summarize:summarize();return
    (ROOT/'gradient_check.json').write_text(json.dumps(gradient_check(),indent=2))
    (ROOT/'environment.json').write_text(json.dumps(dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__,platform=platform.platform(),threads=1,
           runner_sha256=digest(__file__),base_experiments_sha256=digest(ROOT/'base_experiments.py'),shared_methods_sha256=digest(ROOT/'shared_methods.py'),author_methods_sha256=digest(ROOT/'author_methods.py'),protocol_sha256=digest(ROOT/'protocol.json')),indent=2))
    output=ROOT/('pilot_runs.csv' if args.pilot else 'natural_runs.csv')
    curve=ROOT/('pilot_curves.csv' if args.pilot else 'natural_curves.csv')
    done=set()
    if output.exists():
        with output.open() as f:done={(r['dataset'],r['partition'],int(r['seed']),r['attack'],r['method']) for r in csv.DictReader(f)}
    jobs=[(d,p,s,a,m) for d in CFG['datasets'] for p in CFG['partitions'] for s in CFG['seeds'] for a in CFG['attacks'] for m in CFG['methods']]
    if args.pilot:jobs=[('mammographic_mass','random',0,'none','FLTrust')]
    jobs=[x for x in jobs if x not in done]
    models=ROOT/'models';models.mkdir(exist_ok=True)
    splits=ROOT/'splits';splits.mkdir(exist_ok=True)
    for k,(d,p,s,a,m) in enumerate(jobs,1):
        row,cs,meta,theta=run(d,s,p,a,m,rounds=10 if args.pilot else None)
        append(output,[row]);append(curve,cs)
        (splits/f'{d}_{p}_seed{s}.json').write_text(json.dumps(meta,indent=2))
        np.save(models/f'{d}_{p}_seed{s}_{a}_{m}.npy',theta)
        print(f'{k}/{len(jobs)} {d} {p} seed{s} {a} {m}: acc={row["test_accuracy"]:.4f}, BA={row["test_balanced_accuracy"]:.4f}, CE={row["test_ce"]:.4f}, sec={row["wall_seconds"]:.2f}',flush=True)
    if not args.pilot:summarize()

if __name__=='__main__':main()
