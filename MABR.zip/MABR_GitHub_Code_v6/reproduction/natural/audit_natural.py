"""Input and protocol checks; no adaptation of the frozen training choices."""
from pathlib import Path
import json,hashlib
import numpy as np
from run_natural import ROOT,CFG,load_data,prepare,encode,run

records=[]
for dataset in CFG['datasets']:
    x,y,m=load_data(dataset)
    masks,counts=np.unique(m,axis=0,return_counts=True)
    total=dict(dataset=dataset,n_rows=len(y),original_features=x.shape[1],missing_entries=int((~m).sum()),
               missing_by_feature=(~m).sum(axis=0).tolist(),missing_fraction=float((~m).mean()),
               incomplete_rows=int((~m).any(axis=1).sum()),complete_rows=int(m.all(axis=1).sum()),
               class_counts=np.bincount(y,minlength=2).tolist(),distinct_mask_patterns=len(masks),
               mask_pattern_counts=[dict(pattern=''.join('1' if b else '0' for b in pattern),n=int(n)) for pattern,n in zip(masks,counts)])
    splits=[]
    for partition in CFG['partitions']:
        for seed in CFG['seeds']:
            clients,ref,test,(profiles,ix,group),meta=prepare(dataset,seed,partition)
            ids=meta['row_ids'];private=np.array(ids['private']);ri=np.array(ids['reference']);ti=np.array(ids['test'])
            assert set(private).isdisjoint(ri) and set(ri).isdisjoint(ti) and set(private).isdisjoint(ti)
            flat=np.concatenate([np.array(q) for q in ids['clients']]); assert set(flat)==set(private) and len(flat)==len(private)
            assert np.isfinite(ref[0]).all() and np.isfinite(test[0]).all()
            assert np.array_equal(test[2],m[ti][:,group])
            for ii,(_,_,mm) in zip(ids['clients'],clients): assert np.array_equal(mm,m[ii][:,group])
            q=(m[private].sum(axis=0)+1)/(len(private)+2)
            assert np.array_equal(q,np.asarray(meta['target_observation_probabilities']))
            # Compare the training mask-pattern empirical distribution with its
            # independent product approximation. This is a finite-sample
            # descriptive diagnostic, not an MCAR test or a population TV estimate.
            pat,ct=np.unique(m[private],axis=0,return_counts=True)
            prob=np.prod(np.where(pat,q,1-q),axis=1)
            tv=.5*(np.abs(ct/ct.sum()-prob).sum()+1-prob.sum())
            splits.append(dict(partition=partition,seed=seed,n_private=len(private),n_reference=len(ri),n_test=len(ti),
                               incomplete_test_cases=meta['incomplete_test_cases'],
                               observed_mask_pattern_tv_to_product=float(tv),
                               natural_private_and_test_masks_exactly_preserved=True,
                               all_row_allocations_disjoint=True,predictor_groups_disjoint=True,
                               per_round_transport_reference_gradient_evals=len(profiles),
                               required_client_profile_coordinates=meta['original_variables'],
                               complete_reference=True))
    records.append({**total,'split_checks':splits})

replays=[]
csvfile=ROOT/'natural_runs.csv'
if csvfile.exists():
    import pandas as pd
    df=pd.read_csv(csvfile)
    for dataset,part,seed,attack,method in [
        ('mammographic_mass','random',0,'signflip','MGT-Med'),
        ('mammographic_mass','burden',1,'root_aligned','TransportFLTrust'),
        ('hepatitis','random',0,'none','FLTrust')]:
        saved=df[(df.dataset==dataset)&(df.partition==part)&(df.seed==seed)&(df.attack==attack)&(df.method==method)]
        if len(saved):
            row,_,_,_=run(dataset,seed,part,attack,method)
            matched=row['parameter_sha256']==saved.iloc[0].parameter_sha256
            assert matched
            replays.append(dict(dataset=dataset,partition=part,seed=seed,attack=attack,method=method,exact_parameter_hash_match=matched))

out=dict(datasets=records,replay_checks=replays,
         files_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'protocol.json',ROOT/'run_natural.py',ROOT/'base_experiments.py',ROOT/'shared_methods.py',ROOT/'author_methods.py']},
         note='All checks assess implementation and finite data provenance. Natural mask dependence, clinical timing and complete-case representativeness are not validated.')
(ROOT/'data_audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({r['dataset']:{k:r[k] for k in ['n_rows','original_features','missing_entries','missing_fraction','complete_rows','distinct_mask_patterns']} for r in records},indent=2))
print('Exact-hash replays',len(replays))
