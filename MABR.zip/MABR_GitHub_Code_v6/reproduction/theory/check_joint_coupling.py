"""Exact finite-law and Monte Carlo checks; not a substitute for proof."""
from pathlib import Path
import json
import numpy as np

rng = np.random.default_rng(2792026)
ROOT = Path(__file__).resolve().parent

def mass_matrix(client, target):
    overlap = np.minimum(client, target)
    c = float(overlap.sum())
    if c >= 1 - 1e-14:
        return np.diag(target), 0.
    residual_client = client - overlap
    residual_target = target - overlap
    joint = np.diag(overlap) + np.outer(residual_target, residual_client) / (1 - c)
    return joint, 1 - c

cases = 0
row_error = col_error = tv_error = 0.
for _ in range(6000):
    s = int(rng.integers(2, 65))
    client, target = rng.dirichlet(np.ones(s), size=2)
    if rng.random() < .3:
        client[rng.choice(s, max(1, s // 3), replace=False)] = 0
        client /= client.sum()
    if rng.random() < .3:
        target[rng.choice(s, max(1, s // 3), replace=False)] = 0
        target /= target.sum()
    joint, tau = mass_matrix(client, target)
    row_error = max(row_error, float(np.abs(joint.sum(axis=1) - target).max()))
    col_error = max(col_error, float(np.abs(joint.sum(axis=0) - client).max()))
    tv_error = max(tv_error, abs(tau - .5 * np.abs(client - target).sum()), abs(tau - (joint.sum() - np.trace(joint))))
    assert np.all(joint >= -1e-14)
    assert np.allclose(joint.sum(axis=1), target, atol=1e-12)
    assert np.allclose(joint.sum(axis=0), client, atol=1e-12)
    assert np.isclose(tau, .5 * np.abs(client - target).sum(), atol=1e-12)
    assert np.isclose(tau, joint.sum() - np.trace(joint), atol=1e-12)
    # Paired-gradient envelope and variance calculation at fixed theta.
    h = rng.uniform(-1, 1, size=(s, 5))
    diffs = h[None, :, :] - h[:, None, :]
    means = np.einsum('ab,abj->j', joint, diffs)
    moment2 = np.einsum('ab,abj->j', joint, diffs ** 2)
    assert np.allclose(means, (client - target) @ h, atol=1e-12)
    assert np.abs(means).max() <= 2 * tau + 1e-12
    assert moment2.max() <= 4 * tau + 1e-12
    cases += 1

identical = np.array([0., .2, .5, .3])
ident_joint, ident_tau = mass_matrix(identical, identical)
assert ident_tau == 0. and np.array_equal(ident_joint, np.diag(identical))
disjoint_i = np.array([0., .3, 0., .7])
disjoint_t = np.array([.2, 0., .8, 0.])
disjoint_joint, disjoint_tau = mass_matrix(disjoint_i, disjoint_t)
assert disjoint_tau == 1. and np.allclose(disjoint_joint, np.outer(disjoint_t, disjoint_i))

# Actual keep/reject sampler with shared target for three clients.
target = np.array([.05, .15, .25, .30, .25])
clients = np.array([[.30, .10, .20, .10, .30], [.05, .15, .25, .30, .25], [0., .20, .20, .50, .10]])
n = 250000
draw_target = rng.choice(len(target), n, p=target)
summaries = []
for client in clients:
    overlap = np.minimum(client, target)
    c = overlap.sum()
    if c >= 1 - 1e-14:
        draw_client = draw_target.copy()
    else:
        keep = rng.random(n) < overlap[draw_target] / target[draw_target]
        draw_client = draw_target.copy()
        residual = (client - overlap) / (1 - c)
        draw_client[~keep] = rng.choice(len(target), int((~keep).sum()), p=residual)
    observed = np.bincount(draw_client, minlength=len(target)) / n
    mismatch = float(np.mean(draw_client != draw_target))
    tv = float(.5 * np.abs(client - target).sum())
    assert np.abs(observed - client).max() < .005
    assert abs(mismatch - tv) < .005
    summaries.append({'expected_client_marginal': client.tolist(), 'sample_client_marginal': observed.tolist(), 'expected_mismatch_tv': tv, 'sample_mismatch': mismatch})

result = {
    'seed': 2792026,
    'exact_finite_law_cases': cases,
    'max_target_marginal_abs_error': row_error,
    'max_client_marginal_abs_error': col_error,
    'max_mismatch_tv_abs_error': tv_error,
    'paired_gradient_envelope_and_second_moment_cases': cases,
    'identical_law_exact_zero_checked': True,
    'disjoint_law_checked': True,
    'zero_target_mass_patterns_checked': True,
    'shared_target_sampler_pairs_per_client': n,
    'sampler_checks': summaries,
    'interpretation': 'Finite numerical checks corroborate the supplied proof, but do not establish population sampling or missingness-identification assumptions.'
}
(ROOT / 'joint_coupling_checks.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k != 'sampler_checks'}, indent=2))
