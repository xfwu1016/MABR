"""Numerical sanity checks for new theory; not proof certification."""
from pathlib import Path
import itertools
import json
import math
import numpy as np

ROOT = Path(__file__).resolve().parent
rng = np.random.default_rng(7342026)

def ft(z, a):
    norms = np.linalg.norm(z, axis=1)
    an = np.linalg.norm(a)
    s = np.maximum(0., (z @ a) / np.maximum(norms * an, 1e-300))
    if s.sum() == 0:
        return np.zeros_like(a), s, True
    return an * np.sum(s[:, None] * z / np.maximum(norms[:, None], 1e-300), axis=0) / s.sum(), s, False

def rand_ball(d, radius):
    z = rng.normal(size=d)
    return z / np.linalg.norm(z) * radius * rng.random() ** (1 / d)

exact_count = 0
max_inner_identity_error = 0.
max_norm_violation = 0.
for _ in range(4000):
    d = int(rng.integers(2, 20)); n = int(rng.integers(3, 20))
    a = rng.normal(size=d)
    z = rng.normal(size=(n, d)) * np.exp(rng.normal(size=(n, 1)))
    if rng.random() < .2: z[0] = 0
    v, s, fallback = ft(z, a)
    if fallback: continue
    exact_count += 1
    lhs = float(a @ v)
    rhs = float((a @ a) * (s @ s) / s.sum())
    max_inner_identity_error = max(max_inner_identity_error, abs(lhs - rhs))
    max_norm_violation = max(max_norm_violation, float(np.linalg.norm(v) - np.linalg.norm(a)))
    assert lhs > 0 and np.linalg.norm(v) <= np.linalg.norm(a) + 1e-10
    assert np.isclose(lhs, rhs, rtol=1e-12, atol=1e-11)

score_cases = 0
max_score_violation = 0.
max_ft_bound_violation = 0.
for _ in range(5000):
    d = int(rng.integers(2, 15)); n = 11; f = 2; h = n - f
    g = rng.normal(size=d); gn = np.linalg.norm(g)
    e = float(rng.uniform(.001, .28) * gn)
    e0 = float(rng.uniform(.001, .28) * gn)
    a = g + rand_ball(d, e0)
    z = np.stack([g + rand_ball(d, e) for _ in range(h)] + [rng.normal(size=d) * 10 for _ in range(f)])
    v, s, fallback = ft(z, a)
    sm = 1 - 2 * (e + e0) ** 2 / gn ** 2
    assert sm > 0 and not fallback
    beta = float(s[h:].sum() / s.sum())
    bm = f / (f + h * sm)
    bound = (1 - beta) * (2 * e + e0) + beta * (2 * gn + e0)
    max_score_violation = max(max_score_violation, float(sm - s[:h].min()))
    max_ft_bound_violation = max(max_ft_bound_violation, float(np.linalg.norm(v - g) - bound))
    assert s[:h].min() >= sm - 1e-12 and beta <= bm + 1e-12
    assert np.linalg.norm(v - g) <= bound + 1e-11
    score_cases += 1

example_g = np.array([1., 0.])
example_z = np.array([[1., 0.]] * 9 + [[.5, math.sqrt(3) / 2]] * 2)
example_v, example_s, _ = ft(example_z, example_g)
assert np.allclose(example_v, [.95, math.sqrt(3) / 20])
assert np.isclose(np.linalg.norm(example_v - example_g), .1)
assert np.array_equal(np.median(example_z, axis=0), example_g)

# Errors below ||g|| alone do not ensure S>0: this boundary case must not
# be included in the positive-score proposition without s_min>0.
fallback_v, fallback_scores, is_fallback = ft(np.array([[.36, -.48]] * 9), np.array([.36, .48]))
assert is_fallback and np.all(fallback_scores == 0)
assert np.array_equal(fallback_v, np.zeros(2))
assert np.isclose(np.linalg.norm(np.array([.36, .48]) - example_g), .8)

# Equal marginals do not determine nonlinear/interaction gradient means.
two_masks = np.array([[0, 0], [0, 1], [1, 0], [1, 1]], dtype=float)
correlated_mass = np.array([.5, 0., 0., .5])
product_mass = np.ones(4) / 4
toy_gradient = (two_masks[:, 0] - 1)[:, None] * two_masks
correlated_gradient = correlated_mass @ toy_gradient
product_gradient = product_mass @ toy_gradient
assert np.array_equal(correlated_mass @ two_masks, product_mass @ two_masks)
assert np.array_equal(correlated_gradient, [0., 0.])
assert np.array_equal(product_gradient, [0., -.25])

kernel_checks = 0
max_kernel_identity_error = 0.
max_tv_violation = 0.
for _ in range(5000):
    n_z, n_m, d = 7, 8, 5
    p0, pi = rng.dirichlet(np.ones(n_z), size=2)
    ki, ks = rng.dirichlet(np.ones(n_m), size=(2, n_z))
    qi, qs = rng.dirichlet(np.ones(n_m), size=2)
    hvals = rng.uniform(-1., 1., size=(n_z, n_m, d))
    mu = lambda p, k: np.einsum('z,zm,zmd->d', p, np.broadcast_to(k, (n_z, n_m)), hvals)
    xi = rng.normal(size=d)
    khat = rng.normal(size=d)
    d0 = mu(p0, qi) - mu(p0, qs)
    client_report = mu(pi, ki) + xi
    estimate = d0 - khat
    u = client_report - estimate
    delta = mu(pi, ki) - mu(p0, ki)
    gamma_i = mu(p0, ki) - mu(p0, qi)
    gamma_star = mu(p0, qs) - mu(p0, ks)
    residual = u - mu(p0, ks) - (xi + delta + gamma_i + gamma_star + khat)
    max_kernel_identity_error = max(max_kernel_identity_error, float(np.abs(residual).max()))
    bound_i = float(np.einsum('z,zm->', p0, np.abs(ki - qi)))
    bound_s = float(np.einsum('z,zm->', p0, np.abs(ks - qs)))
    max_tv_violation = max(max_tv_violation, float(np.max(np.abs(gamma_i)) - bound_i), float(np.max(np.abs(gamma_star)) - bound_s))
    assert np.abs(residual).max() < 1e-12
    assert np.abs(gamma_i).max() <= bound_i + 1e-12 and np.abs(gamma_star).max() <= bound_s + 1e-12
    kernel_checks += 1

# Check the mask-integrated envelope and Lipschitz constants on an actual
# gradient family: h_theta(z,m) = H(z,m) theta + b(z,m), where H is symmetric.
p, d, nz, R = 3, 4, 6, 2.
masks = np.array(list(itertools.product([0, 1], repeat=p)), dtype=float)
hh = rng.normal(size=(nz, len(masks), d, d))
hh = .5 * (hh + hh.transpose(0, 1, 3, 2))
bb = rng.normal(size=(nz, len(masks), d))
lh = float(np.linalg.norm(hh, axis=-1).max())
G = float((R * np.linalg.norm(hh, axis=-1) + np.abs(bb)).max())
integrated_checks = 0
max_envelope_violation = 0.
max_lipschitz_violation = 0.
max_ref_tv_violation = 0.
for _ in range(4000):
    q, qs = rng.uniform(.01, .99, size=(2, p))
    pr = lambda q: np.prod(q ** masks * (1 - q) ** (1 - masks), axis=1)
    dp = pr(q) - pr(qs)
    r = float(1 - np.prod(1 - np.abs(q - qs)))
    theta, theta2 = rand_ball(d, R), rand_ball(d, R)
    h = np.einsum('zmij,j->zmi', hh, theta) + bb
    h2 = np.einsum('zmij,j->zmi', hh, theta2) + bb
    fun = np.einsum('m,zmd->zd', dp, h)
    fun2 = np.einsum('m,zmd->zd', dp, h2)
    eb = 2 * G * r
    lb = 2 * lh * r * np.linalg.norm(theta - theta2)
    max_envelope_violation = max(max_envelope_violation, float(np.abs(fun).max() - eb))
    max_lipschitz_violation = max(max_lipschitz_violation, float(np.abs(fun - fun2).max() - lb))
    assert np.abs(fun).max() <= eb + 1e-12
    assert np.abs(fun - fun2).max() <= lb + 1e-12
    p0, pref = rng.dirichlet(np.ones(nz), size=2)
    diff = (p0 - pref) @ fun
    ref_bound = 2 * G * r * np.abs(p0 - pref).sum()
    max_ref_tv_violation = max(max_ref_tv_violation, float(np.abs(diff).max() - ref_bound))
    assert np.abs(diff).max() <= ref_bound + 1e-12
    integrated_checks += 1

# Illustrative dimension scaling, not calibrated network constants. R=G=L_h=1,
# epsilon=R/N and r=1; compare to deterministic 4G envelope.
dimension_scaling = []
for d in (3346, 1514):
    for N in (64, 128, 2048, 8192, 1000000):
        K, delta, R, G, L = 3, .05, 1., 1., 1.
        eps = R / N
        a = math.log(2 * K * d / delta) + d * math.log1p(2 * R / eps)
        stochastic = G * math.sqrt(8 * a / N) + 4 * L * eps
        dimension_scaling.append(dict(d=d, N0=N, normalized_unclipped_bound=stochastic, normalized_bound=min(4., stochastic)))

results = {
    'purpose': 'Numerical sanity checks complement but do not replace the supplied mathematical proofs.',
    'seed': 7342026,
    'exact_root_geometry_cases': exact_count,
    'max_exact_root_identity_abs_error': max_inner_identity_error,
    'max_exact_root_norm_violation': max_norm_violation,
    'perturbed_root_report_cases': score_cases,
    'max_score_lower_bound_violation': max_score_violation,
    'max_fltrust_error_bound_violation': max_ft_bound_violation,
    'kernel_identity_tv_cases': kernel_checks,
    'max_kernel_identity_abs_error': max_kernel_identity_error,
    'max_kernel_tv_bound_violation': max_tv_violation,
    'mask_integrated_envelope_lipschitz_cases': integrated_checks,
    'max_integrated_envelope_violation': max_envelope_violation,
    'max_integrated_lipschitz_violation': max_lipschitz_violation,
    'max_reference_population_tv_violation': max_ref_tv_violation,
    'fltrust_example': {'aggregate': example_v.tolist(), 'error_norm': float(np.linalg.norm(example_v - example_g)), 'median_exact': True, 'reference_only_also_exact': True},
    'zero_score_fallback_case_checked': True,
    'correlated_mask_same_marginals_example': {'marginals': (correlated_mass @ two_masks).tolist(), 'actual_gradient': correlated_gradient.tolist(), 'working_product_gradient': product_gradient.tolist()},
    'dimension_scaling_illustration': dimension_scaling,
    'source_conditions': ['independent preprocessing', 'iid core under P_ref', 'fixed finite profile set and target', 'uniform bounded gradient and parameter Lipschitz constants', 'all evaluated iterates in stated parameter set', 'fresh conditional current minibatches'],
}
(ROOT / 'theory_checks_v3.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
print(json.dumps({k:v for k,v in results.items() if k != 'dimension_scaling_illustration'}, indent=2))
