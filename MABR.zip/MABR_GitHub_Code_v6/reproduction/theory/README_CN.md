# v3理论补强交付与适用边界

状态：新增命题、完整证明和独立数学复核完成。没有修改v2主稿。以下结果是标准集中不等式、耦合和几何分析在本方法中的具体化，未宣称新的最优速率或相对FLTrust的普遍优势。

## 交付文件

- `theory_extensions.tex`：三个新增小节，可接在v2理论第5.5节之后。
- `theory_extensions_proofs.tex`：可接在附录证明之后的完整推导。
- `check_theory_v3.py`与`theory_checks_v3.json`：数值错误探测脚本和实际结果。
- `independent_audit.md`：另一个代理独立重推公式、常数与边界条件的记录。

## 1. 自适应复用核心的总体一致界

令参考核心来自P_r，不把它自动视为部署总体P_0。先联合固定整个setup A：预处理、参数域、profile集、target和所有包络常数；条件于A后，N_0个核心样本须iid于P_r。单独逐个说各设置与core边际独立不够。参数落在预先固定的d维半径R球内；坐标梯度有界G且关于参数L_h-Lipschitz；K个工作profile及target预先固定，不能用同一core从无限类中选取。

掩码积分后的transport函数f_theta,q,j逐点有界2G*r，参数Lipschitz常数2L_h*r。epsilon-net+Hoeffding给出以至少1-delta概率，所有theta、profile及坐标同时成立：

    |D_r(theta,q)_j-D_N0(theta,q)_j|
      <= r(q,q*) min{4G, G sqrt(8 a_epsilon/N0)+4 L_h epsilon},
    a_epsilon=log(2Kd/delta)+d log(1+2R/epsilon).

因此允许theta沿训练历史适应这个core。再将失败概率拆为delta/2和delta/2，与现有条件小批次Bernstein界联合，即得到可直接代入既有median/descent理论的显式kappa界。总体差异D_0-D_r仍单列；同一G在P_0支持集也有效时，其大小<=4G*r*TV(P_0,P_r)。

**限制不能删掉：**现有实验的StandardScaler直接拟合同一core，因此不符合独立预处理条件；自然缺失数据用complete cases选核心时，P_r可能不等于P_0。现有实验也未确保全轨迹位于预设紧致参数域。这个新界增加了明确的附加条件总体理论，但不能被写成已经验证所有实验的泛化保证。

维数覆盖界很保守。仅作尺度说明，若取R=G=L_h=1、K=3、delta=.05、epsilon=1/N_0、r=1：Digits参数维数3346、N_0=64时根号项连同离散误差约45.2，必须截断至确定性4G；N_0=8192时仍约5.63。不能用这类保守界为小核心的实测准确率背书，论文应主动说明而不是把rate当实用误差条。

## 2. 原生缺失数据的工作模型残差

使用任意条件kernel K_i(m|Z)表示实际缺失，用产品Q_i表示服务器计算校正时采用的工作模型。对实际部署target K_*，精确分解为：

    honest corrected report - actual target gradient
      = client finite-data/sampling discrepancy
        + domain shift under K_i
        + (actual K_i - working Q_i) gradient discrepancy
        + (working Q_* - actual K_*) gradient discrepancy
        + working-law reference estimation error.

坐标梯度有界G时，两项kernel残差分别<=2G E_P0 TV(K_i,Q_i)与2G E_P0 TV(K_*,Q_*)。TV约定为半L1。这是数学分解与敏感性界，不识别自然MNAR，也不声称估计边际缺失率就估计出条件缺失law。

补充了真正的相同边际反例：沿用v2两特征平方损失模型，实际mask为00、11各半，工作mask为两个独立公平比特。二者边际都(.5,.5)，但w=(1,0)时实际梯度(0,0)、工作梯度(0,-.25)。即便mask不依赖X/Y，只要特征间相关，边际也不足以确定梯度。这直接支撑自然缺失实验应被解释为模型错设验证而非MCAR证据。

## 3. 与FLTrust的几何关系

已按官方NDSS原文第5页公式(2)-(4)核对FLTrust定义：ReLU cosine score、归一化到root范数、按score平均。访问日期2026-10-29，官方原文：
https://www.ndss-symposium.org/wp-content/uploads/2021-434-paper.pdf

保留两个方向的结论：

- 精确root a=g*且score和S>0时，FLTrust输出范数<=||g*||，且内积严格正，等于||g*||^2 sum(s_i^2)/sum(s_i)。所以不能编造其在理想root下可任意翻转目标梯度的结论。
- 若诚实report误差<=e、root误差<=e0，且e+e0<||g*||/sqrt2，则诚实score有显式正下界1-2(e+e0)^2/||g*||^2。由此得到恶意trust weight beta上界和FLTrust输出误差界。这个结果具体解释了transport如果降低诚实误差，如何改善一个充分的trust-score下界；如果参考噪声增加误差则无此结论。接近驻点时相对误差条件变严，不能略去||g*||的分母。

9个诚实g*=(1,0)、2个恶意(.5,sqrt3/2)的算例给FLTrust=(.95,sqrt3/20)、误差.1，中位数精确返回g*。这只表明两个聚合算子的exact-recovery性质不同；FLTrust仍是下降方向，RootOnly在此也精确，因此不能拿它当实测性能或信息效率优势。

零向量赋score=0；S=0时v3遵循作者数值代码返回零更新，其相对g*的误差为||g*||；g*=0不包括在相对误差命题内。上述恒等式是理想exact-arithmetic FLTrust map；实验中eps=1e-9的数值分母扰动不会逐字保留严格恒等式，不能将严格式误称为逐位代码输出性质。由前文逐坐标界转换到这里的二范数误差时使用e=(sum_j rho_j^2)^(1/2)，不能遗漏维数因子。

## 已实际执行的错误探测

- 3915组S>0的精确root几何恒等式（另有随机S=0样本跳过公式），最大绝对恒等式误差5.33e-15。
- 5000组受扰root+诚实report：score下界、恶意weight界、输出误差界均未发现违例。
- 5000组一般kernel误差分解与TV界：恒等式最大误差8.88e-16，未发现界的违例。
- 4000组实际二次函数梯度族的掩码积分包络、参数Lipschitz及参考分布TV界，未发现违例。
- 9+2精确例子、相同边际相关mask例子、e<||g||和e0<||g||但S=0的边界例子均复算。

这些是数值错误探测，不能替代一般证明或实际科学假设验证。所有未识别项和未验证条件已保留在可入稿文本中。

## 建议整合方式

正文优先保留一般kernel残差与FLTrust误差命题，把完整uniform覆盖细节放附录；若主文篇幅允许，可保留uniform定理但压缩其证明。摘要只写“uniform finite-core guarantee under independent preprocessing and a bounded parameter domain”，不可简写成“已解决有限参考数据的自适应泛化问题”。不建议增加仅为增加定理数量的f-order-stat结果：现有FLTrust beta界已经展示f作用，且已有median honest-majority分析并非最优统计率。

## 4. 后续补充：经验joint-mask transport

`joint_mask_transport.tex`与`joint_mask_transport_proof.tex`独立给出一般有限joint mask laws的标准maximal coupling构造、边际与最小不匹配概率TV的完整证明、条件Bernstein，以及uniform-core界的直接推广。该构造不是新coupling方法；算法性贡献若有，只能定位于把相关mask工作law用于本方法及相应实证，不能把标准耦合本身当作新定理。

目标mask只抽一次供各client共享；拒绝时client残余支持与target残余支持不交，因此拒绝必不匹配。c=1精确相同、c=0完全不相同、target概率零的模式等边界均已处理。只需要每个distinct client law一次额外gradient和一次targetgradient，K+1成本保持。自然数据的one-hot同步mask使用原变量pattern，不逐dummy独立遮蔽。

`check_joint_coupling.py`实际核对6000组离散law的精确joint mass、两侧边际、TV等式、2G*TV积分包络和4G^2*TV二阶矩；最大边际误差3.33e-16、最大TV等式误差1.33e-15。另按真实keep/reject sampler为三个client共享250000个targetdraw，每个client边际和mismatch均在预设.005误差检查内。结果见`joint_coupling_checks.json`。

可选书目`optional_reference.bib`已按作者大学官网核对Thorisson (2000)书的标题、作者、出版社、年份与ISBN；publisher DOI页不可达，故没有把未直接核验的DOI写入。原始构造证明已自给，不依赖此书的某一不可读扫描页。官网样章存在但文字抽取乱码，未对其具体页码/定理号作任何断言。可选择引用该书作一般coupling参考，或只承认“standard maximal coupling”并保留自给证明。

该joint law同样只是经验marginal工作law；K_i(m|X,Y)不被识别，选择complete cases的P_r偏差不会因此消失。所有uniform推广须条件于整个setup tuple后让core仍iid，不能仅逐个要求preprocess/profile边际独立。
