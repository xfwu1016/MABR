# 新增理论独立核验记录

范围：仅核验委托消息中的 A、B、C 数学命题；未修改主稿，未检查渲染版页面，未复现实验。方法：手工重推 Hoeffding/覆盖、核均值分解及 FLTrust 几何关系，并用独立数值运算复核给定反例和二维角度网格。以下结论是所给新命题的源式核验，不是全文正确性认证。

## A. 固定有限 profile 集上的参数一致公共 core 界

**结论：所给常数正确，但必须明确耦合、独立性与维数。**

设 mask 维数为 p，参数维数为 d_theta，输出坐标数为 d_out。若三者都采用 d，需在稿中明确是同一维数。取 q,q*∈[0,1]^p，以同一组独立 U_k∼Unif[0,1] 构造 M_q,k=1{U_k≤q_k}。则

    r(q,q*) = Pr(M_q != M_q*) = 1 - product_k(1-|q_k-q*_k|).

这里 r 是该阈值耦合的分歧概率；无需宣称它等于两个乘积 Bernoulli 分布的总变差。若 f 最初以两个独立 mask 写出，期望之差仍可改用这个共同耦合推导。

假设对所有 z,m,theta,j 有 |h_theta(z,m)_j|≤G，并且逐坐标关于 theta 的 Lipschitz 常数不超过 L_h。耦合一致时差为零，因此

    |f_theta,q,j(z)| ≤ 2 G r,
    |f_theta,q,j(z)-f_theta',q,j(z)| ≤ 2 L_h r ||theta-theta'||_2.

对固定 theta,q,j，f 的取值区间长度不超过 4Gr。Hoeffding 给出

    Pr(|P_N f-P_0 f|>t) ≤ 2 exp{-N t^2/(8 G^2 r^2)}.

半径 R 的欧氏球有 epsilon 网，中心可取在该球中，且 N_epsilon≤(1+2R/epsilon)^d_theta。对 K d_out N_epsilon 项并合，再从网点延伸到全参数球：经验均值和总体均值各贡献 2L_h r epsilon，故以至少 1-delta 的概率，所有 theta,q,j 同时满足

    |P_N f_theta,q,j-P_0 f_theta,q,j|
      ≤ r [G sqrt{8 log(2 K d_out N_epsilon/delta)/N} + 4 L_h epsilon].

r=0 时 f 恒为零，可直接处理，无需除以 r。设 N≥1、epsilon>0、delta∈(0,1)。该结果允许 theta 在观察公共 core 后自适应选取，只要它落在预先固定的球内。

必须写明：公共 core Z_1,...,Z_N 条件独立同分布于 P_0；预处理器在独立数据上构造。条件于预处理器后，h、有限 profile 集及其 target 和参数球须固定，且上述统一有界/Lipschitz 假设成立。若 profile 集只依赖这个独立预处理器，则条件证明依然有效，最后积分掉条件即可。若预处理器或 profile 集直接使用同一 core，不能沿用这个条件证明。

后续与小批次 Bernstein 合并时，参数关于整个 core 的自适应性已被本结论覆盖；但固定参数的条件 Bernstein 仍要求本轮小批次在参数和历史选定后新鲜抽样，或另外建立对该抽样的统一界。当前小批次参与选择 theta 时不能直接条件化为固定函数。

本界是标准覆盖与 Hoeffding 推导；没有据此得到最优性或相对于其他方法严格改进的结论。

## B. 一般 mask kernel 与乘积 surrogate

**结论：TV 常数与分解符号全部正确。**

采用 TV(P,Q)=sup_A|P(A)-Q(A)|=(1/2)||P-Q||_1 的约定。对每个 z，|h_theta(z,m)_j|≤G 蕴含

    |E_Ki(.|z) h_theta(z,M)_j - E_Qi h_theta(z,M)_j|
      ≤ 2G TV(K_i(.|z),Q_i).

再对 P_0 取期望和用三角不等式，得到所给 2G E_{P_0} TV 界。无需假定 K_i 与 Z 独立。所有 kernel 必须是同一 mask 空间上的可测概率核，并在 P_0 和 P_i 所需的共同 z 域上定义；只给出 P_i 几乎处处的条件分布而不给出其 P_0 域上的定义，不足以唯一确定公共参考均值。

令 Delta_i^K=mu_{P_i,K_i}-mu_{P_0,K_i}，D_i=mu_{P_0,Q_i}-mu_{P_0,Q*}。则逐坐标及向量恒有

    mu_{P_i,K_i} - D_i - mu_{P_0,K*}
      = Delta_i^K
        + (mu_{P_0,K_i}-mu_{P_0,Q_i})
        + (mu_{P_0,Q*}-mu_{P_0,K*}).

因此每个坐标的绝对剩余项不超过

    |Delta_i,j^K| + 2G [E_{P_0}TV(K_i,Q_i) + E_{P_0}TV(K*,Q*)].

target 的符号为 Q* 减 K*，与客户端项相反。这里 target 是共同参考域上的 mu_{P_0,K*}；若 target 改为另一个 Z 分布，还需要相应分布偏移项。

匹配 mask 边际不足以消除这些项。例：两比特 K 在 00、11 各取 1/2，Q 为独立公平比特，二者边际相同。令 h=G（两比特相等）或 -G（不等），则 mu_K=G、mu_Q=0、TV(K,Q)=1/2，差恰为 2G TV=G。因而常数 2 在仅有绝对有界性时不能普遍降低；也不能据此把乘积校正称为对任意依赖/缺失机制均无偏。

## C. FLTrust 的方向与误差命题

**结论：所给恒等式及误差上界正确；零向量、零总权重和范数记号必须处理。**

用 gamma:=||g||_2>0 表示 target 范数，避免与 A/B 的逐坐标有界常数 G 混淆。所有本节范数均为二范数。

若 a=g，所有参与归一化的 g_i 非零，s_i=max(0,<g_i,g>/(||g_i|| gamma))，S=sum_i s_i>0，则

    v = gamma sum_i s_i g_i/||g_i|| / S,
    ||v||≤gamma,
    <g,v> = gamma^2 sum_i s_i^2/S > 0.

最后一步使用 s_i cos_i=s_i^2；严格正性仅来自 S>0。这证明负 v 是严格下降方向；若要给某个有限步长的损失下降，还须补充相应光滑性和步长条件。

设诚实校正向量 u_i=g+e_i，||e_i||≤epsilon<gamma，且 ||a-g||≤epsilon_0<gamma。两类向量因此非零。标准归一化不等式给出

    ||u_i/||u_i||-a/||a|||| ≤ 2(epsilon+epsilon_0)/gamma,
    s_i ≥ max{0, 1-2(epsilon+epsilon_0)^2/gamma^2}.

若要使用正的 s_min，须额外要求 epsilon+epsilon_0<gamma/sqrt(2)，并可取 s_min=1-2(epsilon+epsilon_0)^2/gamma^2。单独 epsilon<gamma、epsilon_0<gamma 不保证 S>0。明确反例：g=(1,0)，a=(0.36,0.48)，所有诚实 u_i=(0.36,-0.48)。两项误差都为 0.8<gamma，但 cosine=-0.28，每个 score 都为零。

设总数 n，至多 f 个恶意向量，0≤f<n；诚实数 h≥n-f，每个诚实 score≥s_min>0。恶意总权重比例 beta 满足

    beta ≤ f/[f+(n-f)s_min].

这是因为单个 score≤1，恶意 score 总和≤f，而诚实 score 总和≥(n-f)s_min。在这些条件下 S 自动为正。

令 w_i=||a|| u_i/||u_i||。诚实项的常数可直接验证为

    ||w_i-g|| ≤ | ||a||-||u_i|| | + ||u_i-g||
               ≤ epsilon_0+2epsilon.

因此没有遗漏 epsilon epsilon_0/gamma 交叉项。任意非零攻击向量的归一化结果范数为 ||a||，故其与 g 的距离≤||a||+gamma≤2gamma+epsilon_0。凸组合得

    ||v-g|| ≤ (1-beta)(2epsilon+epsilon_0)
               + beta(2gamma+epsilon_0).

由于 epsilon<gamma，右侧随 beta 单调增加，可进一步用上面的 beta 上界代入。该界保守，不支持最优性或优于其他鲁棒聚合器的普遍比较。

零攻击向量可定义 score=0 并在归一化前跳过，或在命题中排除所有零输入。一般 S=0 的算法 fallback 需要单列；当前恒等式和误差命题不涵盖任意 fallback。若前文只得到逐坐标误差 b，则此处只能直接取 epsilon≤sqrt(d_out)b，不能无因子地改成二范数误差 b。

### 给定反例的独立复算

9 个诚实向量均为 g=a=(1,0)，2 个恶意向量均为 (1/2,sqrt(3)/2)。诚实 score=1，恶意 score=1/2，总权重 S=10，恶意比例 beta=0.1。

    v=(0.95,sqrt(3)/20)=(0.95,0.08660254037844387),
    ||v-g||=0.10000000000000002（数值舍入；精确值为 1/10）.

坐标中位数恰为 g；这个具体例子也有几何中位数 g。该反例否定对中位数的普遍精度优势，与严格下降方向结论相容。

另在二维 g=(1,0) 下对 epsilon∈[0,0.99)、epsilon_0∈[0,0.99) 及两类误差方向做有限角度网格检查，score 下界及诚实归一化误差界均未发现违例。有限数值检查仅作代数错误探测，不替代以上一般证明。

## 修订优先项

1. C 中定义 gamma=||g||、明确二范数，并补齐 s_min>0 / S>0、n>f 和零向量/fallback 处理。
2. A 中写清阈值耦合及独立预处理条件；后续小批次条件界保留新鲜抽样假设。
3. B 中保留两个 kernel-surrogate 残差项和共同参考分布 P_0；不要把边际匹配提升为一般无偏性。
4. 不从这些上界推出相对于基线的普遍优势或最优常数；明确给定中位数反例的适用比较范围。
